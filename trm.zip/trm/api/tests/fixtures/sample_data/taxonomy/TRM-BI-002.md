# BI & Analytics › Reporting › Enterprise Reporting

```json
{
  "trm_id": "TRM-BI-002",
  "domain": "BI & Analytics",
  "area": "Reporting",
  "category": "Enterprise Reporting",
  "status": "Active"
}
```

## Scope
Centrally governed, scheduled and paginated reporting platforms used for operational, statutory and regulatory reports (for example IBM Cognos Analytics).
