# Databases › Relational Databases › Open Source RDBMS

```json
{
  "trm_id": "TRM-DB-002",
  "domain": "Databases",
  "category": "Relational Databases",
  "sub_category": "Open Source RDBMS"
}
```

## Scope
Community-governed relational database engines distributed under an open source licence (for example PostgreSQL). Support may be community-based or via a commercial distribution.
