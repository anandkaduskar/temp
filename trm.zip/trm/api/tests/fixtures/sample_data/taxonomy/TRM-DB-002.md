# Databases › Relational Databases › Open Source RDBMS

```json
{
  "trm_id": "TRM-DB-002",
  "domain": "Databases",
  "area": "Relational Databases",
  "category": "Open Source RDBMS",
  "status": "Active"
}
```

## Scope
Community-governed relational database engines distributed under an open source licence (for example PostgreSQL). Support may be community-based or via a commercial distribution.
