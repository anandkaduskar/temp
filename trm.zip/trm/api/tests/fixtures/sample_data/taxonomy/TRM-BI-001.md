# BI & Analytics › Visualisation › Self-Service Analytics

```json
{
  "trm_id": "TRM-BI-001",
  "domain": "BI & Analytics",
  "area": "Visualisation",
  "category": "Self-Service Analytics",
  "status": "Active"
}
```

## Scope
Interactive dashboarding and data discovery tools used by business users and analysts to build their own analyses (for example Power BI, Qlik Sense).
