# BI & Analytics › Visualisation › Self-Service Analytics

```json
{
  "trm_id": "TRM-BI-001",
  "domain": "BI & Analytics",
  "category": "Visualisation",
  "sub_category": "Self-Service Analytics"
}
```

## Scope
Interactive dashboarding and data discovery tools used by business users and analysts to build their own analyses (for example Power BI, Qlik Sense).
