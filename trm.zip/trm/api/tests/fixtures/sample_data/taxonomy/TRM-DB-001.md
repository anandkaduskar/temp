# Databases › Relational Databases › Commercial RDBMS

```json
{
  "trm_id": "TRM-DB-001",
  "domain": "Databases",
  "area": "Relational Databases",
  "category": "Commercial RDBMS",
  "status": "Active"
}
```

## Scope
Licensed relational database engines supplied and supported by a commercial vendor (for example Oracle Database, Microsoft SQL Server). Covers the engine, vendor-supplied tooling and standard editions/options.
