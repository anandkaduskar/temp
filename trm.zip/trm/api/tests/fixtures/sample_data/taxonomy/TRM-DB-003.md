# Databases › NoSQL › Document Store

```json
{
  "trm_id": "TRM-DB-003",
  "domain": "Databases",
  "area": "NoSQL",
  "category": "Document Store",
  "status": "Proposed"
}
```

## Scope
Document-oriented NoSQL databases. No technology has been registered against this node yet, so it shows up as a coverage gap in `/v1/reports/taxonomy-coverage`.
