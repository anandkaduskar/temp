import shutil
from datetime import date
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from trm_api import validate as validate_mod
from trm_api.lifecycle import lifecycle_state, review_state, risk_rating
from trm_api.loader import load
from trm_api.main import app

DATA = Path(__file__).parent / "fixtures" / "sample_data"
AS_OF = "2026-11-12"
client = TestClient(app)


# ---------------------------------------------------------------- loader / validator
def test_sample_data_loads_clean():
    repo = load(DATA)
    assert (len(repo.taxonomy), len(repo.technologies), len(repo.versions), len(repo.mappings)) == (5, 6, 13, 13)
    issues = validate_mod.all_issues(repo)
    assert [i for i in issues if i.level == "error"] == []
    warnings = [i for i in issues if i.level == "warning"]
    assert len(warnings) == 1 and "MAP-1002-01" in warnings[0].message


@pytest.fixture()
def data_copy(tmp_path):
    dst = tmp_path / "data"
    shutil.copytree(DATA, dst)
    return dst


def test_validator_catches_broken_references(data_copy):
    f = data_copy / "technologies" / "TECH-0003.md"
    f.write_text(f.read_text().replace('"trm_id": "TRM-DB-002"', '"trm_id": "TRM-DB-999"'))
    m = data_copy / "mappings" / "APP-1005.md"
    m.write_text(m.read_text().replace('"version": "16"', '"version": "99"'))
    msgs = [i.message for i in validate_mod.all_issues(load(data_copy)) if i.level == "error"]
    assert any("TRM-DB-999" in x for x in msgs)
    assert any("'99' is not registered" in x for x in msgs)


def test_validator_catches_schema_and_filename_errors(data_copy):
    f = data_copy / "technologies" / "TECH-0001.md"
    f.write_text(f.read_text().replace('"Disinvest"', '"Retire"').replace('"owner"', '"ownr"'))
    (data_copy / "taxonomy" / "TRM-DB-002.md").rename(data_copy / "taxonomy" / "TRM-DB-077.md")
    msgs = " | ".join(i.message for i in load(data_copy).issues)
    assert "investment_status" in msgs and "ownr" in msgs and "file name must equal" in msgs


def test_bad_json_is_reported_not_raised(data_copy):
    (data_copy / "taxonomy" / "TRM-DB-003.md").write_text("# x\n```json\n{ not json }\n```\n")
    repo = load(data_copy)
    assert any("invalid JSON" in i.message for i in repo.issues)
    assert len(repo.taxonomy) == 4


def test_cli_exit_codes(data_copy):
    assert validate_mod.main(["--data-dir", str(data_copy)]) == 0
    assert validate_mod.main(["--data-dir", str(data_copy), "--strict"]) == 1  # sample has 1 warning


# ---------------------------------------------------------------- lifecycle rules
D = date(2026, 11, 12)


@pytest.mark.parametrize("eol,eos,expected", [
    (None, None, "Not Dated"),
    (date(2022, 3, 31), date(2025, 3, 31), "Out of Support"),
    (date(2026, 4, 30), date(2030, 4, 30), "Past End of Life"),
    (date(2026, 11, 26), date(2026, 11, 26), "Nearing End of Life"),
    (date(2029, 12, 31), date(2032, 12, 31), "Supported"),
    (None, date(2027, 1, 1), "Nearing End of Life"),
    (date(2026, 1, 1), None, "Past End of Life"),
])
def test_lifecycle_state(eol, eos, expected):
    assert lifecycle_state(eol, eos, D) == expected


def test_review_and_risk_rules():
    assert review_state(date(2026, 11, 11), D) == "Overdue"
    assert review_state(date(2026, 12, 18), D) == "Due Soon"
    assert review_state(date(2027, 5, 1), D) == "Current"
    assert risk_rating("Out of Support", "Invest") == "High"
    assert risk_rating("Supported", "Disinvest") == "Medium"
    assert risk_rating("Supported", "Invest") == "Low"


# ---------------------------------------------------------------- API
def test_health():
    r = client.get("/health").json()
    assert r["status"] == "ok" and r["errors"] == 0 and r["records"]["technologies"] == 6


def test_status_filter_matches_brief():
    r = client.get("/v1/technologies", params={"as_of": AS_OF}).json()
    status = {t["name"]: t["investment_status"] for t in r}
    assert status == {
        "Oracle Database": "Disinvest", "Microsoft SQL Server": "Invest", "PostgreSQL": "Invest",
        "Qlik Sense": "Disinvest", "Microsoft Power BI": "Invest", "IBM Cognos Analytics": "Disinvest",
    }
    only = client.get("/v1/technologies", params={"status": "disinvest", "domain": "databases", "as_of": AS_OF}).json()
    assert [t["name"] for t in only] == ["Oracle Database"]


def test_technology_detail_joins_everything():
    r = client.get("/v1/technologies/TECH-0001", params={"as_of": AS_OF}).json()
    assert r["domain"] == "Databases" and r["sub_category"] == "Commercial RDBMS"
    assert {v["version"]: v["lifecycle_state"] for v in r["versions"]} == {
        "12.2.0.1": "Out of Support", "19c": "Supported"}
    assert {a["application_id"] for a in r["applications"]} == {"APP-1001", "APP-1002", "APP-1004"}
    assert "Disinvest" in r["narrative"]
    assert client.get("/v1/technologies/TECH-9999").status_code == 404


def test_reports_match_hand_calculation():
    s = client.get("/v1/reports/summary", params={"as_of": AS_OF}).json()
    assert s["mapping_risk"] == {"High": 2, "Medium": 7, "Low": 4}
    assert s["versions_by_lifecycle_state"] == {
        "Out of Support": 2, "Past End of Life": 2, "Nearing End of Life": 3, "Supported": 4, "Not Dated": 2}
    assert s["reviews"] == {"Current": 4, "Due Soon": 2}
    assert s["technologies_by_status"] == {"Disinvest": 3, "Invest": 3}
    high = client.get("/v1/mappings", params={"risk_rating": "High", "as_of": AS_OF}).json()
    assert {m["mapping_id"] for m in high} == {"MAP-1002-01", "MAP-1007-01"}
    exp = client.get("/v1/reports/disinvest-exposure", params={"as_of": AS_OF}).json()
    oracle = next(e for e in exp if e["tech_name"] == "Oracle Database")
    assert oracle["application_count"] == 3 and oracle["applications_without_retirement_date"] == ["APP-1002"]
    gaps = [n["trm_id"] for n in client.get("/v1/reports/taxonomy-coverage").json() if n["gap"]]
    assert gaps == ["TRM-DB-003"]


def test_as_of_changes_derived_state():
    later = client.get("/v1/versions", params={"tech_id": "TECH-0004", "as_of": "2027-01-01"}).json()
    assert {v["version"]: v["lifecycle_state"] for v in later}["November 2024"] == "Out of Support"


def test_csv_exports():
    for ds, header in [("taxonomy", "trm_id,domain"), ("technologies", "tech_id,name"),
                       ("versions", "version_id,tech_id"), ("mappings", "mapping_id,application_id")]:
        r = client.get(f"/v1/export/{ds}.csv", params={"as_of": AS_OF})
        assert r.status_code == 200 and r.headers["content-type"].startswith("text/csv")
        assert r.text.startswith(header)
    lines = client.get("/v1/export/mappings.csv", params={"as_of": AS_OF}).text.strip().splitlines()
    assert len(lines) == 14 and "Prod|DR|UAT" in lines[1]
    assert client.get("/v1/export/nope.csv").status_code == 404


def test_raw_and_search_and_traversal():
    raw = client.get("/v1/raw/technologies/TECH-0003")
    assert raw.status_code == 200 and '"tech_id": "TECH-0003"' in raw.text
    assert client.get("/v1/raw/technologies/..%2F..%2FREADME").status_code == 404
    names = {h["name"] for h in client.get("/v1/search", params={"q": "oracle"}).json()}
    assert "Oracle Database" in names


def test_api_key_enforced_when_configured(monkeypatch):
    monkeypatch.setenv("TRM_API_KEY", "s3cret")
    assert client.get("/v1/taxonomy").status_code == 401
    assert client.get("/v1/taxonomy", headers={"X-API-Key": "wrong"}).status_code == 401
    assert client.get("/v1/taxonomy", headers={"X-API-Key": "s3cret"}).status_code == 200
    assert client.get("/health").status_code == 200


def test_export_cli(tmp_path):
    from trm_api.exports import main
    assert main(["--out", str(tmp_path), "--as-of", AS_OF, "--data-dir", str(DATA)]) == 0
    assert sorted(p.name for p in tmp_path.iterdir()) == ["mappings.csv", "taxonomy.csv", "technologies.csv", "versions.csv"]
