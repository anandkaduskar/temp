"""Tests run against a frozen copy of the sample data so they keep passing after the real data/ folder evolves."""
import os
from pathlib import Path

os.environ["TRM_DATA_DIR"] = str(Path(__file__).parent / "fixtures" / "sample_data")
os.environ.pop("TRM_API_KEY", None)
