"""Derived vendor-lifecycle state and risk rating. Nothing here is stored in the data files."""
from __future__ import annotations

from datetime import date

WARN_DAYS = 365          # "Nearing End of Life" window

# Higher = worse
STATE_RANK = {
    "Out of Support": 4,
    "Past End of Life": 3,
    "Nearing End of Life": 2,
    "Supported": 1,
    "Not Dated": 0,
}


def days_until(d: date | None, as_of: date) -> int | None:
    return None if d is None else (d - as_of).days


def lifecycle_state(eol: date | None, eos: date | None, as_of: date, warn_days: int = WARN_DAYS) -> str:
    """Vendor lifecycle state of a version.

    Out of Support      - EOS date has passed
    Past End of Life    - EOL passed (extended/paid support, or EOS unknown)
    Nearing End of Life - next date falls within warn_days
    Supported           - next date is further out
    Not Dated           - no dates recorded (SaaS/evergreen or not yet captured)
    """
    if eol is None and eos is None:
        return "Not Dated"
    if eos is not None and eos < as_of:
        return "Out of Support"
    if eol is not None and eol < as_of:
        return "Past End of Life"
    nxt = eol or eos
    return "Nearing End of Life" if (nxt - as_of).days <= warn_days else "Supported"


def risk_rating(state: str, investment_status: str | None) -> str:
    """High: out of vendor support. Medium: past/nearing EOL, or strategic Disinvest. Else Low."""
    if state == "Out of Support":
        return "High"
    if state in ("Past End of Life", "Nearing End of Life") or investment_status == "Disinvest":
        return "Medium"
    return "Low"
