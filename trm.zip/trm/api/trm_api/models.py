"""Record schemas for the four TRM datasets. Unknown fields are rejected so typos fail CI."""
from __future__ import annotations

from datetime import date
from enum import Enum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class InvestmentStatus(str, Enum):
    INVEST = "Invest"
    MAINTAIN = "Maintain"
    DISINVEST = "Disinvest"


class LicenceModel(str, Enum):
    COMMERCIAL = "Commercial"
    OPEN_SOURCE = "Open Source"
    SAAS = "SaaS"


Environment = Literal["Prod", "DR", "UAT", "Test", "Dev"]


class _Record(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Taxonomy(_Record):
    trm_id: str = Field(pattern=r"^TRM-[A-Z]{2,4}-\d{3}$")
    domain: str = Field(min_length=1)
    category: str = Field(min_length=1)
    sub_category: str = Field(min_length=1)


class Technology(_Record):
    tech_id: str = Field(pattern=r"^TECH-\d{4}$")
    name: str = Field(min_length=1)
    trm_id: str = Field(pattern=r"^TRM-[A-Z]{2,4}-\d{3}$")
    investment_status: InvestmentStatus
    owner: str = Field(min_length=1)
    review_date: date
    next_review_date: date
    vendor: str | None = None
    licence_model: LicenceModel | None = None
    arc_ref: str | None = Field(default=None, pattern=r"^ARC-\d{4}-\d{3}$")
    status_effective_date: date | None = None

    @model_validator(mode="after")
    def _review_order(self) -> "Technology":
        if self.next_review_date <= self.review_date:
            raise ValueError("next_review_date must be after review_date")
        return self


class Version(_Record):
    version_id: str = Field(pattern=r"^TECH-\d{4}-V\d{3}$")
    tech_id: str = Field(pattern=r"^TECH-\d{4}$")
    version: str = Field(min_length=1)
    eol_date: date | None = None  # end of life: end of standard/mainstream vendor support
    eos_date: date | None = None  # end of support: end of all vendor support incl. extended
    details: str = ""

    @model_validator(mode="after")
    def _date_order(self) -> "Version":
        if self.eol_date and self.eos_date and self.eol_date > self.eos_date:
            raise ValueError("eol_date must not be after eos_date")
        return self


class Mapping(_Record):
    mapping_id: str = Field(pattern=r"^MAP-\d{4}-\d{2}$")
    application_id: str = Field(pattern=r"^APP-\d{4}$")
    application_name: str = Field(min_length=1)
    tech_id: str = Field(pattern=r"^TECH-\d{4}$")
    version: str = Field(min_length=1)
    environments: list[Environment] = Field(min_length=1)
    usage: str = Field(min_length=1)
    planned_retirement_date: date | None = None
    notes: str | None = None
