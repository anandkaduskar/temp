"""Record schemas for the four TRM datasets. Unknown fields are rejected so typos fail CI."""
from __future__ import annotations

from datetime import date
from enum import Enum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

# IDs become file names, so they are restricted to a filename-safe pattern.
ID = r"^[A-Za-z0-9][A-Za-z0-9._-]*$"


class TaxonomyStatus(str, Enum):
    ACTIVE = "Active"
    PROPOSED = "Proposed"
    RETIRED = "Retired"


class InvestmentStatus(str, Enum):
    INVEST = "Invest"
    MAINTAIN = "Maintain"
    DISINVEST = "Disinvest"


Environment = Literal["Prod", "DR", "UAT", "Test", "Dev"]


class _Record(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class Taxonomy(_Record):
    """TRM ID, Domain, Area, Category, Status"""
    trm_id: str = Field(pattern=ID)
    domain: str = Field(min_length=1)
    area: str = Field(min_length=1)
    category: str = Field(min_length=1)
    status: TaxonomyStatus


class Technology(_Record):
    """Tech ID, Entity, Technology Name, TRM ID, Status, SME, IT Owner, Support Team, comments"""
    tech_id: str = Field(pattern=ID)
    entity: str = Field(min_length=1)
    technology_name: str = Field(min_length=1)
    trm_id: str = Field(pattern=ID)
    status: InvestmentStatus
    sme: str | None = None
    it_owner: str = Field(min_length=1)
    support_team: str | None = None
    comments: str | None = None


class Version(_Record):
    version_id: str = Field(pattern=ID)
    tech_id: str = Field(pattern=ID)
    version: str = Field(min_length=1)
    eol_date: date | None = None  # end of life: end of standard/mainstream vendor support
    eos_date: date | None = None  # end of support: end of all vendor support incl. extended
    details: str = ""

    @model_validator(mode="after")
    def _date_order(self) -> "Version":
        if self.eol_date and self.eos_date and self.eol_date > self.eos_date:
            raise ValueError("eol_date must not be after eos_date")
        return self


class Mapping(_Record):
    mapping_id: str = Field(pattern=ID)
    application_id: str = Field(pattern=ID)
    application_name: str = Field(min_length=1)
    tech_id: str = Field(pattern=ID)
    version: str = Field(min_length=1)
    environments: list[Environment] = Field(default_factory=list)
    usage: str | None = None
    planned_retirement_date: date | None = None
    notes: str | None = None
