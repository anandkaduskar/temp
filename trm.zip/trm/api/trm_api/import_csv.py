"""Bulk-load TRM records from CSV / Excel into the markdown+JSON data folders.

    python -m trm_api.import_csv --taxonomy taxonomy.csv --technologies technologies.csv
    python -m trm_api.import_csv --versions versions.csv --mappings mappings.csv --dry-run
    python -m trm_api.import_csv --technologies trm.xlsx::Technology
    python -m trm_api.import_csv --make-templates ./templates

Columns (header names are matched case-insensitively; spaces and underscores are equivalent):

    taxonomy      TRM ID, Domain, Area, Category, Status
    technologies  Tech ID, Entity, Technology Name, TRM ID, Status, SME, IT Owner, Support Team, comments
    versions      Tech ID, Version, EOL date, EOS date, details                  (Version ID optional)
    mappings      Application ID, Application Name, Tech ID, Version,
                  Environments, Usage, Planned Retirement Date, Notes            (Mapping ID optional)

Behaviour
- All-or-nothing: if any row in any file is invalid, nothing is written and every problem is listed with its row number.
- Idempotent: unchanged files are not touched, so Git diffs show only real changes.
- Existing prose in a file is kept; only the heading and the JSON record are rewritten.
- Optional columns missing from the sheet leave the existing values alone. A blank cell in a present column clears it.
- versions are written one file per technology, mappings one file per application. Rows are merged into the
  existing file by key (version / technology+version); existing entries not in the sheet are kept unless --replace.
- Version IDs and mapping IDs are generated for new rows and reused for existing ones.
- Mapping rows may carry one environment per row or a list (Prod, DR); rows for the same pair are merged.
- Dates: YYYY-MM-DD, DD-MM-YYYY, DD/MM/YYYY, DD-Mon-YYYY, Excel dates. Blank, NA, TBD, '-' mean no date.
- Records are never deleted. Files absent from the input are reported only.
- Excel: path may carry a sheet name after '::' (e.g. trm.xlsx::Versions); needs `pip install openpyxl`.
"""
from __future__ import annotations

import argparse
import csv
import itertools
import json
import re
import sys
from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum
from pathlib import Path
from typing import Callable, get_args

from pydantic import BaseModel, ValidationError

from .loader import default_data_dir, load, parse_md
from .models import (ID, Environment, InvestmentStatus, Mapping, Taxonomy, TaxonomyStatus, Technology, Version)
from .validate import all_issues

FENCED_JSON = re.compile(r"```json[ \t]*\r?\n.*?\r?\n```", re.DOTALL)
ID_RE = re.compile(ID)
ENVIRONMENTS = get_args(Environment)
ENV_ALIASES = {"prod": "Prod", "production": "Prod", "dr": "DR", "disaster recovery": "DR", "uat": "UAT",
               "test": "Test", "testing": "Test", "dev": "Dev", "development": "Dev"}
BLANKS = {"", "na", "n/a", "-", "tbd", "none", "null", "nil"}
DATE_FORMATS = ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%d-%m-%Y", "%d/%m/%Y", "%d.%m.%Y", "%d-%b-%Y", "%d %b %Y",
                "%d-%B-%Y", "%d %B %Y", "%b %d, %Y", "%B %d, %Y")


@dataclass(frozen=True, eq=False)
class Spec:
    dataset: str
    model: type[BaseModel]
    id_field: str                    # the record ID (flat) or the generated ID (grouped)
    columns: dict[str, str]          # field -> header label
    required: tuple[str, ...]        # columns that must exist in the file
    enums: dict[str, type[Enum]] = field(default_factory=dict)
    date_fields: tuple[str, ...] = ()
    list_fields: tuple[str, ...] = ()
    # grouped datasets (one file holds many records)
    group_field: str | None = None
    container_key: str | None = None
    parent_fields: tuple[str, ...] = ()
    natural_key: tuple[str, ...] = ()
    new_id: Callable[[str, int], str] | None = None

    def template_headers(self) -> list[str]:
        return [label for f, label in self.columns.items() if not (self.group_field and f == self.id_field)]


TAXONOMY = Spec(
    "taxonomy", Taxonomy, "trm_id",
    {"trm_id": "TRM ID", "domain": "Domain", "area": "Area", "category": "Category", "status": "Status"},
    ("trm_id", "domain", "area", "category", "status"), {"status": TaxonomyStatus})
TECHNOLOGIES = Spec(
    "technologies", Technology, "tech_id",
    {"tech_id": "Tech ID", "entity": "Entity", "technology_name": "Technology Name", "trm_id": "TRM ID",
     "status": "Status", "sme": "SME", "it_owner": "IT Owner", "support_team": "Support Team", "comments": "comments"},
    ("tech_id", "entity", "technology_name", "trm_id", "status", "it_owner"), {"status": InvestmentStatus})
VERSIONS = Spec(
    "versions", Version, "version_id",
    {"version_id": "Version ID", "tech_id": "Tech ID", "version": "Version", "eol_date": "EOL date",
     "eos_date": "EOS date", "details": "details"},
    ("tech_id", "version"), date_fields=("eol_date", "eos_date"),
    group_field="tech_id", container_key="versions", parent_fields=("tech_id",), natural_key=("version",),
    new_id=lambda gid, n: f"{gid}-V{n:03d}")
MAPPINGS = Spec(
    "mappings", Mapping, "mapping_id",
    {"mapping_id": "Mapping ID", "application_id": "Application ID", "application_name": "Application Name",
     "tech_id": "Tech ID", "version": "Version", "environments": "Environments", "usage": "Usage",
     "planned_retirement_date": "Planned Retirement Date", "notes": "Notes"},
    ("application_id", "application_name", "tech_id", "version"),
    date_fields=("planned_retirement_date",), list_fields=("environments",),
    group_field="application_id", container_key="mappings", parent_fields=("application_id", "application_name"),
    natural_key=("tech_id", "version"),
    new_id=lambda gid, n: f"MAP-{gid[4:] if gid.upper().startswith('APP-') else gid}-{n:02d}")
SPECS = (TAXONOMY, TECHNOLOGIES, VERSIONS, MAPPINGS)


def _key(header: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", header.strip().lower()).strip("_")


# ------------------------------------------------------------------ reading
def _cell(c) -> str:
    if c is None:
        return ""
    if isinstance(c, datetime):
        return c.date().isoformat()
    if isinstance(c, date):
        return c.isoformat()
    if isinstance(c, float) and c.is_integer():
        return str(int(c))
    return str(c)


def read_table(spec_path: str) -> tuple[list[str], list[tuple[int, list[str]]]]:
    """Return (headers, [(row_number, cells)]). Row numbers match the spreadsheet (header = row 1)."""
    path_s, _, sheet = spec_path.partition("::")
    path = Path(path_s)
    if not path.is_file():
        raise ValueError(f"file not found: {path}")
    if path.suffix.lower() in (".xlsx", ".xlsm"):
        try:
            from openpyxl import load_workbook
        except ImportError as exc:
            raise ValueError("reading Excel needs openpyxl: pip install openpyxl (or save the sheet as CSV)") from exc
        wb = load_workbook(path, read_only=True, data_only=True)
        if sheet and sheet not in wb.sheetnames:
            raise ValueError(f"sheet '{sheet}' not in {path.name}; found {wb.sheetnames}")
        ws = wb[sheet] if sheet else wb.worksheets[0]
        raw = [[_cell(c) for c in row] for row in ws.iter_rows(values_only=True)]
        wb.close()
    else:
        with path.open(newline="", encoding="utf-8-sig") as fh:  # utf-8-sig strips the BOM Excel adds
            raw = list(csv.reader(fh))
    if not raw:
        raise ValueError("file is empty")
    rows = [(i, [c.strip() for c in r]) for i, r in enumerate(raw[1:], start=2) if any(c.strip() for c in r)]
    return [h.strip() for h in raw[0]], rows


def read_rows(spec: Spec, source: str):
    """-> (present_fields, [(row_number, {field: text})], errors, warnings)"""
    try:
        headers, rows = read_table(source)
    except ValueError as exc:
        return set(), [], [f"{spec.dataset}: {exc}"], []
    seen = {_key(h): i for i, h in enumerate(headers)}
    index = {f: seen[_key(label)] for f, label in spec.columns.items() if _key(label) in seen}
    missing = [spec.columns[f] for f in spec.required if f not in index]
    if missing:
        return set(), [], [f"{spec.dataset}: missing required column(s): {', '.join(missing)}. Found: {headers}"], []
    known = {_key(label) for label in spec.columns.values()}
    ignored = [h for h in headers if h and _key(h) not in known]
    warns = [f"{spec.dataset}: ignoring unknown column(s): {', '.join(ignored)}"] if ignored else []
    out = [(n, {f: (cells[i] if i < len(cells) else "") for f, i in index.items()}) for n, cells in rows]
    return set(index), out, [], warns


# ------------------------------------------------------------------ cell coercion
def parse_date(text: str) -> str:
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(text.strip(), fmt).date().isoformat()
        except ValueError:
            continue
    raise ValueError(f"'{text}' is not a recognised date (use YYYY-MM-DD or DD-MM-YYYY)")


def coerce(spec: Spec, raw: dict[str, str], rownum: int, hint: str, errors: list[str]) -> dict | None:
    data: dict = {}
    ok = True

    def err(f: str, msg: str) -> None:
        nonlocal ok
        ok = False
        errors.append(f"{spec.dataset} row {rownum} ({hint}): {spec.columns[f]}: {msg}")

    for f, v in raw.items():
        if v == "":
            continue
        if f in spec.enums:
            v = next((m.value for m in spec.enums[f] if m.value.lower() == v.lower()), v)
        elif f in spec.date_fields:
            if v.lower() in BLANKS:
                continue
            try:
                v = parse_date(v)
            except ValueError as exc:
                err(f, str(exc))
                continue
        elif f in spec.list_fields:
            items = []
            for part in re.split(r"[,;|]", v):
                p = part.strip()
                if not p:
                    continue
                canon = ENV_ALIASES.get(p.lower())
                if canon is None:
                    err(f, f"'{p}' is not a known environment (use {', '.join(ENVIRONMENTS)})")
                else:
                    items.append(canon)
            v = list(dict.fromkeys(items))
            if not v:
                continue
        data[f] = v
    return data if ok else None


def _loc_label(spec: Spec, loc: tuple) -> str:
    name = str(loc[0]) if loc else "(row)"
    return spec.columns.get(name, name)


# ------------------------------------------------------------------ rendering
def json_block(obj: dict) -> str:
    return "```json\n" + json.dumps(obj, indent=2, ensure_ascii=False) + "\n```"


def render(existing: str | None, heading: str, obj: dict) -> str:
    """New file, or the existing file with only its heading and JSON block replaced (prose is kept)."""
    block = json_block(obj)
    if existing is None or not FENCED_JSON.search(existing):
        return f"# {heading}\n\n{block}\n"
    text = FENCED_JSON.sub(lambda _m: block, existing.replace("\r\n", "\n"), count=1)
    lines = text.split("\n")
    if lines[0].startswith("# "):
        lines[0] = f"# {heading}"
    return "\n".join(lines)


@dataclass
class FilePlan:
    path: Path
    text: str
    status: str                       # created | updated | unchanged
    notes: list[str] = field(default_factory=list)


def make_plan(path: Path, heading: str, obj: dict, notes: list[str] | None = None) -> FilePlan:
    old = path.read_text(encoding="utf-8") if path.exists() else None
    new = render(old, heading, obj)
    status = "created" if old is None else ("unchanged" if old.replace("\r\n", "\n") == new else "updated")
    return FilePlan(path, new, status, notes or [])


@dataclass
class Context:
    taxonomy_ids: set[str] = field(default_factory=set)
    tech_names: dict[str, str] = field(default_factory=dict)
    version_keys: set[tuple[str, str]] = field(default_factory=set)


@dataclass
class Result:
    plans: list[FilePlan] = field(default_factory=list)
    records: list[BaseModel] = field(default_factory=list)
    group_ids: set[str] = field(default_factory=set)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


def _existing_json(path: Path) -> dict | None:
    try:
        return parse_md(path)[0]
    except (ValueError, OSError, UnicodeDecodeError):
        return None


# ------------------------------------------------------------------ flat datasets (taxonomy, technologies)
def parse_flat(spec: Spec, present: set[str], rows, data_dir: Path) -> Result:
    res = Result()
    first_row: dict[str, int] = {}
    for rownum, raw in rows:
        hint = raw.get(spec.id_field) or "?"
        data = coerce(spec, raw, rownum, hint, res.errors)
        if data is None:
            continue
        rid = data.get(spec.id_field, "")
        path = data_dir / spec.dataset / f"{rid}.md"
        old = _existing_json(path) if ID_RE.fullmatch(rid) and path.exists() else None
        if old:  # columns absent from the sheet keep their current values
            for f in spec.columns:
                if f not in present and f in old and f not in data:
                    data[f] = old[f]
        try:
            rec = spec.model.model_validate(data)
        except ValidationError as exc:
            for e in exc.errors():
                res.errors.append(f"{spec.dataset} row {rownum} ({hint}): {_loc_label(spec, e['loc'])}: {e['msg']}")
            continue
        if rid in first_row:
            res.errors.append(f"{spec.dataset} row {rownum} ({rid}): duplicate ID, first seen on row {first_row[rid]}")
            continue
        first_row[rid] = rownum
        res.records.append(rec)
        res.group_ids.add(rid)
    return res


def _heading_flat(spec: Spec, rec: BaseModel) -> str:
    if spec.dataset == "taxonomy":
        return f"{rec.domain} › {rec.area} › {rec.category}"  # type: ignore[attr-defined]
    return rec.technology_name  # type: ignore[attr-defined]


# ------------------------------------------------------------------ grouped datasets (versions, mappings)
def parse_grouped(spec: Spec, present: set[str], rows, data_dir: Path, ctx: Context, replace: bool) -> Result:
    res = Result()
    groups: dict[str, list[tuple[int, dict]]] = {}
    for rownum, raw in rows:
        hint = f"{raw.get(spec.group_field) or '?'} {' '.join(raw.get(k, '') for k in spec.natural_key)}".strip()
        data = coerce(spec, raw, rownum, hint, res.errors)
        if data is None:
            continue
        gid = data.get(spec.group_field, "")
        if not gid:
            res.errors.append(f"{spec.dataset} row {rownum}: {spec.columns[spec.group_field]}: Field required")
            continue
        groups.setdefault(gid, []).append((rownum, data))

    def child_key(c: dict) -> tuple:
        return tuple(str(c.get(k, "")) for k in spec.natural_key)

    for gid, items in groups.items():
        first = items[0][0]
        if not ID_RE.fullmatch(gid):
            res.errors.append(f"{spec.dataset} row {first} ({gid}): {spec.columns[spec.group_field]}: "
                              "may contain only letters, digits, '.', '_' and '-'")
            continue
        path = data_dir / spec.dataset / f"{gid}.md"
        existing_children: list[dict] = []
        if path.exists():
            try:
                edata, _ = parse_md(path)
            except (ValueError, OSError, UnicodeDecodeError) as exc:
                res.errors.append(f"{spec.dataset}/{path.name}: existing file cannot be read ({exc}); fix it before importing")
                continue
            lst = edata.get(spec.container_key)
            existing_children = [c for c in lst if isinstance(c, dict)] if isinstance(lst, list) else []
        old_by_key = {child_key(c): c for c in existing_children}

        # parent fields (e.g. application name) must agree across the group
        for pf in spec.parent_fields[1:]:
            vals = {d[pf] for _, d in items if d.get(pf)}
            if len(vals) > 1:
                res.errors.append(f"{spec.dataset} ({gid}): {spec.columns[pf]} differs between rows: {sorted(vals)}")

        # merge rows describing the same record (e.g. one row per environment)
        merged: dict[tuple, tuple[int, dict]] = {}
        for rownum, data in items:
            key = child_key(data)
            if not all(key):
                names = ", ".join(spec.columns[k] for k, v in zip(spec.natural_key, key) if not v)
                res.errors.append(f"{spec.dataset} row {rownum} ({gid}): {names}: Field required")
                continue
            if key not in merged:
                merged[key] = (rownum, dict(data))
                continue
            row0, base = merged[key]
            for f, v in data.items():
                if f not in base:
                    base[f] = v
                elif f in spec.list_fields:
                    base[f] = list(dict.fromkeys([*base[f], *v]))
                elif base[f] != v:
                    res.errors.append(f"{spec.dataset} row {rownum} ({gid}): {spec.columns[f]} '{v}' conflicts with "
                                      f"'{base[f]}' on row {row0} for the same {' / '.join(spec.natural_key)}")

        used = {str(c.get(spec.id_field)) for c in existing_children if c.get(spec.id_field)}
        new_children: dict[tuple, dict] = {}
        recs: list[BaseModel] = []
        for key, (rownum, data) in merged.items():
            old = old_by_key.get(key)
            if old:
                for f in spec.columns:
                    if f not in present and f in old and f not in data:
                        data[f] = old[f]
            rid = data.get(spec.id_field) or (old or {}).get(spec.id_field)
            if not rid:
                rid = next(c for n in itertools.count(1) if (c := spec.new_id(gid, n)) not in used)  # type: ignore[misc]
            used.add(str(rid))
            data[spec.id_field] = rid
            try:
                rec = spec.model.model_validate(data)
            except ValidationError as exc:
                for e in exc.errors():
                    res.errors.append(f"{spec.dataset} row {rownum} ({gid} {' '.join(key)}): {_loc_label(spec, e['loc'])}: {e['msg']}")
                continue
            recs.append(rec)
            new_children[key] = rec.model_dump(mode="json", exclude=set(spec.parent_fields), exclude_none=True)
        if not recs:
            continue

        parent = {k: getattr(recs[0], k) for k in spec.parent_fields}
        children: list[dict] = []
        added = updated = kept = removed = 0
        for old in existing_children:
            key = child_key(old)
            if key in new_children:
                new = new_children.pop(key)
                children.append(new)
                updated += new != {k: v for k, v in old.items() if v is not None}
            elif replace:
                removed += 1
            else:
                children.append(old)
                kept += 1
        for new in new_children.values():
            children.append(new)
            added += 1

        if spec.dataset == "versions":
            heading = f"{ctx.tech_names.get(gid, gid)} — versions"
        else:
            heading = f"{gid} {parent['application_name']}"
        notes = [f"{n} {label}" for n, label in ((added, "added"), (updated, "changed"), (kept, "kept (not in input)"),
                                                  (removed, "removed")) if n]
        res.plans.append(make_plan(path, heading, {**parent, spec.container_key: children}, notes))
        res.records.extend(recs)
        res.group_ids.add(gid)
    return res


# ------------------------------------------------------------------ one dataset
def parse_dataset(spec: Spec, source: str, data_dir: Path, ctx: Context, replace: bool) -> Result:
    present, rows, errors, warnings = read_rows(spec, source)
    if errors:
        return Result(errors=errors)
    if spec.group_field:
        res = parse_grouped(spec, present, rows, data_dir, ctx, replace)
    else:
        res = parse_flat(spec, present, rows, data_dir)
        for rec in res.records:
            rid = getattr(rec, spec.id_field)
            obj = rec.model_dump(mode="json", exclude_none=True)
            res.plans.append(make_plan(data_dir / spec.dataset / f"{rid}.md", _heading_flat(spec, rec), obj))
    res.warnings = warnings
    return res


def cross_check(spec: Spec, res: Result, ctx: Context) -> None:
    """Referential checks against the input plus what is already in the data folder."""
    for r in res.records:
        if spec is TECHNOLOGIES and r.trm_id not in ctx.taxonomy_ids:  # type: ignore[attr-defined]
            res.errors.append(f"technologies ({r.tech_id}): TRM ID '{r.trm_id}' is not in the taxonomy")  # type: ignore[attr-defined]
        elif spec is VERSIONS and r.tech_id not in ctx.tech_names:  # type: ignore[attr-defined]
            res.errors.append(f"versions ({r.version_id}): Tech ID '{r.tech_id}' is not in the technologies")  # type: ignore[attr-defined]
        elif spec is MAPPINGS:
            if r.tech_id not in ctx.tech_names:  # type: ignore[attr-defined]
                res.errors.append(f"mappings ({r.mapping_id}): Tech ID '{r.tech_id}' is not in the technologies")  # type: ignore[attr-defined]
            elif (r.tech_id, r.version) not in ctx.version_keys:  # type: ignore[attr-defined]
                res.errors.append(f"mappings ({r.mapping_id}): {r.tech_id} version '{r.version}' is not registered "  # type: ignore[attr-defined]
                                  "in versions (import versions first)")


def update_context(spec: Spec, res: Result, ctx: Context) -> None:
    for r in res.records:
        if spec is TAXONOMY:
            ctx.taxonomy_ids.add(r.trm_id)  # type: ignore[attr-defined]
        elif spec is TECHNOLOGIES:
            ctx.tech_names[r.tech_id] = r.technology_name  # type: ignore[attr-defined]
        elif spec is VERSIONS:
            ctx.version_keys.add((r.tech_id, r.version))  # type: ignore[attr-defined]


# ------------------------------------------------------------------ CLI
def write_templates(out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    for spec in SPECS:
        path = out / f"{spec.dataset}_template.csv"
        path.write_text(",".join(spec.template_headers()) + "\n", encoding="utf-8", newline="")
        print(f"wrote {path}")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Create/update TRM markdown files from CSV or Excel")
    ap.add_argument("--taxonomy", help="TRM ID, Domain, Area, Category, Status")
    ap.add_argument("--technologies", help="Tech ID, Entity, Technology Name, TRM ID, Status, SME, IT Owner, Support Team, comments")
    ap.add_argument("--versions", help="Tech ID, Version, EOL date, EOS date, details")
    ap.add_argument("--mappings", help="Application ID, Application Name, Tech ID, Version, Environments, Usage, Planned Retirement Date, Notes")
    ap.add_argument("--data-dir", type=Path, default=None, help="default: ../data (or TRM_DATA_DIR)")
    ap.add_argument("--dry-run", action="store_true", help="show what would change, write nothing")
    ap.add_argument("--replace", action="store_true",
                    help="versions/mappings: drop existing entries (for the technologies/applications in the input) that are not in the sheet")
    ap.add_argument("--make-templates", type=Path, metavar="DIR", help="write empty CSV templates and exit")
    args = ap.parse_args(argv)

    if args.make_templates:
        write_templates(args.make_templates)
        return 0
    sources = {"taxonomy": args.taxonomy, "technologies": args.technologies, "versions": args.versions, "mappings": args.mappings}
    if not any(sources.values()):
        ap.error("give at least one of --taxonomy, --technologies, --versions, --mappings (or --make-templates DIR)")

    data_dir = args.data_dir or default_data_dir()
    existing = load(data_dir)
    ctx = Context({t.trm_id for t in existing.taxonomy}, {t.tech_id: t.technology_name for t in existing.technologies},
                  {(v.tech_id, v.version) for v in existing.versions})
    errors: list[str] = []
    results: list[tuple[Spec, Result]] = []
    for spec in SPECS:  # order matters: later datasets are checked against earlier ones
        if not sources[spec.dataset]:
            continue
        res = parse_dataset(spec, sources[spec.dataset], data_dir, ctx, args.replace)
        cross_check(spec, res, ctx)
        update_context(spec, res, ctx)
        errors += res.errors
        for w in res.warnings:
            print(f"WARNING {w}")
        results.append((spec, res))

    if errors:
        for e in errors:
            print(f"ERROR   {e}")
        print(f"\n{len(errors)} problem(s) found. Nothing was written.")
        return 1

    verb = "would " if args.dry_run else ""
    for spec, res in results:
        by = {s: [p for p in res.plans if p.status == s] for s in ("created", "updated", "unchanged")}
        print(f"{spec.dataset}: {len(res.group_ids)} {'files' if spec.group_field else 'rows'} | {verb}create "
              f"{len(by['created'])}, {verb}update {len(by['updated'])}, unchanged {len(by['unchanged'])}")
        for p in by["created"] + by["updated"]:
            mark = "+" if p.status == "created" else "~"
            print(f"  {mark} {p.path.name}" + (f"  ({', '.join(p.notes)})" if p.notes else ""))
        folder = data_dir / spec.dataset
        for stem in sorted(p.stem for p in folder.glob("*.md") if not p.name.startswith("_")) if folder.is_dir() else []:
            if stem not in res.group_ids:
                print(f"  ? {spec.dataset}/{stem}.md is not in the input (left untouched)")
        if not args.dry_run:
            (data_dir / spec.dataset).mkdir(parents=True, exist_ok=True)
            for p in res.plans:
                if p.status != "unchanged":
                    p.path.write_text(p.text, encoding="utf-8", newline="\n")

    if args.dry_run:
        return 0
    issues = all_issues(load(data_dir))
    n_err = sum(i.level == "error" for i in issues)
    # Informational: a partial load can legitimately leave other datasets incomplete.
    print(f"\nData check: {n_err} error(s), {len(issues) - n_err} warning(s). Run `python -m trm_api.validate` for details.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
