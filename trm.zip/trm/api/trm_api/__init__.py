"""Technology Reference Model (TRM) API - reads markdown/JSON records from Git."""
__version__ = "0.1.0"
