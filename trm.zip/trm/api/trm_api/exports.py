"""CSV rendering plus a CLI that writes the CSV set to disk (for scheduled Power BI loads).

    python -m trm_api.exports --out exports [--as-of 2026-11-12] [--data-dir PATH]
"""
from __future__ import annotations

import argparse
import csv
import io
from datetime import date
from pathlib import Path

from .loader import load
from .service import COLUMNS, dataset_rows


def _cell(v) -> str:
    if v is None:
        return ""
    if isinstance(v, list):
        return "|".join(str(x) for x in v)
    return str(v)


def to_csv(rows: list[dict], columns: list[str]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(columns)
    for r in rows:
        w.writerow([_cell(r.get(c)) for c in columns])
    return buf.getvalue()


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Export TRM datasets as CSV")
    ap.add_argument("--out", type=Path, default=Path("exports"))
    ap.add_argument("--as-of", type=date.fromisoformat, default=date.today())
    ap.add_argument("--data-dir", type=Path, default=None)
    args = ap.parse_args(argv)
    repo = load(args.data_dir)
    args.out.mkdir(parents=True, exist_ok=True)
    for ds, cols in COLUMNS.items():
        rows = dataset_rows(repo, ds, args.as_of)
        (args.out / f"{ds}.csv").write_text(to_csv(rows, cols), encoding="utf-8", newline="")
        print(f"wrote {args.out / (ds + '.csv')} ({len(rows)} rows)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
