"""Cross-record validation (referential integrity, duplicates, governance hygiene).

Run in CI:  python -m trm_api.validate [--strict] [--data-dir PATH]
Exit code 1 on any error (and on warnings with --strict).
"""
from __future__ import annotations

import argparse
import sys
from collections import Counter
from pathlib import Path

from .loader import ID_FIELD, Issue, Repository, load


def _where(repo: Repository, dataset: str, rid: str) -> str:
    return repo.record_files.get((dataset, rid), dataset)


def check(repo: Repository) -> list[Issue]:
    out: list[Issue] = []
    err = lambda ds, rid, msg: out.append(Issue("error", _where(repo, ds, rid), f"{rid}: {msg}"))  # noqa: E731
    warn = lambda ds, rid, msg: out.append(Issue("warning", _where(repo, ds, rid), f"{rid}: {msg}"))  # noqa: E731

    # duplicates
    for ds in ("taxonomy", "technologies", "versions", "mappings"):
        ids = [getattr(r, ID_FIELD[ds]) for r in getattr(repo, ds)]
        for rid, n in Counter(ids).items():
            if n > 1:
                err(ds, rid, f"duplicate id ({n} records)")
    for (tid, ver), n in Counter((v.tech_id, v.version) for v in repo.versions).items():
        if n > 1:
            err("versions", tid, f"duplicate version '{ver}'")
    for key, n in Counter((m.application_id, m.tech_id, m.version) for m in repo.mappings).items():
        if n > 1:
            err("mappings", key[0], f"duplicate mapping of {key[1]} {key[2]}")

    taxonomy = {t.trm_id: t for t in repo.taxonomy}
    techs = {t.tech_id: t for t in repo.technologies}
    version_keys = {(v.tech_id, v.version) for v in repo.versions}
    techs_with_versions = {v.tech_id for v in repo.versions}

    for t in repo.technologies:
        node = taxonomy.get(t.trm_id)
        if node is None:
            err("technologies", t.tech_id, f"trm_id '{t.trm_id}' not found in taxonomy")
        elif node.status.value == "Retired":
            warn("technologies", t.tech_id, f"mapped to retired taxonomy node {t.trm_id}")
        if not t.sme:
            warn("technologies", t.tech_id, "no SME recorded")
        if not t.support_team:
            warn("technologies", t.tech_id, "no support team recorded")
        if t.tech_id not in techs_with_versions:
            warn("technologies", t.tech_id, "no versions registered")
    for v in repo.versions:
        if v.tech_id not in techs:
            err("versions", v.version_id, f"tech_id '{v.tech_id}' not found in technologies")
    for m in repo.mappings:
        t = techs.get(m.tech_id)
        if t is None:
            err("mappings", m.mapping_id, f"tech_id '{m.tech_id}' not found in technologies")
            continue
        if (m.tech_id, m.version) not in version_keys:
            err("mappings", m.mapping_id, f"{m.tech_id} version '{m.version}' is not registered in versions/")
        if t.status.value == "Disinvest" and m.planned_retirement_date is None:
            warn("mappings", m.mapping_id,
                 f"{m.application_id} uses Disinvest technology {t.technology_name} with no planned_retirement_date")
    return out


def all_issues(repo: Repository) -> list[Issue]:
    return [*repo.issues, *check(repo)]


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Validate TRM markdown/JSON data")
    ap.add_argument("--data-dir", type=Path, default=None)
    ap.add_argument("--strict", action="store_true", help="fail on warnings too")
    args = ap.parse_args(argv)
    repo = load(args.data_dir)
    issues = all_issues(repo)
    for i in issues:
        print(f"{i.level.upper():7} {i.file}: {i.message}")
    errors = sum(i.level == "error" for i in issues)
    warnings = len(issues) - errors
    print(
        f"\n{len(repo.taxonomy)} taxonomy nodes, {len(repo.technologies)} technologies, "
        f"{len(repo.versions)} versions, {len(repo.mappings)} mappings | {errors} error(s), {warnings} warning(s)"
    )
    return 1 if errors or (args.strict and warnings) else 0


if __name__ == "__main__":
    sys.exit(main())
