"""Reads the markdown/JSON dataset folders into validated records.

Each .md file holds exactly one ```json block (the record) plus optional prose.
Problems are collected as Issues rather than raised, so one bad file never takes
the API down; CI fails the merge request on any error-level issue instead.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path

from pydantic import BaseModel, ValidationError

from .models import Mapping, Taxonomy, Technology, Version

JSON_BLOCK = re.compile(r"```json[ \t]*\r?\n(.*?)\r?\n```", re.DOTALL)
DATASETS = ("taxonomy", "technologies", "versions", "mappings")
ID_FIELD = {"taxonomy": "trm_id", "technologies": "tech_id", "versions": "version_id", "mappings": "mapping_id"}


@dataclass(frozen=True)
class Issue:
    level: str  # "error" | "warning"
    file: str
    message: str

    def as_dict(self) -> dict:
        return {"level": self.level, "file": self.file, "message": self.message}


@dataclass
class Repository:
    root: Path
    taxonomy: list[Taxonomy] = field(default_factory=list)
    technologies: list[Technology] = field(default_factory=list)
    versions: list[Version] = field(default_factory=list)
    mappings: list[Mapping] = field(default_factory=list)
    narratives: dict[tuple[str, str], str] = field(default_factory=dict)   # (dataset, file stem) -> prose
    sources: dict[tuple[str, str], Path] = field(default_factory=dict)     # (dataset, file stem) -> file
    record_files: dict[tuple[str, str], str] = field(default_factory=dict)  # (dataset, record id) -> rel path
    issues: list[Issue] = field(default_factory=list)


def default_data_dir() -> Path:
    env = os.environ.get("TRM_DATA_DIR")
    return Path(env) if env else Path(__file__).resolve().parents[2] / "data"


def parse_md(path: Path) -> tuple[dict, str]:
    text = path.read_text(encoding="utf-8")
    blocks = JSON_BLOCK.findall(text)
    if len(blocks) != 1:
        raise ValueError(f"expected exactly one ```json block, found {len(blocks)}")
    try:
        data = json.loads(blocks[0])
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("JSON root must be an object")
    return data, JSON_BLOCK.sub("", text, count=1).strip()


def _files(folder: Path) -> list[Path]:
    if not folder.is_dir():
        return []
    return sorted(p for p in folder.glob("*.md") if not p.name.startswith("_"))


def fingerprint(root: Path) -> tuple:
    out = []
    for ds in DATASETS:
        for p in _files(root / ds):
            st = p.stat()
            out.append((str(p), st.st_mtime_ns, st.st_size))
    return tuple(out)


def _load_dataset(
    repo: Repository,
    dataset: str,
    model: type[BaseModel],
    sink: list,
    child_key: str | None = None,
    parent_fields: tuple[str, ...] = (),
) -> None:
    folder = repo.root / dataset
    if not folder.is_dir():
        repo.issues.append(Issue("error", dataset, "dataset folder is missing"))
        return
    id_field = ID_FIELD[dataset]
    for path in _files(folder):
        rel = f"{dataset}/{path.name}"
        try:
            data, narrative = parse_md(path)
        except (ValueError, OSError, UnicodeDecodeError) as exc:
            repo.issues.append(Issue("error", rel, str(exc)))
            continue
        repo.sources[(dataset, path.stem)] = path
        repo.narratives[(dataset, path.stem)] = narrative

        if child_key:
            unknown = set(data) - set(parent_fields) - {child_key}
            if unknown:
                repo.issues.append(Issue("error", rel, f"unknown top-level keys: {sorted(unknown)}"))
                continue
            children = data.get(child_key)
            if not isinstance(children, list) or not children or not all(isinstance(c, dict) for c in children):
                repo.issues.append(Issue("error", rel, f"'{child_key}' must be a non-empty list of objects"))
                continue
            parent = {k: data[k] for k in parent_fields if k in data}
            records = [{**parent, **c} for c in children]
            file_id = data.get(parent_fields[0])
        else:
            records = [data]
            file_id = data.get(id_field)

        if file_id != path.stem:
            repo.issues.append(Issue("error", rel, f"file name must equal {parent_fields[0] if child_key else id_field} ('{file_id}')"))

        for rec in records:
            try:
                obj = model.model_validate(rec)
            except ValidationError as exc:
                for err in exc.errors():
                    loc = ".".join(str(x) for x in err["loc"]) or "(record)"
                    repo.issues.append(Issue("error", rel, f"{rec.get(id_field, '?')}: {loc}: {err['msg']}"))
                continue
            sink.append(obj)
            repo.record_files[(dataset, getattr(obj, id_field))] = rel


def load(root: Path | None = None) -> Repository:
    repo = Repository(root=root or default_data_dir())
    _load_dataset(repo, "taxonomy", Taxonomy, repo.taxonomy)
    _load_dataset(repo, "technologies", Technology, repo.technologies)
    _load_dataset(repo, "versions", Version, repo.versions, "versions", ("tech_id",))
    _load_dataset(repo, "mappings", Mapping, repo.mappings, "mappings", ("application_id", "application_name"))
    return repo
