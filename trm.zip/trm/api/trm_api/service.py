"""Joins, derived fields and reports built on top of the loaded Repository."""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import date

from .lifecycle import STATE_RANK, days_until, lifecycle_state, review_state, risk_rating
from .loader import Repository
from .validate import all_issues

# Stable column order for CSV exports (Power BI relies on a fixed schema).
COLUMNS: dict[str, list[str]] = {
    "taxonomy": ["trm_id", "domain", "category", "sub_category", "technology_count"],
    "technologies": [
        "tech_id", "name", "vendor", "licence_model", "trm_id", "domain", "category", "sub_category",
        "investment_status", "status_effective_date", "arc_ref", "owner", "review_date", "next_review_date",
        "review_state", "days_to_next_review", "version_count", "application_count", "as_of",
    ],
    "versions": [
        "version_id", "tech_id", "tech_name", "investment_status", "version", "eol_date", "eos_date",
        "lifecycle_state", "days_to_eol", "days_to_eos", "application_count", "details", "as_of",
    ],
    "mappings": [
        "mapping_id", "application_id", "application_name", "tech_id", "tech_name", "domain", "category",
        "sub_category", "investment_status", "version", "environments", "usage", "planned_retirement_date",
        "eol_date", "eos_date", "lifecycle_state", "days_to_eos", "risk_rating", "notes", "as_of",
    ],
}


def taxonomy_rows(repo: Repository) -> list[dict]:
    counts = Counter(t.trm_id for t in repo.technologies)
    return [{**t.model_dump(mode="json"), "technology_count": counts[t.trm_id]} for t in repo.taxonomy]


def technology_rows(repo: Repository, as_of: date) -> list[dict]:
    tax = {t.trm_id: t for t in repo.taxonomy}
    n_versions = Counter(v.tech_id for v in repo.versions)
    apps: dict[str, set[str]] = defaultdict(set)
    for m in repo.mappings:
        apps[m.tech_id].add(m.application_id)
    rows = []
    for t in repo.technologies:
        x = tax.get(t.trm_id)
        rows.append({
            **t.model_dump(mode="json"),
            "domain": x.domain if x else None,
            "category": x.category if x else None,
            "sub_category": x.sub_category if x else None,
            "review_state": review_state(t.next_review_date, as_of),
            "days_to_next_review": days_until(t.next_review_date, as_of),
            "version_count": n_versions[t.tech_id],
            "application_count": len(apps[t.tech_id]),
            "as_of": as_of.isoformat(),
        })
    return rows


def version_rows(repo: Repository, as_of: date) -> list[dict]:
    techs = {t.tech_id: t for t in repo.technologies}
    usage = Counter((m.tech_id, m.version) for m in repo.mappings)
    rows = []
    for v in repo.versions:
        t = techs.get(v.tech_id)
        rows.append({
            **v.model_dump(mode="json"),
            "tech_name": t.name if t else None,
            "investment_status": t.investment_status.value if t else None,
            "lifecycle_state": lifecycle_state(v.eol_date, v.eos_date, as_of),
            "days_to_eol": days_until(v.eol_date, as_of),
            "days_to_eos": days_until(v.eos_date, as_of),
            "application_count": usage[(v.tech_id, v.version)],
            "as_of": as_of.isoformat(),
        })
    return rows


def mapping_rows(repo: Repository, as_of: date) -> list[dict]:
    techs = {t.tech_id: t for t in repo.technologies}
    tax = {t.trm_id: t for t in repo.taxonomy}
    versions = {(v.tech_id, v.version): v for v in repo.versions}
    rows = []
    for m in repo.mappings:
        t = techs.get(m.tech_id)
        x = tax.get(t.trm_id) if t else None
        v = versions.get((m.tech_id, m.version))
        state = lifecycle_state(v.eol_date, v.eos_date, as_of) if v else "Not Dated"
        status = t.investment_status.value if t else None
        rows.append({
            **m.model_dump(mode="json"),
            "tech_name": t.name if t else None,
            "domain": x.domain if x else None,
            "category": x.category if x else None,
            "sub_category": x.sub_category if x else None,
            "investment_status": status,
            "eol_date": v.eol_date.isoformat() if v and v.eol_date else None,
            "eos_date": v.eos_date.isoformat() if v and v.eos_date else None,
            "lifecycle_state": state,
            "days_to_eos": days_until(v.eos_date, as_of) if v else None,
            "risk_rating": risk_rating(state, status),
            "as_of": as_of.isoformat(),
        })
    return rows


def dataset_rows(repo: Repository, dataset: str, as_of: date) -> list[dict]:
    if dataset == "taxonomy":
        return taxonomy_rows(repo)
    if dataset == "technologies":
        return technology_rows(repo, as_of)
    if dataset == "versions":
        return version_rows(repo, as_of)
    if dataset == "mappings":
        return mapping_rows(repo, as_of)
    raise KeyError(dataset)


# ---------------------------------------------------------------- reports

_RISK_ORDER = {"High": 0, "Medium": 1, "Low": 2}


def lifecycle_risk(repo: Repository, as_of: date) -> list[dict]:
    rows = [r for r in mapping_rows(repo, as_of) if r["risk_rating"] != "Low"]
    rows.sort(key=lambda r: (_RISK_ORDER[r["risk_rating"]], -STATE_RANK[r["lifecycle_state"]],
                             r["days_to_eos"] if r["days_to_eos"] is not None else 10**9))
    return rows


def disinvest_exposure(repo: Repository, as_of: date) -> list[dict]:
    by_tech: dict[str, list[dict]] = defaultdict(list)
    for r in mapping_rows(repo, as_of):
        if r["investment_status"] == "Disinvest":
            by_tech[r["tech_id"]].append(r)
    out = []
    for tech_id, rows in by_tech.items():
        dates = [r["planned_retirement_date"] for r in rows if r["planned_retirement_date"]]
        out.append({
            "tech_id": tech_id,
            "tech_name": rows[0]["tech_name"],
            "application_count": len({r["application_id"] for r in rows}),
            "applications_without_retirement_date": sorted({r["application_id"] for r in rows if not r["planned_retirement_date"]}),
            "last_planned_retirement_date": max(dates) if dates else None,
            "applications": [
                {k: r[k] for k in ("application_id", "application_name", "version", "environments",
                                   "lifecycle_state", "planned_retirement_date")}
                for r in rows
            ],
        })
    return sorted(out, key=lambda x: -x["application_count"])


def reviews_due(repo: Repository, as_of: date, within_days: int) -> list[dict]:
    rows = [r for r in technology_rows(repo, as_of) if r["days_to_next_review"] <= within_days]
    return sorted(rows, key=lambda r: r["days_to_next_review"])


def taxonomy_coverage(repo: Repository) -> list[dict]:
    names: dict[str, list[str]] = defaultdict(list)
    for t in repo.technologies:
        names[t.trm_id].append(t.name)
    return [
        {**t.model_dump(mode="json"), "technology_count": len(names[t.trm_id]),
         "technologies": sorted(names[t.trm_id]), "gap": not names[t.trm_id]}
        for t in repo.taxonomy
    ]


def summary(repo: Repository, as_of: date) -> dict:
    techs = technology_rows(repo, as_of)
    issues = all_issues(repo)
    by_dom = Counter((t["domain"], t["investment_status"]) for t in techs)
    return {
        "as_of": as_of.isoformat(),
        "counts": {
            "taxonomy_nodes": len(repo.taxonomy),
            "technologies": len(repo.technologies),
            "versions": len(repo.versions),
            "applications": len({m.application_id for m in repo.mappings}),
            "mappings": len(repo.mappings),
        },
        "technologies_by_status": dict(Counter(t["investment_status"] for t in techs)),
        "technologies_by_domain_status": [
            {"domain": d, "investment_status": s, "count": n} for (d, s), n in sorted(by_dom.items(), key=str)
        ],
        "versions_by_lifecycle_state": dict(Counter(v["lifecycle_state"] for v in version_rows(repo, as_of))),
        "mapping_risk": dict(Counter(m["risk_rating"] for m in mapping_rows(repo, as_of))),
        "reviews": dict(Counter(t["review_state"] for t in techs)),
        "data_quality": {
            "errors": sum(i.level == "error" for i in issues),
            "warnings": sum(i.level == "warning" for i in issues),
        },
    }


def search(repo: Repository, q: str) -> list[dict]:
    needle = q.lower()
    hits = []
    for t in repo.technologies:
        prose = repo.narratives.get(("technologies", t.tech_id), "")
        hay = " ".join([t.name, t.vendor or "", t.owner, prose]).lower()
        if needle in hay:
            hits.append({"type": "technology", "id": t.tech_id, "name": t.name,
                         "investment_status": t.investment_status.value})
    for t in repo.taxonomy:
        prose = repo.narratives.get(("taxonomy", t.trm_id), "")
        if needle in " ".join([t.domain, t.category, t.sub_category, prose]).lower():
            hits.append({"type": "taxonomy", "id": t.trm_id,
                         "name": f"{t.domain} > {t.category} > {t.sub_category}"})
    apps = {(m.application_id, m.application_name) for m in repo.mappings}
    for aid, name in sorted(apps):
        if needle in f"{aid} {name}".lower():
            hits.append({"type": "application", "id": aid, "name": name})
    return hits
