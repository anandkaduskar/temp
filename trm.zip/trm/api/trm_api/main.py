"""FastAPI service exposing the TRM for consumers, AI models and Power BI.

Run:  python -m uvicorn trm_api.main:app --reload --port 8080   (from the api/ folder)
Env:  TRM_DATA_DIR      data folder (default: ../data)
      TRM_AUTO_RELOAD   "false" to load once at start-up (default: reload when files change)
      TRM_API_KEY       if set, every /v1 call must send header X-API-Key
"""
from __future__ import annotations

import os
import secrets
import threading
from datetime import date

from fastapi import APIRouter, Depends, FastAPI, Header, HTTPException, Query
from fastapi.responses import PlainTextResponse, Response

from . import __version__, service
from .exports import to_csv
from .loader import DATASETS, Repository, default_data_dir, fingerprint, load
from .validate import all_issues

app = FastAPI(
    title="Technology Reference Model API",
    version=__version__,
    description="Read-only access to the Git-managed Technology Reference Model: taxonomy, technologies, "
    "versions and application mappings, with derived lifecycle state, MI reports and CSV exports.",
)

_lock = threading.Lock()
_cache: dict = {"fp": None, "repo": None}


def get_repo() -> Repository:
    root = default_data_dir()
    auto = os.environ.get("TRM_AUTO_RELOAD", "true").lower() != "false"
    with _lock:
        if _cache["repo"] is None or (auto and fingerprint(root) != _cache["fp"]):
            _cache["repo"], _cache["fp"] = load(root), fingerprint(root)
        return _cache["repo"]


def require_key(x_api_key: str | None = Header(default=None)) -> None:
    key = os.environ.get("TRM_API_KEY")
    if key and not secrets.compare_digest((x_api_key or "").encode(), key.encode()):
        raise HTTPException(status_code=401, detail="missing or invalid X-API-Key")


AsOf = Query(None, description="Report date (YYYY-MM-DD) for derived lifecycle/review fields. Defaults to today.")


def _as_of(v: date | None) -> date:
    return v or date.today()


def _filter(rows: list[dict], **criteria: str | None) -> list[dict]:
    for key, want in criteria.items():
        if want is not None:
            rows = [r for r in rows if str(r.get(key) or "").lower() == want.lower()]
    return rows


@app.get("/health", tags=["system"])
def health() -> dict:
    repo = get_repo()
    return {"status": "ok", "version": __version__,
            "records": {ds: len(getattr(repo, ds)) for ds in DATASETS},
            "errors": sum(i.level == "error" for i in repo.issues)}


v1 = APIRouter(prefix="/v1", dependencies=[Depends(require_key)])


# ------------------------------------------------------------ core datasets
@v1.get("/taxonomy", tags=["taxonomy"])
def list_taxonomy(domain: str | None = None, area: str | None = None, category: str | None = None,
                  status: str | None = Query(None, description="Active | Proposed | Retired"),
                  repo: Repository = Depends(get_repo)):
    return _filter(service.taxonomy_rows(repo), domain=domain, area=area, category=category, status=status)


@v1.get("/taxonomy/{trm_id}", tags=["taxonomy"])
def get_taxonomy(trm_id: str, as_of: date | None = AsOf, repo: Repository = Depends(get_repo)):
    node = next((r for r in service.taxonomy_rows(repo) if r["trm_id"] == trm_id), None)
    if node is None:
        raise HTTPException(404, f"{trm_id} not found")
    techs = [r for r in service.technology_rows(repo, _as_of(as_of)) if r["trm_id"] == trm_id]
    return {**node, "narrative": repo.narratives.get(("taxonomy", trm_id), ""), "technologies": techs}


@v1.get("/technologies", tags=["technologies"])
def list_technologies(
    domain: str | None = None, area: str | None = None, category: str | None = None,
    status: str | None = Query(None, description="Invest | Maintain | Disinvest"),
    entity: str | None = None, sme: str | None = None, it_owner: str | None = None,
    support_team: str | None = None,
    as_of: date | None = AsOf, repo: Repository = Depends(get_repo),
):
    rows = service.technology_rows(repo, _as_of(as_of))
    return _filter(rows, domain=domain, area=area, category=category, status=status, entity=entity,
                   sme=sme, it_owner=it_owner, support_team=support_team)


@v1.get("/technologies/{tech_id}", tags=["technologies"])
def get_technology(tech_id: str, as_of: date | None = AsOf, repo: Repository = Depends(get_repo)):
    d = _as_of(as_of)
    tech = next((r for r in service.technology_rows(repo, d) if r["tech_id"] == tech_id), None)
    if tech is None:
        raise HTTPException(404, f"{tech_id} not found")
    return {
        **tech,
        "narrative": repo.narratives.get(("technologies", tech_id), ""),
        "versions": [r for r in service.version_rows(repo, d) if r["tech_id"] == tech_id],
        "applications": [r for r in service.mapping_rows(repo, d) if r["tech_id"] == tech_id],
    }


@v1.get("/versions", tags=["versions"])
def list_versions(tech_id: str | None = None, lifecycle_state: str | None = None,
                  as_of: date | None = AsOf, repo: Repository = Depends(get_repo)):
    return _filter(service.version_rows(repo, _as_of(as_of)), tech_id=tech_id, lifecycle_state=lifecycle_state)


@v1.get("/mappings", tags=["mappings"])
def list_mappings(tech_id: str | None = None, application_id: str | None = None,
                  risk_rating: str | None = Query(None, description="High | Medium | Low"),
                  lifecycle_state: str | None = None, as_of: date | None = AsOf,
                  repo: Repository = Depends(get_repo)):
    return _filter(service.mapping_rows(repo, _as_of(as_of)), tech_id=tech_id, application_id=application_id,
                   risk_rating=risk_rating, lifecycle_state=lifecycle_state)


@v1.get("/applications/{application_id}/technologies", tags=["mappings"])
def application_technologies(application_id: str, as_of: date | None = AsOf, repo: Repository = Depends(get_repo)):
    rows = [r for r in service.mapping_rows(repo, _as_of(as_of)) if r["application_id"] == application_id]
    if not rows:
        raise HTTPException(404, f"{application_id} has no mappings")
    return {"application_id": application_id, "application_name": rows[0]["application_name"], "technologies": rows}


# ------------------------------------------------------------ reports / MI
@v1.get("/reports/summary", tags=["reports"])
def report_summary(as_of: date | None = AsOf, repo: Repository = Depends(get_repo)):
    return service.summary(repo, _as_of(as_of))


@v1.get("/reports/lifecycle-risk", tags=["reports"])
def report_lifecycle_risk(as_of: date | None = AsOf, repo: Repository = Depends(get_repo)):
    return service.lifecycle_risk(repo, _as_of(as_of))


@v1.get("/reports/disinvest-exposure", tags=["reports"])
def report_disinvest_exposure(as_of: date | None = AsOf, repo: Repository = Depends(get_repo)):
    return service.disinvest_exposure(repo, _as_of(as_of))


@v1.get("/reports/taxonomy-coverage", tags=["reports"])
def report_taxonomy_coverage(repo: Repository = Depends(get_repo)):
    return service.taxonomy_coverage(repo)


# ------------------------------------------------------------ AI / tooling
@v1.get("/search", tags=["ai"])
def search(q: str = Query(..., min_length=2), repo: Repository = Depends(get_repo)):
    return service.search(repo, q)


@v1.get("/raw/{dataset}/{record_id}", tags=["ai"], response_class=PlainTextResponse)
def raw_markdown(dataset: str, record_id: str, repo: Repository = Depends(get_repo)):
    """The original markdown source file (JSON record + narrative), e.g. /v1/raw/technologies/TECH-0001."""
    path = repo.sources.get((dataset, record_id))  # looked up, never built from user input
    if path is None:
        raise HTTPException(404, "no such file")
    return PlainTextResponse(path.read_text(encoding="utf-8"), media_type="text/markdown")


@v1.get("/validate", tags=["system"])
def validate(repo: Repository = Depends(get_repo)):
    issues = all_issues(repo)
    return {"errors": sum(i.level == "error" for i in issues),
            "warnings": sum(i.level == "warning" for i in issues),
            "issues": [i.as_dict() for i in issues]}


# ------------------------------------------------------------ CSV export
@v1.get("/export/{dataset}.csv", tags=["export"], response_class=Response)
def export_csv(dataset: str, as_of: date | None = AsOf, repo: Repository = Depends(get_repo)):
    """CSV for Power BI / Excel. Datasets: taxonomy, technologies, versions, mappings."""
    if dataset not in service.COLUMNS:
        raise HTTPException(404, f"unknown dataset '{dataset}'; use one of {sorted(service.COLUMNS)}")
    body = to_csv(service.dataset_rows(repo, dataset, _as_of(as_of)), service.COLUMNS[dataset])
    return Response(body, media_type="text/csv",
                    headers={"Content-Disposition": f'inline; filename="{dataset}.csv"'})


app.include_router(v1)
