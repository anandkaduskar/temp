# Technology Reference Model: GitLab Governance Workflow (Proposal)

**Status:** Draft for discussion | **Scope:** how TRM data is changed, approved, published and audited once it lives in GitLab.

## 1. Principles

1. **ARC decides, Git records.** The Architecture Review Council (ARC) is the only authority to change a technology's investment status, add a technology or change the taxonomy. A merge request (MR) *executes* an ARC decision; it never substitutes for one.
2. **`main` is the approved state.** Nothing reaches `main` except through an approved MR. The API, CSV exports and Power BI report on `main` only.
3. **One record, one file.** Small files give small diffs, few conflicts and a readable `git log` for each technology or application.
4. **Rules are enforced by CI, not by memory.** Schema, references and ID rules are checked on every MR.
5. **Light path for routine change.** Vendor date updates and application mapping updates do not need an ARC meeting.

## 2. Roles

| Role | Who | Responsibility |
|---|---|---|
| IT Owner / SME | Named per technology (`it_owner`, `sme` fields) | IT Owner is accountable for the technology; both keep versions and EOL/EOS dates current |
| Application Owner | Per application | Keeps `data/mappings/APP-xxxx.md` accurate |
| Submitter | Architect or owner raising the change | Prepares ARC paper, raises MR citing the ARC reference |
| ARC | Architecture Review Council | Decides status changes, new technologies, taxonomy changes |
| ARC Secretariat | ARC secretary | Records the decision and ARC reference; approves status-bearing MRs |
| TRM Custodian | EA team | Owns the repository, reviews every MR for data quality, maintains CI and API |

## 3. Change types

| Change | Example | Files | ARC needed? | Approvals |
|---|---|---|---|---|
| **Status change** | Qlik Sense: Invest → Disinvest | `technologies/` | **Yes** | Custodian + ARC Secretariat |
| **New technology** | Add MongoDB | `technologies/`, `versions/`, maybe `taxonomy/` | **Yes** | Custodian + ARC Secretariat |
| **Taxonomy change** | New sub category | `taxonomy/` | **Yes** | Custodian + ARC Secretariat |
| **Version / lifecycle update** | Vendor moves an EOS date; new release registered | `versions/` | No (standard change) | Custodian |
| **Application mapping update** | App upgrades PostgreSQL 15 → 17 | `mappings/` | No; **ARC exception** for a *new* use of a Disinvest technology | Custodian |

## 4. Status change workflow (the ARC-gated path)

```mermaid
flowchart TD
  A[Submitter prepares ARC paper] --> B{ARC decision}
  B -- Rejected or deferred --> X[No Git change]
  B -- Approved --> C[ARC Secretariat records decision and ARC reference]
  C --> D[Submitter branches from main and edits technology file]
  D --> E[Opens MR from Status_Change template, citing ARC reference]
  E --> F[CI: validate schema, references, IDs]
  F -- fails --> D
  F -- passes --> G[Custodian checks MR matches the ARC minute]
  G --> H[ARC Secretariat approves]
  H --> I[Squash merge to main]
  I --> J[Pipeline: CSV snapshot, API image, deploy]
  J --> K[API and Power BI show new status]
```

**What the MR must contain** for a status change to `data/technologies/TECH-xxxx.md`:

| Field | Change |
|---|---|
| `status` | New status exactly as decided by ARC |
| `comments` | Starts with the ARC decision reference and a one-line summary, e.g. `ARC-2026-014: Disinvest. No new applications.` |
| Narrative | Standard position, rationale and guidance updated |

For a move **to Disinvest**, the MR description should link follow-up MRs (or issues) that give every affected application a `planned_retirement_date`. This is what turns a strategy decision into measurable exposure in the MI reports.

**Allowed status transitions** (proposed): Invest ↔ Maintain, Maintain → Disinvest, Invest → Disinvest. A later phase adds a terminal **Retired** status, set once no application maps to the technology, so history stays in Git rather than disappearing with a deleted file.

## 5. Routine change paths

**Version / lifecycle update (no ARC).** Technology owner opens an MR from `Version_Update` editing `data/versions/TECH-xxxx.md`. Date changes must link the vendor lifecycle page. Custodian approves. Typical triggers: a new vendor release, a vendor extending or shortening support.

**Application mapping update (no ARC).** Application owner opens an MR from `Application_Mapping`. CI proves the technology and version exist in the TRM. If a team wants to adopt a technology that is already **Disinvest**, the MR must cite an ARC exception reference. In the MVP the custodian checks this by eye; Phase 2 enforces it in CI (see §8).

**Bulk load and migration (loaders).** For the initial population, or a large refresh from a spreadsheet, a custodian runs the importers (`python -m trm_api.import_csv --taxonomy ... --technologies ... --versions ... --mappings ...`; `--dry-run` first) on a branch. The importers write the md files, so the result is reviewed as an ordinary MR and the normal approvals apply. A bulk change to `taxonomy/` or `technologies/` still needs its ARC reference: the importer does not bypass governance, it only produces the files. Re-importing is safe: unchanged files are not touched, so the MR diff shows only real changes. Versions and mappings merge into existing files and nothing is deleted unless `--replace` is used, so a `--replace` import must be called out in the MR description.

## 6. GitLab configuration

**Repository layout** (this folder): `data/` (four dataset folders), `api/` (FastAPI service and validator), `docs/`, `.gitlab/` (CODEOWNERS, MR templates), `.gitlab-ci.yml`, `Dockerfile`.

**Branches and MRs**
- Branch names: `trm/TECH-0004-status-disinvest`, `trm/TECH-0003-add-version-17`, `trm/APP-1005-upgrade-postgres`.
- MR titles: `[STATUS] TECH-0004 Qlik Sense: Invest → Disinvest (ARC-2025-044)`; prefixes `[STATUS]`, `[NEW]`, `[VERSION]`, `[MAPPING]`, `[REVIEW]`, `[TAXONOMY]`.
- Merge method: **squash**, so each ARC decision or routine change is one commit on `main`.
- Rollback: a `git revert` MR through the same process.

**Protected `main`** (some settings need GitLab Premium; confirm your tier)
- No direct push; merge allowed for Maintainers (TRM Custodians).
- "Pipelines must succeed" on; "Remove all approvals when commits are added" on.
- "Prevent approval by author" on, so submitters cannot approve their own MR.
- Code owner approval required, using `.gitlab/CODEOWNERS`: two sections. A change under `data/technologies/` or `data/taxonomy/` needs the **Custodians and the ARC Secretariat**; changes under `data/versions/` or `data/mappings/` need only the **Custodians**.

**Pipeline** (`.gitlab-ci.yml`)

| Stage | Job | Runs on | Effect |
|---|---|---|---|
| validate | `validate-data` | every MR and `main` | Fails the MR on any schema, reference, duplicate or filename error; prints warnings |
| validate | `test-api` | when `api/` changes | Unit, API and loader tests against frozen fixtures |
| validate | `test-dashboard` | when `dashboard/` or `api/` changes | Starts the API on frozen sample data and drives the Streamlit app headlessly |
| publish | `export-csv` | `main` | Publishes the four CSV files as a pipeline artifact (audit evidence and file-based Power BI feed) |
| publish | `deploy-api` (stub) | `main` | Builds the image with `data/` baked in and rolls it out, so the deployed API always equals approved `main` |

## 7. Audit and reporting

- **Traceability chain:** ARC paper → ARC reference → MR → commit → deployed API. The ARC reference is written into the record's `comments`, so the chain survives outside GitLab (for example in a CSV given to an auditor or regulator).
- **Point-in-time view:** `git log -p data/technologies/TECH-0001.md` shows every status change with author, approver and date. Tag `main` monthly (`trm-2026.12`) so any month-end state can be rebuilt.
- **MI:** the API computes lifecycle state and risk from the vendor dates at query time. `?as_of=YYYY-MM-DD` reproduces a historical view from a tagged snapshot.
- **Dashboard:** the Streamlit dashboard reads only from the API (never from the files), so it shows the approved state of `main` once deployed, the same numbers Power BI gets. Its report-date control uses `as_of`, so a tagged month-end can be viewed as it was.

## 8. Roll-out

| Phase | Content |
|---|---|
| **0. MVP (this folder)** | Four datasets as markdown/JSON, validator, FastAPI, CSV export, **loaders for all four datasets (CSV / Excel)**, **Streamlit MI dashboard**, sample for Databases and BI tools |
| **1. GitLab governance** | Create project, set up groups for CODEOWNERS, enable protections and MR templates, run `validate-data` in CI, wire the deploy job |
| **2. Hardening** | CI "diff-guard": a changed `status` must also add an ARC reference to `comments`; a new mapping to a Disinvest technology needs an exception reference; Retired status |
| **3. Integration** | Source application list and mappings from the ServiceNow CMDB (the mappings loader already takes any application ID, so a CMDB export can feed it) instead of hand-maintained files; host the dashboard next to the API (OpenShift); surface TRM in the architecture portal; API access for AI assistants through a thin MCP wrapper |

## 9. Decisions needed

1. Who is the ARC Secretariat approver, and what is the target turnaround between an ARC decision and the MR merging?
2. Is "Maintain" a formal status alongside Invest and Disinvest? The data model supports it; confirm it matches ARC policy.
3. Does your GitLab licence include code owner approvals and approval settings (Premium)? If not, fall back to merge permissions plus a mandatory reviewer in the MR template.
4. Until the CMDB feed exists, who owns each `mappings/` file: the application owner or the EA team?
5. Confirm the EOL / EOS definitions in `DATA_MODEL.md` match how your organisation uses the terms.
