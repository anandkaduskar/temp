# TRM Data Model

## File convention
Every record file is a markdown file with **exactly one** fenced `json` block (the machine-readable record) and optional prose (rationale, guidance) that the API returns as `narrative` for AI consumers and humans.

```
data/
  taxonomy/      TRM-DB-001.md     one file per taxonomy node
  technologies/  TECH-0001.md      one file per technology
  versions/      TECH-0001.md      all versions of one technology
  mappings/      APP-1001.md       all technologies used by one application
```
File names must equal the ID in the file (CI enforces it). Files starting with `_` are ignored. Dates are ISO `YYYY-MM-DD`. Unknown fields are rejected.

```mermaid
erDiagram
  TAXONOMY ||--o{ TECHNOLOGY : classifies
  TECHNOLOGY ||--o{ VERSION : has
  TECHNOLOGY ||--o{ MAPPING : "used via"
  VERSION ||--o{ MAPPING : "in use"
  APPLICATION ||--o{ MAPPING : uses
```

## 1. Taxonomy (`data/taxonomy/TRM-DB-001.md`)
| Field | Req | Notes |
|---|---|---|
| `trm_id` | yes | `TRM-<domain code>-<nnn>` |
| `domain`, `category`, `sub_category` | yes | Three-level classification |

## 2. Technology (`data/technologies/TECH-0001.md`)
| Field | Req | Notes |
|---|---|---|
| `tech_id` | yes | `TECH-nnnn` |
| `name` | yes | |
| `trm_id` | yes | Must exist in taxonomy |
| `investment_status` | yes | `Invest`, `Maintain` or `Disinvest` |
| `owner` | yes | Role or person accountable |
| `review_date` | yes | Date last reviewed |
| `next_review_date` | yes | Must be after `review_date` |
| `vendor`, `licence_model` | no | `Commercial`, `Open Source`, `SaaS` |
| `arc_ref` | no* | `ARC-yyyy-nnn`; *warning if missing, enforced on change in Phase 2 |
| `status_effective_date` | no | When the current status took effect |

## 3. Technology version (`data/versions/TECH-0001.md`)
Container: `{"tech_id": "...", "versions": [ ... ]}`

| Field | Req | Notes |
|---|---|---|
| `version_id` | yes | `TECH-nnnn-Vnnn` |
| `version` | yes | As the vendor names it ("19c", "November 2024") |
| `eol_date` | no | **End of life**: end of standard/mainstream vendor support |
| `eos_date` | no | **End of support**: end of all vendor support incl. paid extended |
| `details` | no | Source, caveats, internal guidance |

Leave both dates `null` for evergreen SaaS or when not yet captured. Where a vendor has one date only (community PostgreSQL, Qlik), set both to it. If your organisation defines EOL and EOS differently, change the labels in one place (`models.py` and this file); the logic only needs "first date" and "last date".

## 4. Technology-to-application mapping (`data/mappings/APP-1001.md`)
Container: `{"application_id": "...", "application_name": "...", "mappings": [ ... ]}`

| Field | Req | Notes |
|---|---|---|
| `mapping_id` | yes | `MAP-<app nnnn>-<nn>` |
| `tech_id`, `version` | yes | Must match a registered technology version |
| `environments` | yes | List of `Prod`, `DR`, `UAT`, `Test`, `Dev` |
| `usage` | yes | What the technology does for the application |
| `planned_retirement_date` | no | Expected last day of use; expected for Disinvest technologies |
| `notes` | no | |

Application master data (ID, name) is not a fifth dataset in the MVP; it is carried on the mapping file and later sourced from the CMDB.

## Derived fields (computed by the API, never stored)
| Field | Rule |
|---|---|
| `lifecycle_state` | `Out of Support` (EOS passed) / `Past End of Life` (EOL passed, EOS not) / `Nearing End of Life` (next date within 365 days) / `Supported` / `Not Dated` |
| `review_state` | `Overdue` / `Due Soon` (within 60 days) / `Current` |
| `risk_rating` (mapping) | **High**: Out of Support. **Medium**: Past or Nearing EOL, or the technology is Disinvest. **Low**: otherwise |
| `days_to_eol`, `days_to_eos`, `days_to_next_review` | Relative to `as_of` (default today) |
| `application_count`, `version_count`, `technology_count` | Joins |
