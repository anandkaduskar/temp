from datetime import date
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

APP = str(Path(__file__).resolve().parents[1] / "app.py")
AS_OF = date(2026, 11, 12)


def run(url, key="", as_of=AS_OF, monkeypatch=None):
    monkeypatch.setenv("TRM_API_URL", url)
    monkeypatch.setenv("TRM_API_KEY", key)
    at = AppTest.from_file(APP, default_timeout=60)
    at.run()
    if not at.exception and not at.error:
        at.sidebar.date_input[0].set_value(as_of)
        at.run()
    return at


def metrics(at):
    out = {}
    for m in at.metric:
        out.setdefault(m.label, m.value)  # first occurrence wins (overview KPIs before drill-down metrics)
    return out


@pytest.fixture(autouse=True)
def _clear_cache():
    from streamlit.runtime.caching import cache_data_api  # noqa: F401
    import streamlit as st
    st.cache_data.clear()


def test_renders_all_tabs_with_correct_numbers(api_url, monkeypatch):
    at = run(api_url, monkeypatch=monkeypatch)
    assert not at.exception, at.exception
    assert [t.label for t in at.tabs] == ["Overview", "Technology landscape", "Lifecycle & risk",
                                          "Disinvest exposure", "Applications", "Data quality"]
    m = metrics(at)
    assert (m["Technologies"], m["Invest"], m["Maintain"], m["Disinvest"], m["Applications"]) == ("6", "3", "0", "3", "7")
    assert m["High-risk usages"] == "2"
    assert m["Applications exposed"] == "5" and m["Applications with no retirement date"] == "1"
    assert m["Errors"] == "0" and m["Warnings"] == "1" and m["Taxonomy nodes with no technology"] == "1"
    assert len(at.dataframe) >= 8


def test_landscape_filter_and_drilldown(api_url, monkeypatch):
    at = run(api_url, monkeypatch=monkeypatch)
    status = next(w for w in at.multiselect if w.label == "Status")
    status.set_value(["Disinvest"])
    at.run()
    assert not at.exception, at.exception
    assert any("3 of 6 technologies" in c.value for c in at.caption)
    pick = next(s for s in at.selectbox if s.label == "Drill into a technology")
    pick.select("TECH-0004")
    at.run()
    assert not at.exception, at.exception
    assert "ARC-2025-044" in " ".join(i.value for i in at.info)
    assert any("Qlik" in md.value for md in at.markdown)


def test_application_drilldown(api_url, monkeypatch):
    at = run(api_url, monkeypatch=monkeypatch)
    app = next(s for s in at.selectbox if s.label == "Application")
    app.select("APP-1002")
    at.run()
    assert not at.exception, at.exception


def test_unreachable_api_shows_friendly_error(monkeypatch):
    at = run("http://127.0.0.1:9", monkeypatch=monkeypatch)
    assert not at.exception
    assert any("Cannot reach the TRM API" in e.value for e in at.error)
    assert not at.tabs


def test_bad_url_and_wrong_key(keyed_api_url, monkeypatch):
    at = run("not-a-url", monkeypatch=monkeypatch)
    assert any("not a valid URL" in e.value or "Cannot reach" in e.value for e in at.error)
    at = run(keyed_api_url, key="wrong", monkeypatch=monkeypatch)
    assert any("401" in e.value for e in at.error)
    at = run(keyed_api_url, key="s3cret", monkeypatch=monkeypatch)
    assert not at.exception and not at.error and metrics(at)["Technologies"] == "6"
