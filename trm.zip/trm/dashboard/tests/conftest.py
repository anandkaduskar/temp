"""Spins up the real FastAPI service (on frozen sample data) so the dashboard is tested end to end."""
import os
import socket
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path

import pytest
import requests

API_DIR = Path(__file__).resolve().parents[2] / "api"
SAMPLE = API_DIR / "tests" / "fixtures" / "sample_data"


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@contextmanager
def api_server(api_key: str = ""):
    port = _free_port()
    env = {**os.environ, "TRM_DATA_DIR": str(SAMPLE), "TRM_API_KEY": api_key}
    proc = subprocess.Popen([sys.executable, "-m", "uvicorn", "trm_api.main:app", "--port", str(port), "--log-level", "warning"],
                            cwd=API_DIR, env=env)
    url = f"http://127.0.0.1:{port}"
    try:
        for _ in range(60):
            try:
                if requests.get(f"{url}/health", timeout=1).ok:
                    break
            except requests.RequestException:
                time.sleep(0.25)
        else:
            raise RuntimeError("API did not start")
        yield url
    finally:
        proc.terminate()
        proc.wait(timeout=10)


@pytest.fixture(scope="session")
def api_url():
    with api_server() as url:
        yield url


@pytest.fixture()
def keyed_api_url():
    with api_server("s3cret") as url:
        yield url
