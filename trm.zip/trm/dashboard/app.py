"""TRM Management Information dashboard (Streamlit). Reads everything from the TRM FastAPI service.

    streamlit run app.py          (from the dashboard/ folder)
Env: TRM_API_URL (default http://localhost:8080), TRM_API_KEY (optional)
"""
from __future__ import annotations

import os
from datetime import date

import altair as alt
import pandas as pd
import streamlit as st

from trm_client import TRMApiError, TRMClient

st.set_page_config(page_title="TRM Management Information", page_icon=":material/hub:", layout="wide")

STATUS_ORDER = ["Invest", "Maintain", "Disinvest"]
STATUS_COLORS = ["#2a9d8f", "#e9c46a", "#e76f51"]
STATE_ORDER = ["Supported", "Nearing End of Life", "Past End of Life", "Out of Support", "Not Dated"]
STATE_COLORS = ["#2a9d8f", "#e9c46a", "#f4a261", "#d62828", "#adb5bd"]
RISK_ORDER = ["High", "Medium", "Low"]
RISK_COLORS = ["#d62828", "#f4a261", "#2a9d8f"]


def scale(domain: list[str], colors: list[str]) -> alt.Scale:
    return alt.Scale(domain=domain, range=colors)


def show_chart(chart: alt.Chart) -> None:
    try:
        st.altair_chart(chart, width="stretch")
    except TypeError:  # older Streamlit
        st.altair_chart(chart, use_container_width=True)


def show_df(df: pd.DataFrame, **kw) -> None:
    try:
        st.dataframe(df, width="stretch", hide_index=True, **kw)
    except TypeError:
        st.dataframe(df, use_container_width=True, hide_index=True, **kw)


def frame(rows: list[dict], cols: list[str] | None = None) -> pd.DataFrame:
    df = pd.DataFrame(rows)
    if cols:
        for c in cols:
            if c not in df:
                df[c] = None
        df = df[cols]
    return df


def flatten(df: pd.DataFrame) -> pd.DataFrame:
    """Lists (e.g. environments) -> 'Prod, DR' so tables and CSVs stay readable."""
    out = df.copy()
    for c in out.columns:
        if out[c].map(lambda v: isinstance(v, list)).any():
            out[c] = out[c].map(lambda v: ", ".join(v) if isinstance(v, list) else v)
    return out


# ------------------------------------------------------------------ sidebar / data access
with st.sidebar:
    st.title("TRM MI")
    api_url = st.text_input("API URL", os.environ.get("TRM_API_URL", "http://localhost:8080"))
    api_key = st.text_input("API key (optional)", os.environ.get("TRM_API_KEY", ""), type="password")
    as_of = st.date_input("Report date", value=date.today(), help="Lifecycle states and days-to-date are computed as of this date.")
    if st.button("Refresh data"):
        st.cache_data.clear()


@st.cache_data(ttl=60, show_spinner=False)
def fetch(url: str, key: str, path: str, params: tuple):
    return TRMClient(url, key).json(path, **dict(params))


@st.cache_data(ttl=60, show_spinner=False)
def fetch_text(url: str, key: str, path: str) -> str:
    return TRMClient(url, key).text(path)


@st.cache_data(ttl=60, show_spinner=False)
def fetch_csv(url: str, key: str, dataset: str, as_of_iso: str) -> bytes:
    return TRMClient(url, key).csv_bytes(dataset, as_of=as_of_iso)


def load(path: str, **params):
    return fetch(api_url, api_key, path, tuple(sorted({**params, "as_of": as_of.isoformat()}.items())))


try:
    health = fetch(api_url, api_key, "/health", ())
    summary = load("/v1/reports/summary")
    tech_rows = load("/v1/technologies")
    version_rows = load("/v1/versions")
    mapping_rows = load("/v1/mappings")
    risk_rows = load("/v1/reports/lifecycle-risk")
    exposure_rows = load("/v1/reports/disinvest-exposure")
    coverage_rows = load("/v1/reports/taxonomy-coverage")
    validation = load("/v1/validate")
except TRMApiError as exc:
    st.error(str(exc))
    st.caption("Start the API with `python -m uvicorn trm_api.main:app --port 8080` from the `api` folder, "
               "or change the API URL in the sidebar.")
    st.stop()

techs = frame(tech_rows)
versions = frame(version_rows)
mappings = frame(mapping_rows)

with st.sidebar:
    st.caption(f"API v{health['version']} · {health['records']['technologies']} technologies · "
               f"{health['records']['mappings']} mappings")
    st.divider()
    st.subheader("Download CSV")
    for ds in ("taxonomy", "technologies", "versions", "mappings"):
        try:
            st.download_button(f"{ds}.csv", fetch_csv(api_url, api_key, ds, as_of.isoformat()), file_name=f"{ds}.csv",
                               mime="text/csv", key=f"dl_{ds}")
        except TRMApiError as exc:
            st.caption(str(exc))

st.title("Technology Reference Model: Management Information")
st.caption(f"As of {as_of.isoformat()} · lifecycle dates are vendor dates recorded in the TRM")

tab_overview, tab_landscape, tab_risk, tab_disinvest, tab_apps, tab_quality = st.tabs(
    ["Overview", "Technology landscape", "Lifecycle & risk", "Disinvest exposure", "Applications", "Data quality"])

# ------------------------------------------------------------------ Overview
with tab_overview:
    by_status = summary["technologies_by_status"]
    risk = summary["mapping_risk"]
    cols = st.columns(6)
    cols[0].metric("Technologies", summary["counts"]["technologies"])
    cols[1].metric("Invest", by_status.get("Invest", 0))
    cols[2].metric("Maintain", by_status.get("Maintain", 0))
    cols[3].metric("Disinvest", by_status.get("Disinvest", 0))
    cols[4].metric("Applications", summary["counts"]["applications"])
    cols[5].metric("High-risk usages", risk.get("High", 0),
                   help="Application-technology pairs running a version that is out of vendor support.")

    left, right = st.columns(2)
    with left:
        st.subheader("Technologies by domain and status")
        d = frame(summary["technologies_by_domain_status"], ["domain", "status", "count"])
        show_chart(alt.Chart(d).mark_bar().encode(
            x=alt.X("domain:N", title=None, axis=alt.Axis(labelAngle=0)),
            y=alt.Y("count:Q", title="Technologies", axis=alt.Axis(tickMinStep=1)),
            color=alt.Color("status:N", scale=scale(STATUS_ORDER, STATUS_COLORS), sort=STATUS_ORDER, title="Status"),
            tooltip=["domain", "status", "count"]).properties(height=300))
    with right:
        st.subheader("Versions by vendor lifecycle state")
        d = pd.DataFrame({"state": list(summary["versions_by_lifecycle_state"]),
                          "versions": list(summary["versions_by_lifecycle_state"].values())})
        show_chart(alt.Chart(d).mark_bar().encode(
            y=alt.Y("state:N", sort=STATE_ORDER, title=None),
            x=alt.X("versions:Q", title="Versions", axis=alt.Axis(tickMinStep=1)),
            color=alt.Color("state:N", scale=scale(STATE_ORDER, STATE_COLORS), legend=None),
            tooltip=["state", "versions"]).properties(height=300))

    left, right = st.columns(2)
    with left:
        st.subheader("Usage risk by domain")
        if not mappings.empty:
            d = mappings.groupby(["domain", "risk_rating"]).size().reset_index(name="usages")
            show_chart(alt.Chart(d).mark_bar().encode(
                x=alt.X("domain:N", title=None, axis=alt.Axis(labelAngle=0)),
                y=alt.Y("usages:Q", title="Application-technology usages", axis=alt.Axis(tickMinStep=1)),
                color=alt.Color("risk_rating:N", scale=scale(RISK_ORDER, RISK_COLORS), sort=RISK_ORDER, title="Risk"),
                tooltip=["domain", "risk_rating", "usages"]).properties(height=300))
        else:
            st.info("No application mappings yet.")
    with right:
        st.subheader("Top risks")
        st.caption("High first, then Medium; sorted by days to end of support.")
        cols_r = ["application_name", "technology_name", "version", "lifecycle_state", "risk_rating", "days_to_eos"]
        show_df(frame(risk_rows[:10], cols_r))

# ------------------------------------------------------------------ Landscape
with tab_landscape:
    st.subheader("Technology landscape")
    f = st.columns(5)
    pick = {
        "domain": f[0].multiselect("Domain", sorted(techs["domain"].dropna().unique())),
        "area": f[1].multiselect("Area", sorted(techs["area"].dropna().unique())),
        "status": f[2].multiselect("Status", STATUS_ORDER),
        "entity": f[3].multiselect("Entity", sorted(techs["entity"].dropna().unique())),
        "it_owner": f[4].multiselect("IT owner", sorted(techs["it_owner"].dropna().unique())),
    }
    view = techs
    for col, chosen in pick.items():
        if chosen:
            view = view[view[col].isin(chosen)]
    cols_t = ["tech_id", "technology_name", "entity", "domain", "area", "category", "status", "sme", "it_owner",
              "support_team", "version_count", "application_count", "comments"]
    show_df(frame(view.to_dict("records"), cols_t))
    st.caption(f"{len(view)} of {len(techs)} technologies")

    if not view.empty:
        labels = {r["tech_id"]: f'{r["technology_name"]} ({r["tech_id"]})' for r in view.to_dict("records")}
        chosen_id = st.selectbox("Drill into a technology", list(labels), format_func=labels.get)
        detail = load(f"/v1/technologies/{chosen_id}")
        m = st.columns(4)
        m[0].metric("Status", detail["status"])
        m[1].metric("Applications", detail["application_count"])
        m[2].metric("Versions", detail["version_count"])
        m[3].metric("Classification", f'{detail["area"]} › {detail["category"]}')
        st.write(f'**IT owner:** {detail["it_owner"]} · **SME:** {detail.get("sme") or "n/a"} · '
                 f'**Support team:** {detail.get("support_team") or "n/a"} · **Entity:** {detail["entity"]}')
        if detail.get("comments"):
            st.info(detail["comments"])
        st.markdown("**Versions**")
        show_df(frame(detail["versions"], ["version", "eol_date", "eos_date", "lifecycle_state", "application_count", "details"]))
        st.markdown("**Applications using it**")
        show_df(flatten(frame(detail["applications"], ["application_id", "application_name", "version", "environments",
                                                        "usage", "lifecycle_state", "risk_rating", "planned_retirement_date"])))
        with st.expander("Rationale and guidance (from the markdown file)"):
            st.markdown(detail.get("narrative") or "_No narrative recorded._")
        with st.expander("Source file"):
            try:
                st.code(fetch_text(api_url, api_key, f"/v1/raw/technologies/{chosen_id}"), language="markdown")
            except TRMApiError as exc:
                st.caption(str(exc))

# ------------------------------------------------------------------ Lifecycle & risk
with tab_risk:
    st.subheader("Where applications run versions that are ending support")
    f = st.columns(3)
    sel_risk = f[0].multiselect("Risk rating", RISK_ORDER, default=["High", "Medium"])
    sel_state = f[1].multiselect("Lifecycle state", STATE_ORDER)
    in_use_only = f[2].checkbox("Timeline: only versions in use", value=True)

    rv = mappings
    if not rv.empty:
        if sel_risk:
            rv = rv[rv["risk_rating"].isin(sel_risk)]
        if sel_state:
            rv = rv[rv["lifecycle_state"].isin(sel_state)]
    cols_m = ["application_name", "technology_name", "version", "technology_status", "lifecycle_state", "risk_rating",
              "eol_date", "eos_date", "days_to_eos", "planned_retirement_date", "environments"]
    show_df(flatten(frame(rv.to_dict("records"), cols_m)))
    st.caption("Risk: High = out of vendor support. Medium = past or nearing end of life, or the technology is Disinvest.")

    st.subheader("Vendor support timeline")
    tv = versions.copy()
    if not tv.empty:
        tv["label"] = tv["technology_name"] + " " + tv["version"]
        tv["eol"] = pd.to_datetime(tv["eol_date"], errors="coerce")
        tv["eos"] = pd.to_datetime(tv["eos_date"], errors="coerce")
        tv["start"] = tv["eol"].fillna(tv["eos"])
        tv["end"] = tv["eos"].fillna(tv["eol"])
        dated = tv[tv["start"].notna()]
        if in_use_only:
            dated = dated[dated["application_count"] > 0]
        undated = len(tv) - int(tv["start"].notna().sum())
        if dated.empty:
            st.info("No dated versions to plot.")
        else:
            order = dated.sort_values(["end", "label"])["label"].tolist()
            y = alt.Y("label:N", sort=order, title=None)
            color = alt.Color("lifecycle_state:N", scale=scale(STATE_ORDER, STATE_COLORS), sort=STATE_ORDER, title="State")
            tip = ["label", "lifecycle_state", "eol_date", "eos_date", "application_count"]
            base = alt.Chart(dated)
            bars = base.mark_bar(size=12, opacity=0.8).encode(x=alt.X("start:T", title=None), x2="end:T", y=y, color=color, tooltip=tip)
            ends = base.mark_point(filled=True, shape="diamond", size=110).encode(x="end:T", y=y, color=color, tooltip=tip)
            today = alt.Chart(pd.DataFrame({"d": [pd.Timestamp(as_of)]})).mark_rule(color="#333", strokeDash=[4, 3]).encode(x="d:T")
            show_chart(alt.layer(bars, ends, today).properties(height=max(140, 30 * len(dated))))
            st.caption("Bar: from end of life to end of support. Diamond: end of support. Dashed line: report date. "
                       "Where EOL and EOS are the same date only the diamond shows.")
        if undated:
            st.caption(f"{undated} version(s) have no EOL/EOS dates recorded (SaaS or not yet captured) and are not plotted.")

# ------------------------------------------------------------------ Disinvest exposure
with tab_disinvest:
    st.subheader("Applications still dependent on Disinvest technologies")
    if not exposure_rows:
        st.success("No applications are mapped to Disinvest technologies.")
    else:
        apps_exposed = len({a["application_id"] for e in exposure_rows for a in e["applications"]})
        no_date = sorted({a for e in exposure_rows for a in e["applications_without_retirement_date"]})
        m = st.columns(3)
        m[0].metric("Disinvest technologies in use", len(exposure_rows))
        m[1].metric("Applications exposed", apps_exposed)
        m[2].metric("Applications with no retirement date", len(no_date),
                    help=", ".join(no_date) if no_date else "All have a planned retirement date.")
        left, right = st.columns(2)
        with left:
            d = frame(exposure_rows, ["technology_name", "application_count"])
            show_chart(alt.Chart(d).mark_bar(color=STATUS_COLORS[2]).encode(
                y=alt.Y("technology_name:N", sort="-x", title=None),
                x=alt.X("application_count:Q", title="Applications", axis=alt.Axis(tickMinStep=1)),
                tooltip=["technology_name", "application_count"]).properties(height=220))
        with right:
            dm = mappings[mappings["technology_status"] == "Disinvest"].copy() if not mappings.empty else mappings
            dm["year"] = pd.to_datetime(dm["planned_retirement_date"], errors="coerce").dt.year.astype("Int64").astype(str)
            dm["year"] = dm["year"].replace("<NA>", "No date")
            d = dm.groupby("year").size().reset_index(name="usages")
            show_chart(alt.Chart(d).mark_bar(color="#6c757d").encode(
                x=alt.X("year:N", title="Planned retirement year", axis=alt.Axis(labelAngle=0)),
                y=alt.Y("usages:Q", title="Usages", axis=alt.Axis(tickMinStep=1)),
                tooltip=["year", "usages"]).properties(height=220))
        for e in exposure_rows:
            with st.expander(f'{e["technology_name"]}: {e["application_count"]} application(s), '
                             f'last planned retirement {e["last_planned_retirement_date"] or "not set"}'):
                show_df(flatten(frame(e["applications"])))

# ------------------------------------------------------------------ Applications
with tab_apps:
    st.subheader("Application × technology risk map")
    if mappings.empty:
        st.info("No application mappings yet.")
    else:
        hm = mappings.copy()
        hm["tech_version"] = hm["technology_name"] + " " + hm["version"]
        show_chart(alt.Chart(hm).mark_rect(stroke="white", strokeWidth=2).encode(
            x=alt.X("tech_version:N", title=None, axis=alt.Axis(labelAngle=-35)),
            y=alt.Y("application_name:N", title=None),
            color=alt.Color("risk_rating:N", scale=scale(RISK_ORDER, RISK_COLORS), sort=RISK_ORDER, title="Risk"),
            tooltip=["application_name", "technology_name", "version", "lifecycle_state", "risk_rating", "technology_status"]
        ).properties(height=max(200, 38 * hm["application_name"].nunique())))
        apps = sorted(hm[["application_id", "application_name"]].drop_duplicates().itertuples(index=False))
        labels = {a.application_id: f"{a.application_name} ({a.application_id})" for a in apps}
        chosen_app = st.selectbox("Application", list(labels), format_func=labels.get)
        app_detail = load(f"/v1/applications/{chosen_app}/technologies")
        show_df(flatten(frame(app_detail["technologies"], [
            "technology_name", "version", "technology_status", "environments", "usage", "lifecycle_state",
            "risk_rating", "eos_date", "days_to_eos", "planned_retirement_date", "notes"])))

# ------------------------------------------------------------------ Data quality
with tab_quality:
    st.subheader("Repository data quality")
    m = st.columns(3)
    m[0].metric("Errors", validation["errors"])
    m[1].metric("Warnings", validation["warnings"])
    gaps = [c for c in coverage_rows if c["gap"]]
    m[2].metric("Taxonomy nodes with no technology", len(gaps))
    if validation["issues"]:
        show_df(frame(validation["issues"], ["level", "file", "message"]))
    else:
        st.success("No issues found.")
    st.subheader("Taxonomy coverage")
    cov = frame(coverage_rows, ["trm_id", "domain", "area", "category", "status", "technology_count", "technologies", "gap"])
    cov["technologies"] = cov["technologies"].map(lambda v: ", ".join(v) if isinstance(v, list) else v)
    show_df(cov)
