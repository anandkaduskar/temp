"""Thin HTTP client for the TRM FastAPI service. The dashboard talks to the API only, never to the files."""
from __future__ import annotations

from typing import Any

import requests


class TRMApiError(RuntimeError):
    """Raised with a message that is safe to show to the user."""


class TRMClient:
    def __init__(self, base_url: str, api_key: str = "", timeout: float = 15.0, session: Any = None):
        self.base = base_url.strip().rstrip("/")
        self.headers = {"X-API-Key": api_key} if api_key else {}
        self.timeout = timeout
        self.session = session or requests.Session()

    def _get(self, path: str, params: dict | None = None):
        clean = {k: v for k, v in (params or {}).items() if v not in (None, "")}
        try:
            r = self.session.get(f"{self.base}{path}", params=clean, headers=self.headers, timeout=self.timeout)
        except requests.exceptions.MissingSchema as exc:
            raise TRMApiError(f"'{self.base}' is not a valid URL; include http:// or https://") from exc
        except requests.exceptions.RequestException as exc:
            raise TRMApiError(f"Cannot reach the TRM API at {self.base} ({type(exc).__name__}). Is it running?") from exc
        if r.status_code == 401:
            raise TRMApiError("The API rejected the key (401). Check the API key in the sidebar.")
        if r.status_code == 404:
            raise TRMApiError(f"Not found: {path}")
        if not r.ok:
            raise TRMApiError(f"API error {r.status_code} on {path}: {r.text[:200]}")
        return r

    def json(self, path: str, **params):
        return self._get(path, params).json()

    def text(self, path: str, **params) -> str:
        return self._get(path, params).text

    def csv_bytes(self, dataset: str, **params) -> bytes:
        return self._get(f"/v1/export/{dataset}.csv", params).content
