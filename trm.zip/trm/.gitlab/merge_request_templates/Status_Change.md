## ARC decision (required)
- ARC reference: ARC-YYYY-NNN
- ARC meeting date:
- Link to ARC paper / minute:

## Change
| Technology | Current status | New status |
|---|---|---|
| TECH-xxxx | | |

## Checklist
- [ ] `status` updated in `data/technologies/TECH-xxxx.md`
- [ ] `comments` starts with the ARC reference and a one-line summary of the decision
- [ ] Standard position / rationale / guidance text updated
- [ ] If moving to **Disinvest**: affected applications have a `planned_retirement_date` (or a follow-up MR is linked)
- [ ] CI `validate-data` passes
