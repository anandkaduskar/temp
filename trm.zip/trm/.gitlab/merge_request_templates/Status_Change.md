## ARC decision (required)
- ARC reference: ARC-YYYY-NNN
- ARC meeting date:
- Link to ARC paper / minute:

## Change
| Technology | Current status | New status | Effective date |
|---|---|---|---|
| TECH-xxxx | | | |

## Checklist
- [ ] `investment_status`, `status_effective_date` and `arc_ref` updated in `data/technologies/TECH-xxxx.md`
- [ ] `review_date` and `next_review_date` updated
- [ ] Standard position / rationale / guidance text updated
- [ ] If moving to **Disinvest**: affected applications have a `planned_retirement_date` (or a follow-up MR is linked)
- [ ] CI `validate-data` passes
