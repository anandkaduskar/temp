## ARC decision (required)
- ARC reference: ARC-YYYY-NNN
- Link to ARC paper / minute:

## Checklist
- [ ] New `data/technologies/TECH-xxxx.md` (next free ID) with owner, status, review dates and `arc_ref`
- [ ] Taxonomy node exists, or a new `data/taxonomy/TRM-xx-nnn.md` is included
- [ ] At least one version registered in `data/versions/TECH-xxxx.md` with EOL / EOS dates and source
- [ ] CI `validate-data` passes
