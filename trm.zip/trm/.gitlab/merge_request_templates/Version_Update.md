## What changed
- Technology: TECH-xxxx
- [ ] New version added
- [ ] Vendor EOL / EOS date changed
- [ ] Details corrected

## Evidence
Link to the vendor lifecycle page or announcement (required for date changes):

## Checklist
- [ ] `data/versions/TECH-xxxx.md` updated
- [ ] CI `validate-data` passes
