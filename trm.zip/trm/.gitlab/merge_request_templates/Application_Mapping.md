## What changed
- Application: APP-xxxx
- [ ] Technology added
- [ ] Version upgraded
- [ ] Technology removed after migration

## Checklist
- [ ] `data/mappings/APP-xxxx.md` updated; the version exists in `data/versions/`
- [ ] If the technology is **Disinvest**: `planned_retirement_date` set, and ARC exception reference added in the MR if this is a *new* use (`ARC-YYYY-NNN`)
- [ ] CI `validate-data` passes
