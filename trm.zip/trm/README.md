# Technology Reference Model (TRM) — MVP

Git-managed technology standards as **markdown files with a JSON record**, served by a **FastAPI** service for any consumer (apps, AI models, Power BI) and presented in a **Streamlit MI dashboard**.

| Component | What it does | Where |
|---|---|---|
| Data | Four datasets as markdown + JSON, changed only through GitLab MRs and ARC approval | `data/` |
| **Loaders (CSV / Excel importers)** | Bulk-create or update the md files for all four datasets from a sheet; all-or-nothing, idempotent, row-numbered errors | `api/trm_api/import_csv.py`, `samples/` |
| Validator | Schema, referential integrity, duplicates; runs in CI | `api/trm_api/validate.py` |
| FastAPI | Read API, reports, search, CSV export for Power BI | `api/` |
| **Streamlit dashboard** | MI on top of the API: landscape, lifecycle risk, Disinvest exposure, application map, data quality | `dashboard/` |

| Dataset | Source columns | Folder | One file per |
|---|---|---|---|
| Taxonomy | TRM ID, Domain, Area, Category, Status | `data/taxonomy/` | taxonomy node |
| Technologies | Tech ID, Entity, Technology Name, TRM ID, Status, SME, IT Owner, Support Team, comments | `data/technologies/` | technology |
| Technology versions | Tech ID, Version, EOL date, EOS date, details | `data/versions/` | technology (all its versions) |
| Technology-to-application mappings | Application ID, Application Name, Tech ID, Version, environments, usage, retirement date | `data/mappings/` | application |

- Field definitions, rules and derived fields: [`docs/DATA_MODEL.md`](docs/DATA_MODEL.md)
- GitLab / ARC governance proposal: [`docs/GITLAB_WORKFLOW_PROPOSAL.md`](docs/GITLAB_WORKFLOW_PROPOSAL.md)

## Loaders: create the md files from a sheet
Use the loaders for the initial bulk load and for large updates. Day-to-day single changes are still made by editing one md file in an MR.

Load order is taxonomy → technologies → versions → mappings (each is checked against the one before). Pass any subset; all four can go in one run.
```bash
cd api
python -m trm_api.import_csv --make-templates ../templates          # empty CSVs with the exact headers
python -m trm_api.import_csv --taxonomy taxonomy.csv --technologies technologies.csv --versions versions.csv --mappings mappings.csv --dry-run
python -m trm_api.import_csv --taxonomy taxonomy.csv --technologies technologies.csv --versions versions.csv --mappings mappings.csv
python -m trm_api.import_csv --versions trm.xlsx::Versions          # Excel: sheet after '::' (pip install openpyxl)
```
| Dataset | Columns | File written |
|---|---|---|
| taxonomy | TRM ID, Domain, Area, Category, Status | one per TRM ID |
| technologies | Tech ID, Entity, Technology Name, TRM ID, Status, SME, IT Owner, Support Team, comments | one per Tech ID |
| versions | Tech ID, Version, EOL date, EOS date, details (Version ID optional) | one per technology |
| mappings | Application ID, Application Name, Tech ID, Version, Environments, Usage, Planned Retirement Date, Notes (Mapping ID optional) | one per application |

- Header names are matched case-insensitively (`TRM ID`, `trm_id`, `Trm Id` all work). Unknown columns are ignored with a warning.
- Status values are matched case-insensitively. Technology status: `Invest`, `Maintain`, `Disinvest`. Taxonomy status: `Active`, `Proposed`, `Retired`.
- **All-or-nothing:** any invalid row (bad status, missing value, duplicate ID, unknown TRM ID / Tech ID, version not registered, bad date or environment, application name that differs between rows) stops the run, lists every problem with its sheet row number, and writes nothing.
- **Safe to re-run:** unchanged files are not touched, existing prose is kept, only the heading and JSON are rewritten. Files are never deleted.
- **Versions and mappings merge** into the existing file by key (version; technology + version). Entries not in the sheet are kept unless you add `--replace`. Version and mapping IDs are generated for new rows (`TECH-0001-V003`, `MAP-1001-04`) and reused for existing ones.
- **Absent column = leave as is; blank cell = clear.** Re-importing a sheet without a `Notes` column keeps notes; a blank `Usage` cell clears usage.
- **Environments:** one per row or a list (`Prod, DR`); rows for the same application + technology + version are merged. `Production`/`Development` aliases accepted; conflicting values on the same pair are an error.
- **Dates:** `YYYY-MM-DD`, `DD-MM-YYYY`, `DD/MM/YYYY`, `DD-Mon-YYYY` or real Excel dates. Blank, `NA`, `TBD` or `-` mean no date.

## Sample data (read this first)
`data/` holds sample records for **Databases** (Oracle: Disinvest, SQL Server: Invest, PostgreSQL: Invest) and **BI & Analytics** (Qlik Sense: Disinvest, Power BI: Invest, Cognos: Disinvest), plus 7 fictional applications.

- ARC references, entity, SME, IT owner, support team and application names are **illustrative**.
- Oracle 19c / 12.2, IBM Cognos 11.2.x and Qlik Sense release dates were checked against vendor or vendor-tracking sources in Nov 2026. SQL Server and PostgreSQL dates were **not re-checked** — confirm all dates before treating them as authoritative.
- The sample deliberately contains an out-of-support version with no retirement date (APP-1002) so the validator warning and the risk report have something to show.

## Run it
```bash
cd api
python -m venv .venv
source .venv/Scripts/activate        # PowerShell: .\.venv\Scripts\Activate.ps1   (Linux/macOS: source .venv/bin/activate)
pip install -r requirements-dev.txt

python -m trm_api.validate                      # data checks (what CI runs)
python -m pytest -q                             # tests
python -m uvicorn trm_api.main:app --reload --port 8080   # API; docs at http://localhost:8080/docs
python -m trm_api.exports --out ../exports      # write the 4 CSV files to disk
```
Data folder defaults to `../data`; override with `TRM_DATA_DIR`. Files are re-read automatically when they change (`TRM_AUTO_RELOAD=false` to load once, as the container does). Set `TRM_API_KEY` to require an `X-API-Key` header on `/v1` calls.

## Dashboard (Streamlit MI)
Reads only from the FastAPI service, so the same numbers reach Power BI, the API and the dashboard.
```bash
# terminal 1: API
cd api && python -m uvicorn trm_api.main:app --port 8080
# terminal 2: dashboard
cd dashboard
pip install -r requirements.txt
python -m streamlit run app.py          # http://localhost:8501
```
Set the API address and key in the sidebar, or with `TRM_API_URL` (default `http://localhost:8080`) and `TRM_API_KEY`. The sidebar also has the report date (drives lifecycle states) and CSV downloads.

| Tab | Answers |
|---|---|
| Overview | How many technologies by status, how many usages are High risk, versions by lifecycle state, risk by domain, top 10 risks |
| Technology landscape | Filter by domain, area, status, entity, IT owner; drill into one technology (versions, applications, comments, rationale, source file) |
| Lifecycle & risk | Which applications run versions that are past or nearing end of support; vendor support timeline |
| Disinvest exposure | Applications still on Disinvest technologies, those with no retirement date, retirements by year |
| Applications | Application × technology risk map; everything one application depends on |
| Data quality | Validator errors and warnings; taxonomy nodes with no technology |

Data is cached for 60 seconds; use **Refresh data** after changing the md files. Tests (`cd dashboard && python -m pytest`) start the real API on the sample data and drive the app headlessly.

## API (all under `/v1`, filters are query parameters, `as_of=YYYY-MM-DD` optional)
| Endpoint | Purpose |
|---|---|
| `/technologies`, `/technologies/{id}` | List with filters (`domain`, `area`, `category`, `status`, `entity`, `sme`, `it_owner`, `support_team`); detail joins taxonomy, versions, applications and narrative |
| `/taxonomy`, `/taxonomy/{trm_id}` | Taxonomy nodes (filter `domain`, `area`, `category`, `status`) and the technologies under them |
| `/versions`, `/mappings` | Versions with lifecycle state; mappings with lifecycle state and risk rating |
| `/applications/{app_id}/technologies` | Everything one application depends on |
| `/reports/summary` | Counts by domain/status, lifecycle states, risk, data quality |
| `/reports/lifecycle-risk` | Application-technology pairs rated High/Medium, worst first |
| `/reports/disinvest-exposure` | Applications still on Disinvest technologies and their retirement dates |
| `/reports/taxonomy-coverage` | Taxonomy nodes with no technology (gaps) |
| `/search?q=`, `/raw/{dataset}/{id}` | Text search; original markdown source file |
| `/validate`, `/health` | Data-quality issues; liveness |
| `/export/{dataset}.csv` | `taxonomy`, `technologies`, `versions`, `mappings` as CSV |

## Power BI
Import the four CSVs as tables and relate them (`trm_id`, `tech_id`, and `tech_id` + `version`). `mappings` is already denormalised with domain, area, category, technology status, lifecycle state and risk, so many visuals need no relationships. Every derived table carries an `as_of` column.

*Live from the API* (Get Data > Blank Query > Advanced Editor):
```
let
  Source = Csv.Document(
    Web.Contents("https://<your-api-host>/v1/export/mappings.csv",
                 [Headers = [#"X-API-Key" = "<key>"]]),
    [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
  Result = Table.PromoteHeaders(Source, [PromoteAllScalars = true])
in
  Result
```
*From files:* run `python -m trm_api.exports` (the GitLab `export-csv` job does this on each merge to `main`) and point Power BI at the folder. If the API is only reachable inside your network, scheduled refresh in the Power BI service needs an on-premises data gateway. In CSV, `environments` is pipe-separated (`Prod|DR|UAT`).

## AI models
Point an assistant at `/openapi.json`, or give it `/v1/technologies/{id}` (joined record plus rationale) and `/v1/raw/...` (source file). `/v1/search` finds technologies, taxonomy nodes and applications by keyword. A thin MCP wrapper over these endpoints is the natural next step.

## Deploy
`Dockerfile` (repo root) bakes `data/` into the image and runs as a non-root user on port 8080, suitable for OpenShift. Rebuilding the image on every merge to `main` keeps the deployed API identical to the approved data.

## Tests and sample data
`cd api && python -m pytest` (36 tests, including the loaders) and `cd dashboard && python -m pytest` (5 tests, real API plus headless Streamlit).

`api/tests/fixtures/` holds frozen copies of the sample data and sample CSVs, so tests keep passing when `data/` is replaced with real records.
