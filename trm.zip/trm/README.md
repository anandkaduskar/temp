# Technology Reference Model (TRM) — MVP

Git-managed technology standards as **markdown files with a JSON record**, served by a **FastAPI** service for any consumer (apps, AI models, Power BI).

| Dataset | Folder | One file per |
|---|---|---|
| Technology taxonomy | `data/taxonomy/` | taxonomy node (TRM ID) |
| Technologies | `data/technologies/` | technology (Tech ID) |
| Technology versions | `data/versions/` | technology (all its versions) |
| Technology to application mappings | `data/mappings/` | application |

- Field definitions, rules and derived fields: [`docs/DATA_MODEL.md`](docs/DATA_MODEL.md)
- GitLab / ARC governance proposal: [`docs/GITLAB_WORKFLOW_PROPOSAL.md`](docs/GITLAB_WORKFLOW_PROPOSAL.md)

## Sample data (read this first)
`data/` holds sample records for **Databases** (Oracle: Disinvest, SQL Server: Invest, PostgreSQL: Invest) and **BI & Analytics** (Qlik Sense: Disinvest, Power BI: Invest, Cognos: Disinvest), plus 7 fictional applications.

- ARC references, owners and application names are **illustrative**, not real.
- Oracle 19c / 12.2, IBM Cognos 11.2.x and Qlik Sense release dates were checked against vendor or vendor-tracking sources in Nov 2026. SQL Server and PostgreSQL dates are from the vendors' published lifecycle policies but were **not re-checked** — confirm all dates before treating them as authoritative.
- The sample deliberately contains an out-of-support version with no retirement date (APP-1002) so the validator warning and the risk report have something to show.

## Run it
```powershell
cd api
python -m venv .venv ; .\.venv\Scripts\Activate.ps1
pip install -r requirements-dev.txt

python -m trm_api.validate                      # data checks (what CI runs)
python -m pytest -q                             # tests
python -m uvicorn trm_api.main:app --reload --port 8080   # API; docs at http://localhost:8080/docs
python -m trm_api.exports --out ..\exports      # write the 4 CSV files to disk
```
Data folder defaults to `../data`; override with `TRM_DATA_DIR`. Files are re-read automatically when they change (`TRM_AUTO_RELOAD=false` to load once, as the container does). Set `TRM_API_KEY` to require an `X-API-Key` header on `/v1` calls.

## API (all under `/v1`, filters are query parameters, `as_of=YYYY-MM-DD` optional)
| Endpoint | Purpose |
|---|---|
| `/technologies`, `/technologies/{id}` | List with filters (`domain`, `category`, `status`, `owner`, `review_state`); detail joins taxonomy, versions, applications and narrative |
| `/taxonomy`, `/taxonomy/{trm_id}` | Taxonomy nodes and the technologies under them |
| `/versions`, `/mappings` | Versions with lifecycle state; mappings with lifecycle state and risk rating |
| `/applications/{app_id}/technologies` | Everything one application depends on |
| `/reports/summary` | Counts by domain/status, lifecycle states, risk, reviews, data quality |
| `/reports/lifecycle-risk` | Application-technology pairs rated High/Medium, worst first |
| `/reports/disinvest-exposure` | Applications still on Disinvest technologies and their retirement dates |
| `/reports/reviews-due?within_days=60` | Technology reviews due or overdue |
| `/reports/taxonomy-coverage` | Taxonomy nodes with no technology (gaps) |
| `/search?q=`, `/raw/{dataset}/{id}` | Text search; original markdown source file |
| `/validate`, `/health` | Data-quality issues; liveness |
| `/export/{dataset}.csv` | `taxonomy`, `technologies`, `versions`, `mappings` as CSV |

## Power BI
Import the four CSVs as tables and relate them (`trm_id`, `tech_id`, and `tech_id` + `version`). `mappings` is already denormalised with domain, status, lifecycle state and risk, so many visuals need no relationships. Every derived table carries an `as_of` column.

*Live from the API* (Get Data > Blank Query > Advanced Editor):
```
let
  Source = Csv.Document(
    Web.Contents("https://<your-api-host>/v1/export/mappings.csv",
                 [Headers = [#"X-API-Key" = "<key>"]]),
    [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
  Result = Table.PromoteHeaders(Source, [PromoteAllScalars = true])
in
  Result
```
*From files:* run `python -m trm_api.exports` (the GitLab `export-csv` job does this on each merge to `main`) and point Power BI at the folder. If the API is only reachable inside your network, scheduled refresh in the Power BI service needs an on-premises data gateway. In CSV, `environments` is pipe-separated (`Prod|DR|UAT`).

## AI models
Point an assistant at `/openapi.json`, or give it `/v1/technologies/{id}` (joined record plus rationale) and `/v1/raw/...` (source file). `/v1/search` finds technologies, taxonomy nodes and applications by keyword. A thin MCP wrapper over these endpoints is the natural next step.

## Deploy
`Dockerfile` (repo root) bakes `data/` into the image and runs as a non-root user on port 8080, suitable for OpenShift. Rebuilding the image on every merge to `main` keeps the deployed API identical to the approved data.

## Tests and sample data
`api/tests/fixtures/sample_data/` is a frozen copy of the sample so tests keep passing when `data/` is replaced with real records.
