@echo off
rem Creates a virtual environment on first run, installs the requirements and starts the app.
cd /d "%~dp0"
if not exist .venv (
  python -m venv .venv || goto :fail
  call .venv\Scripts\activate
  pip install -r requirements.txt || goto :fail
) else (
  call .venv\Scripts\activate
)
streamlit run app.py
goto :eof
:fail
echo Setup failed. Check that Python 3.10 or later is installed and on PATH.
pause
