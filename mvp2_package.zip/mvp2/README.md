# EA repository, MVP 2: technology lifecycle, open source and application mapping

A self-contained Streamlit module. It does not import or read anything from MVP 1; its own data lives in `data/`.
Data comes from five CSV files.

## What it covers

| Element | Pages |
| --- | --- |
| 1. Technology lifecycle: Invest, Maintain, Disinvest, and usage | Technology lifecycle |
| 2. Open-source software: status and usage | Open source |
| 3. Applications and their mappings to 1 and 2 | Application view, Application mapping |
| Overview and quality | Overview, Data quality |

| Page | Purpose |
| --- | --- |
| Overview | Headline numbers, stance by area, approval by licence, what to act on first |
| Technology lifecycle | Support end dates by quarter, migration pressure (usage against time to end of support), catalogue with detail and applications using each technology, stance contradictions |
| Open source | Approval, licence, maintainer health and vulnerabilities; catalogue with detail; findings (copyleft in external applications, in use but not approved, past end of life, critical vulnerabilities, approvals to revisit) |
| Application view | One application's technologies and open-source components, with what needs attention |
| Application mapping | Technology debt against open-source risk, applications ranked by exposure, mapping gaps |
| Data quality | Checks on the CSV files |

## Run it

Python 3.10 or later. On Windows double-click `run_windows.bat`; on macOS or Linux run `./run.sh`. Or by hand:

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows;  source .venv/bin/activate on macOS or Linux
pip install -r requirements.txt
streamlit run app.py
```

Open http://localhost:8501. The sidebar lets you use the pilot data, point at a folder of your own CSV files, or upload the five files.
Tests: `pip install -r requirements-dev.txt` then `python -m pytest`.

## The data files

All five go in one folder (pilot: `data/ib_pilot/`). Column names must match exactly. Everything is read as text.

| File | One row per | Columns |
| --- | --- | --- |
| `technologies.csv` | Technology product and version | `tech_id`, `name`, `vendor`, `version`, `area`, `category`, `service`, `investment_stance`, `stance_rationale`, `replacement_tech_id`, `target_date`, `deployment_model`, `end_of_support`, `date_source`, `owner_team`, `annual_cost_usd`, `oss_id` |
| `oss_components.csv` | Open-source component and version | `oss_id`, `name`, `version`, `license`, `license_category`, `approval_status`, `conditions`, `support_model`, `support_vendor`, `maintainer_health`, `last_release`, `end_of_life`, `critical_vulns`, `high_vulns`, `vuln_checked`, `owner_team`, `replacement_oss_id` |
| `applications.csv` | Application | `app_id`, `name`, `business_domain`, `criticality`, `owner_team`, `lifecycle`, `exposure`, `last_reviewed` |
| `app_technology.csv` | Application running on a technology | `app_id`, `tech_id`, `usage` |
| `app_oss.csv` | Application using a component | `app_id`, `oss_id`, `usage_type`, `link_type` |

Allowed values:

- `investment_stance`: Invest (preferred for new work), Maintain (keep supported, no new investment), Disinvest (wind down)
- `license_category`: Permissive, Weak copyleft, Strong copyleft, Network copyleft, Source-available
- `approval_status`: Approved, Conditionally approved (say the condition in `conditions`), Under review, Not approved
- `maintainer_health`: Active, Slowing, Inactive. `support_model`: Community, Foundation-backed, Commercial support
- `criticality`: Tier 1, Tier 2, Tier 3. `exposure`: Internal, Client-facing, Distributed (shipped to others)
- `usage_type`: Platform product, Runtime, Framework, Library, Build tool, Embedded component. `link_type`: Direct, Transitive
- `end_of_support`, `end_of_life`, `target_date`, `last_release`, `vuln_checked`: a date such as `2027-01-12`, or blank

**How technologies and open source meet.** A technology that is itself open source (Python, Kafka, PostgreSQL) carries an `oss_id`
pointing at its entry in `oss_components.csv`. An application that runs the technology is counted as using the component, mapped
as a Platform product, so you do not list it twice. Libraries and frameworks that are not in the technology catalogue (Spring,
Log4j, React) are mapped in `app_oss.csv`.

## How the scores work

Technology score = stance points (Invest 0, Maintain 1, Disinvest 3) + support points (out of support 5, under 6 months 4, 6 to 12 months 3,
12 to 24 months 1). Open-source score = approval (0, 1, 2, 5) + licence (permissive 0 to network copyleft 4) + maintainer health (0, 2, 4)
+ vulnerabilities (3 per critical, 1 per high, capped at 6) + end of life. Priority = score x tier weight (Tier 1 = 3) of the most critical
application that uses it; High at 15 or more, Medium from 6. An application's exposure score is (technology score + open-source score) x its tier weight.
Rules sit at the top of `ea2/model.py`; the pages show them.

Copyleft is flagged separately: strong or network copyleft used by a client-facing or distributed application. That is a prompt for legal
review, not a legal opinion.

## Pilot data

`data/ib_pilot/` is an illustrative Investment Banking dataset: 88 technologies, 50 open-source components, 42 applications.
Technology versions and dates follow the MVP 1 catalogue (`data/seed/`, a one-off copy). Licences, approvals, vulnerability counts, dates and
every mapping are made up; check them against your own scanning tool before real use. Regenerate with `python scripts/make_pilot_data.py`.

## Layout

```
app.py                entry point and navigation
views/                one file per page
ea2/data.py           loading (CSV, upload) and validation; swap CsvRepository for a SQL one later
ea2/model.py          support state, scoring, application exposure
ea2/state.py          sidebar and data-source handling
ea2/ui.py             colours and small helpers
data/ib_pilot/        pilot CSV files;  data/seed/  technology seed used by the generator
scripts/              pilot data generator
tests/                logic and page smoke tests
```
