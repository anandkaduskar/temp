"""Logic and smoke tests for MVP 2, run against the pilot data."""
from pathlib import Path

import pandas as pd
import pytest
from streamlit.testing.v1 import AppTest

from ea2.data import CsvRepository, validate
from ea2.model import build, oss_gaps, stance_conflict, support_state

ROOT = Path(__file__).resolve().parent.parent
AS_OF = pd.Timestamp("2026-11-01")
PAGES = ["overview", "lifecycle", "open_source", "application", "mapping", "data_quality"]


@pytest.fixture(scope="module")
def data():
    return CsvRepository(ROOT / "data" / "ib_pilot").load()


@pytest.fixture(scope="module")
def issues(data):
    return validate(data)


@pytest.fixture(scope="module")
def model(data):
    return build(data, AS_OF)


def test_pilot_data_has_no_errors(issues):
    assert not (issues["severity"] == "Error").any(), issues[issues["severity"] == "Error"]


def test_versions_stay_text(data):
    assert "3.9" in set(data.technologies["version"]) and "1.1.1" in set(data.oss["version"])


def test_support_state_rules():
    assert support_state(pd.Timestamp("2026-01-01"), AS_OF, "No date") == "Out of support"
    assert support_state(pd.Timestamp("2027-01-12"), AS_OF, "No date") == "Under 6 months"
    assert support_state(pd.NaT, AS_OF, "No date") == "No date"


def test_stance_conflict_rules():
    assert stance_conflict("Invest", "Under 6 months", "", pd.NaT)
    assert stance_conflict("Maintain", "Out of support", "", pd.NaT)
    assert stance_conflict("Disinvest", "Supported", "", pd.NaT)
    assert stance_conflict("Disinvest", "Supported", "TECH-001", pd.NaT) == ""
    assert stance_conflict("Disinvest", "Supported", "", pd.Timestamp("2027-06-30")) == ""
    assert stance_conflict("Invest", "Supported", "", pd.NaT) == ""


def test_oss_gap_only_for_approved():
    assert oss_gaps("Approved", "Inactive", "Supported", 0) == "Approved, but maintainer inactive"
    assert oss_gaps("Not approved", "Inactive", "Out of support", 5) == ""


def test_designed_cases_are_found(model):
    t, o, ts = model.technologies.set_index("tech_id"), model.oss.set_index("oss_id"), model.tech_stack
    assert "Invest, but vendor support" in t.loc["TECH-008", "stance_conflict"]        # .NET 9 ends 10 Nov 2026
    assert "Maintain, but already out" in t.loc["TECH-013", "stance_conflict"]        # JBoss EAP lapsed
    assert o.loc["OSS-025", "critical_vulns"] == 3 and o.loc["OSS-025", "risk_level"] == "High"   # Log4j 1.2
    assert model.oss_stack["copyleft_exposed"].sum() >= 2                              # iText and MySQL connector
    flagged = set(model.oss_stack.loc[model.oss_stack["copyleft_exposed"], "application"])
    assert {"Research Publishing Platform", "Cash Management and Payments Hub"} <= flagged
    assert "Approved, but past end of life" in o.loc["OSS-046", "governance_gap"]      # OpenSSL 3.0


def test_platform_oss_is_derived_from_technology(model):
    via = model.oss_stack[model.oss_stack["source"] == "Via technology"]
    assert len(via) > 0 and (via["usage_type"] == "Platform product").all()
    # Kafka is mapped through the technology, not declared
    assert "OSS-012" in set(via["oss_id"])


def test_one_row_per_application_and_component(model):
    assert not model.oss_stack.duplicated(["app_id", "oss_id"]).any()
    assert not model.tech_stack.duplicated(["app_id", "tech_id"]).any()
    assert len(model.applications) == len(set(model.applications["app_id"]))


def test_priority_uses_most_critical_application(model):
    t = model.technologies.set_index("tech_id")
    r = t.loc["TECH-003"]  # Oracle Java SE 8, used by Tier 1 applications
    assert r["max_crit_weight"] == 3 and r["priority"] == r["tech_score"] * 3


def test_app_with_no_oss_is_reported(model, issues):
    app = model.applications.set_index("name").loc["Model Inventory and Validation Tracker"]
    assert app["oss_components"] == 0
    assert (issues["check"] == "Application has no open-source components mapped").any()


def test_bad_references_are_errors(data):
    broken = pd.concat([data.app_oss, pd.DataFrame([{"app_id": "APP-999", "oss_id": "OSS-404", "usage_type": "Library", "link_type": "Direct"}])], ignore_index=True)
    bad_t = data.technologies.copy()
    bad_t.loc[0, "investment_stance"] = "Keep"
    bad_t.loc[1, "replacement_tech_id"] = "TECH-404"
    d2 = type(data)(**{**data.__dict__, "app_oss": broken, "technologies": bad_t})
    checks = set(validate(d2).query("severity == 'Error'")["check"])
    assert {"Unknown application", "Unknown open-source component", "Unknown investment stance", "Unknown replacement technology"} <= checks


def _run(page, data, issues, model):
    at = AppTest.from_file(str(ROOT / "views" / f"{page}.py"), default_timeout=90)
    at.session_state["data"], at.session_state["issues"], at.session_state["model"] = data, issues, model
    at.run()
    return at


@pytest.mark.parametrize("page", PAGES)
def test_page_renders(page, data, issues, model):
    at = _run(page, data, issues, model)
    assert not at.exception, [e.value for e in at.exception]


def test_app_entry_renders():
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=90)
    at.run()
    assert not at.exception, [e.value for e in at.exception]
