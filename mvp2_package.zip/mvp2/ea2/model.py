"""Derived measures: support state, lifecycle and open-source risk, and per-application exposure.

The scoring rules are deliberately simple and written down so reviewers can challenge them.
Change the tables below to change the model.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .data import Data

# ---- technology lifecycle: points for the investment stance and for vendor support
STANCE_POINTS = {"Invest": 0, "Maintain": 1, "Disinvest": 3}

SUPPORT_ORDER = ["Out of support", "Under 6 months", "6 to 12 months", "12 to 24 months", "Supported",
                 "No date (vendor managed)", "No date (self-managed)", "No date"]
SUPPORT_POINTS = {"Out of support": 5, "Under 6 months": 4, "6 to 12 months": 3, "12 to 24 months": 1, "Supported": 0,
                  "No date (vendor managed)": 0, "No date (self-managed)": 1, "No date": 0}

# ---- open source: points for approval, licence, maintainer health and known vulnerabilities
APPROVAL_POINTS = {"Approved": 0, "Conditionally approved": 1, "Under review": 2, "Not approved": 5}
LICENSE_POINTS = {"Permissive": 0, "Weak copyleft": 1, "Strong copyleft": 3, "Network copyleft": 4, "Source-available": 3}
HEALTH_POINTS = {"Active": 0, "Slowing": 2, "Inactive": 4}
VULN_CAP = 6  # 3 per critical and 1 per high vulnerability, capped

# ---- shared
CRITICALITY_WEIGHT = {"Tier 1": 3, "Tier 2": 2, "Tier 3": 1}
HIGH_AT, MEDIUM_AT = 15, 6  # priority thresholds (score x tier weight of the most critical application)
ENDING_SOON = ("Out of support", "Under 6 months", "6 to 12 months")
EXTERNAL = ("Client-facing", "Distributed")
RESTRICTIVE = ("Strong copyleft", "Network copyleft")  # obligations can reach code that is shown or shipped to others
NOT_APPROVED = ("Under review", "Not approved")


def support_state(eos: pd.Timestamp, as_of: pd.Timestamp, no_date: str) -> str:
    if pd.isna(eos):
        return no_date
    if eos < as_of:
        return "Out of support"
    months = (eos.year - as_of.year) * 12 + (eos.month - as_of.month) + (eos.day - as_of.day) / 30
    if months < 6:
        return "Under 6 months"
    if months < 12:
        return "6 to 12 months"
    if months < 24:
        return "12 to 24 months"
    return "Supported"


def risk_level(priority: float) -> str:
    if priority >= HIGH_AT:
        return "High"
    if priority >= MEDIUM_AT:
        return "Medium"
    return "Low"


def stance_conflict(stance: str, support: str, replacement_id: str, target) -> str:
    """Where the stance disagrees with the support date or is incomplete; '' when it is coherent."""
    msgs = []
    if stance == "Invest" and support in ENDING_SOON:
        msgs.append("Invest, but vendor support has ended or ends within 12 months")
    if stance == "Maintain" and support == "Out of support":
        msgs.append("Maintain, but already out of vendor support")
    if stance == "Disinvest" and not replacement_id and pd.isna(target):
        msgs.append("Disinvest with no replacement and no target date")
    return "; ".join(msgs)


def oss_gaps(approval: str, health: str, support: str, critical: int) -> str:
    """Approved components that no longer deserve the approval."""
    if approval != "Approved":
        return ""
    msgs = []
    if support == "Out of support":
        msgs.append("Approved, but past end of life")
    if health == "Inactive":
        msgs.append("Approved, but maintainer inactive")
    if critical > 0:
        msgs.append("Approved, but has critical vulnerabilities")
    return "; ".join(msgs)


@dataclass
class Model:
    """Everything the pages need, already joined and scored."""

    as_of: pd.Timestamp
    technologies: pd.DataFrame   # one row per technology, with usage and risk
    oss: pd.DataFrame            # one row per open-source component, with usage and risk
    applications: pd.DataFrame   # one row per application, with technology and open-source exposure
    tech_stack: pd.DataFrame     # one row per application-technology mapping, fully joined
    oss_stack: pd.DataFrame      # one row per application-component mapping, fully joined


def build(data: Data, as_of: pd.Timestamp) -> Model:
    apps = data.applications.copy()
    apps["crit_weight"] = apps["criticality"].map(CRITICALITY_WEIGHT).fillna(1).astype(int)
    app_cols = apps[["app_id", "name", "business_domain", "criticality", "owner_team", "lifecycle", "exposure", "crit_weight"]].rename(
        columns={"name": "application", "owner_team": "app_owner"})

    # ---------------- technologies
    tech = data.technologies.copy()
    for c in ("end_of_support", "target_date"):
        tech[c] = pd.to_datetime(tech[c], errors="coerce")
    tech["annual_cost_usd"] = pd.to_numeric(tech["annual_cost_usd"], errors="coerce").fillna(0.0)
    tech["label"] = (tech["name"] + " " + tech["version"]).str.strip()
    tech["replacement"] = tech["replacement_tech_id"].map(dict(zip(tech["tech_id"], tech["label"]))).fillna("")
    tech["support_state"] = [
        support_state(e, as_of, "No date (vendor managed)" if d in ("SaaS", "PaaS") else "No date (self-managed)")
        for e, d in zip(tech["end_of_support"], tech["deployment_model"])]
    tech["stance_points"] = tech["investment_stance"].map(STANCE_POINTS).fillna(0).astype(int)
    tech["support_points"] = tech["support_state"].map(SUPPORT_POINTS).fillna(0).astype(int)
    tech["tech_score"] = tech["stance_points"] + tech["support_points"]
    tech["months_to_support_end"] = ((tech["end_of_support"] - as_of).dt.days / 30.4).round(1)
    tech["stance_conflict"] = [stance_conflict(a, b, c, d) for a, b, c, d in
                               zip(tech["investment_stance"], tech["support_state"], tech["replacement_tech_id"], tech["target_date"])]

    tech_stack = (
        data.app_technology.drop_duplicates(["app_id", "tech_id"])
        .merge(app_cols, on="app_id", how="left")
        .merge(tech.rename(columns={"name": "tech_name", "owner_team": "tech_owner"}), on="tech_id", how="left")
    )
    use = tech_stack.groupby("tech_id").agg(
        app_count=("app_id", "nunique"),
        max_crit_weight=("crit_weight", "max"),
        tier1_apps=("criticality", lambda s: int((s == "Tier 1").sum())),
        external_apps=("exposure", lambda s: int(s.isin(EXTERNAL).sum())),
    )
    tech = tech.merge(use, on="tech_id", how="left")
    for c in ("app_count", "max_crit_weight", "tier1_apps", "external_apps"):
        tech[c] = tech[c].fillna(0).astype(int)
    tech["priority"] = tech["tech_score"] * tech["max_crit_weight"]
    tech["risk_level"] = tech["priority"].map(risk_level)
    tech.loc[tech["app_count"] == 0, "risk_level"] = "Low"
    tech_stack = tech_stack.merge(tech[["tech_id", "priority", "risk_level", "app_count"]], on="tech_id", how="left")
    # a shared technology's cost is split across the applications that use it
    tech_stack["cost_share_usd"] = tech_stack["annual_cost_usd"] / tech_stack["app_count"].clip(lower=1)

    # ---------------- open source
    oss = data.oss.copy()
    for c in ("last_release", "end_of_life", "vuln_checked"):
        oss[c] = pd.to_datetime(oss[c], errors="coerce")
    for c in ("critical_vulns", "high_vulns"):
        oss[c] = pd.to_numeric(oss[c], errors="coerce").fillna(0).astype(int)
    oss["label"] = (oss["name"] + " " + oss["version"]).str.strip()
    oss["replacement"] = oss["replacement_oss_id"].map(dict(zip(oss["oss_id"], oss["label"]))).fillna("")
    oss["support_state"] = [support_state(e, as_of, "No date") for e in oss["end_of_life"]]
    oss["approval_points"] = oss["approval_status"].map(APPROVAL_POINTS).fillna(0).astype(int)
    oss["license_points"] = oss["license_category"].map(LICENSE_POINTS).fillna(0).astype(int)
    oss["health_points"] = oss["maintainer_health"].map(HEALTH_POINTS).fillna(0).astype(int)
    oss["vuln_points"] = np.minimum(VULN_CAP, 3 * oss["critical_vulns"] + oss["high_vulns"])
    oss["eol_points"] = oss["support_state"].map(SUPPORT_POINTS).fillna(0).astype(int)
    oss["oss_score"] = oss[["approval_points", "license_points", "health_points", "vuln_points", "eol_points"]].sum(axis=1)
    oss["governance_gap"] = [oss_gaps(a, h, s, c) for a, h, s, c in
                             zip(oss["approval_status"], oss["maintainer_health"], oss["support_state"], oss["critical_vulns"])]
    oss["linked_technology"] = oss["oss_id"].map(
        {o: l for o, l in zip(tech["oss_id"], tech["label"]) if o}).fillna("")

    # an application uses a component if it declares it, or runs a technology that is that component
    declared = data.app_oss.drop_duplicates(["app_id", "oss_id"])[["app_id", "oss_id", "usage_type", "link_type"]].assign(source="Declared")
    linked = tech.loc[tech["oss_id"] != "", ["tech_id", "oss_id"]]
    via = (data.app_technology.drop_duplicates(["app_id", "tech_id"]).merge(linked, on="tech_id")[["app_id", "oss_id"]]
           .assign(usage_type="Platform product", link_type="Direct", source="Via technology"))
    links = pd.concat([declared, via], ignore_index=True).drop_duplicates(["app_id", "oss_id"], keep="first")

    oss_stack = (
        links.merge(app_cols, on="app_id", how="left")
        .merge(oss.rename(columns={"name": "oss_name", "owner_team": "oss_owner"}), on="oss_id", how="left")
    )
    oss_stack["copyleft_exposed"] = oss_stack["license_category"].isin(RESTRICTIVE) & oss_stack["exposure"].isin(EXTERNAL)
    use = oss_stack.groupby("oss_id").agg(
        app_count=("app_id", "nunique"),
        max_crit_weight=("crit_weight", "max"),
        tier1_apps=("criticality", lambda s: int((s == "Tier 1").sum())),
        external_apps=("exposure", lambda s: int(s.isin(EXTERNAL).sum())),
        copyleft_apps=("copyleft_exposed", "sum"),
    )
    oss = oss.merge(use, on="oss_id", how="left")
    for c in ("app_count", "max_crit_weight", "tier1_apps", "external_apps", "copyleft_apps"):
        oss[c] = oss[c].fillna(0).astype(int)
    oss["priority"] = oss["oss_score"] * oss["max_crit_weight"]
    oss["risk_level"] = oss["priority"].map(risk_level)
    oss.loc[oss["app_count"] == 0, "risk_level"] = "Low"
    oss["in_use_not_approved"] = oss["approval_status"].isin(NOT_APPROVED) & (oss["app_count"] > 0)
    oss_stack = oss_stack.merge(oss[["oss_id", "priority", "risk_level", "app_count"]], on="oss_id", how="left")

    def attention(r) -> str:
        msgs = []
        if r["copyleft_exposed"]:
            msgs.append(f"{r['license_category']} in a {r['exposure'].lower()} application")
        if r["approval_status"] in NOT_APPROVED:
            msgs.append(f"In use while {r['approval_status'].lower()}")
        if r["critical_vulns"] > 0:
            msgs.append(f"{r['critical_vulns']} critical vulnerabilities")
        if r["support_state"] == "Out of support":
            msgs.append("Past end of life")
        elif r["maintainer_health"] == "Inactive":
            msgs.append("Maintainer inactive")
        return "; ".join(msgs)

    oss_stack["attention"] = oss_stack.apply(attention, axis=1) if len(oss_stack) else ""

    # ---------------- applications
    t = tech_stack.groupby("app_id").agg(
        technologies=("tech_id", "nunique"),
        disinvest_techs=("investment_stance", lambda s: int((s == "Disinvest").sum())),
        out_of_support_techs=("support_state", lambda s: int((s == "Out of support").sum())),
        high_risk_techs=("risk_level", lambda s: int((s == "High").sum())),
        medium_risk_techs=("risk_level", lambda s: int((s == "Medium").sum())),
        tech_debt=("tech_score", "sum"),
        allocated_cost_usd=("cost_share_usd", "sum"),
    ).reset_index()
    o = oss_stack.groupby("app_id").agg(
        oss_components=("oss_id", "nunique"),
        unapproved_oss=("approval_status", lambda s: int(s.isin(NOT_APPROVED).sum())),
        critical_vulns_total=("critical_vulns", "sum"),
        eol_oss=("support_state", lambda s: int((s == "Out of support").sum())),
        high_risk_oss=("risk_level", lambda s: int((s == "High").sum())),
        medium_risk_oss=("risk_level", lambda s: int((s == "Medium").sum())),
        copyleft_flags=("copyleft_exposed", "sum"),
        oss_debt=("oss_score", "sum"),
    ).reset_index()
    apps = apps.merge(t, on="app_id", how="left").merge(o, on="app_id", how="left")
    num = [c for c in apps.columns if c not in data.applications.columns and c != "crit_weight"]
    apps[num] = apps[num].fillna(0)
    for c in num:
        if c != "allocated_cost_usd":
            apps[c] = apps[c].astype(int)
    apps["exposure_score"] = (apps["tech_debt"] + apps["oss_debt"]) * apps["crit_weight"]
    high = apps["high_risk_techs"] + apps["high_risk_oss"]
    med = apps["medium_risk_techs"] + apps["medium_risk_oss"]
    apps["worst_risk"] = np.where(high > 0, "High", np.where(med > 0, "Medium", "Low"))

    return Model(as_of=as_of, technologies=tech, oss=oss, applications=apps, tech_stack=tech_stack, oss_stack=oss_stack)
