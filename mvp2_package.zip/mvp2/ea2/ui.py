"""Shared colours and small helpers."""
from __future__ import annotations

STANCE_COLOURS = {"Invest": "#0f766e", "Maintain": "#1d4ed8", "Disinvest": "#b91c1c"}
APPROVAL_COLOURS = {"Approved": "#0f766e", "Conditionally approved": "#b45309", "Under review": "#6d28d9", "Not approved": "#b91c1c"}
RISK_COLOURS = {"High": "#b91c1c", "Medium": "#d97706", "Low": "#0f766e"}
LICENSE_COLOURS = {"Permissive": "#0f766e", "Weak copyleft": "#1d4ed8", "Strong copyleft": "#b45309",
                   "Network copyleft": "#b91c1c", "Source-available": "#6d28d9"}
STANCE_MEANING = {
    "Invest": "Preferred for new work; keep investing",
    "Maintain": "Keep running and supported; no new strategic investment",
    "Disinvest": "Wind down; move users to the replacement",
}


def money(v: float) -> str:
    if v >= 1_000_000:
        return f"${v / 1_000_000:.1f}M"
    if v >= 1_000:
        return f"${v / 1_000:.0f}K"
    return f"${v:.0f}"


def badge(text: str, colour: str) -> str:
    return f'<span style="background:{colour};color:#fff;padding:.15rem .6rem;border-radius:999px;font-size:.8rem">{text}</span>'
