"""Loading and validating the MVP 2 data.

Five CSV files: technologies, oss_components, applications and the two mapping tables
app_technology and app_oss. The app only talks to `Repository`; today that reads CSV files and
a SQL implementation can replace it later without touching the pages.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO, Mapping, Protocol

import pandas as pd

STANCES = ["Invest", "Maintain", "Disinvest"]
CRITICALITIES = ["Tier 1", "Tier 2", "Tier 3"]
DEPLOYMENT_MODELS = ["SaaS", "PaaS", "Self-managed", "Appliance"]
EXPOSURES = ["Internal", "Client-facing", "Distributed"]
LICENSE_CATEGORIES = ["Permissive", "Weak copyleft", "Strong copyleft", "Network copyleft", "Source-available"]
APPROVALS = ["Approved", "Conditionally approved", "Under review", "Not approved"]
HEALTH = ["Active", "Slowing", "Inactive"]
SUPPORT_MODELS = ["Community", "Foundation-backed", "Commercial support"]
OSS_USAGE_TYPES = ["Platform product", "Runtime", "Framework", "Library", "Build tool", "Embedded component"]
LINK_TYPES = ["Direct", "Transitive"]

FILES = {
    "technologies": "technologies.csv",
    "oss": "oss_components.csv",
    "applications": "applications.csv",
    "app_technology": "app_technology.csv",
    "app_oss": "app_oss.csv",
}

REQUIRED_COLUMNS = {
    "technologies": ["tech_id", "name", "vendor", "version", "area", "service", "investment_stance", "stance_rationale",
                     "replacement_tech_id", "target_date", "deployment_model", "end_of_support", "owner_team",
                     "annual_cost_usd", "oss_id"],
    "oss": ["oss_id", "name", "version", "license", "license_category", "approval_status", "conditions", "support_model",
            "support_vendor", "maintainer_health", "last_release", "end_of_life", "critical_vulns", "high_vulns",
            "vuln_checked", "owner_team", "replacement_oss_id"],
    "applications": ["app_id", "name", "business_domain", "criticality", "owner_team", "lifecycle", "exposure"],
    "app_technology": ["app_id", "tech_id", "usage"],
    "app_oss": ["app_id", "oss_id", "usage_type", "link_type"],
}


@dataclass
class Data:
    technologies: pd.DataFrame
    oss: pd.DataFrame
    applications: pd.DataFrame
    app_technology: pd.DataFrame
    app_oss: pd.DataFrame

    def counts(self) -> dict[str, int]:
        return {k: len(getattr(self, k)) for k in FILES}


class Repository(Protocol):
    def load(self) -> Data: ...


def _read(source) -> pd.DataFrame:
    # Everything is read as text so versions such as "3.9" and "1.1.1" survive.
    df = pd.read_csv(source, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    df.columns = [c.strip() for c in df.columns]
    return df.apply(lambda col: col.str.strip())


class CsvRepository:
    """Reads the five CSV files from a folder."""

    def __init__(self, folder: str | Path):
        self.folder = Path(folder)

    def load(self) -> Data:
        frames = {}
        for key, fname in FILES.items():
            path = self.folder / fname
            if not path.exists():
                raise FileNotFoundError(f"Missing file: {path}")
            frames[key] = _read(path)
        return Data(**frames)


class UploadRepository:
    """Reads the five CSV files from uploaded file objects, keyed by logical name."""

    def __init__(self, files: Mapping[str, BinaryIO]):
        self.files = files

    def load(self) -> Data:
        missing = [k for k in FILES if self.files.get(k) is None]
        if missing:
            raise FileNotFoundError("Missing uploads: " + ", ".join(FILES[m] for m in missing))
        return Data(**{k: _read(self.files[k]) for k in FILES})


# --------------------------------------------------------------- validation
def _is_bad_date(v: str) -> bool:
    return bool(v) and pd.isna(pd.to_datetime(v, errors="coerce"))


def validate(data: Data) -> pd.DataFrame:
    """One row per problem found. Errors stop the pages; warnings and notes do not."""
    issues: list[dict] = []

    def add(severity, file, row, check, detail):
        issues.append({"severity": severity, "file": FILES[file], "row": row, "check": check, "detail": detail})

    frames = {k: getattr(data, k) for k in FILES}
    for key, cols in REQUIRED_COLUMNS.items():
        for c in [c for c in cols if c not in frames[key].columns]:
            add("Error", key, "", "Missing column", c)
    if issues:
        return pd.DataFrame(issues)

    tech, oss, apps, at, ao = data.technologies, data.oss, data.applications, data.app_technology, data.app_oss

    # ids
    for key, col in [("technologies", "tech_id"), ("oss", "oss_id"), ("applications", "app_id")]:
        df = frames[key]
        for idx in df.index[df[col] == ""]:
            add("Error", key, idx + 2, "Blank id", col)
        for idx, r in df[df[col].duplicated(keep=False) & (df[col] != "")].iterrows():
            add("Error", key, idx + 2, "Duplicate id", r[col])

    # technologies
    for idx, r in tech.iterrows():
        row = idx + 2
        if r["investment_stance"] not in STANCES:
            add("Error", "technologies", row, "Unknown investment stance", f"{r['tech_id']}: '{r['investment_stance']}'")
        if r["deployment_model"] not in DEPLOYMENT_MODELS:
            add("Warning", "technologies", row, "Unknown deployment model", f"{r['tech_id']}: '{r['deployment_model']}'")
        for col in ("end_of_support", "target_date"):
            if _is_bad_date(r[col]):
                add("Error", "technologies", row, "Invalid date", f"{r['tech_id']} {col}: '{r[col]}'")
        if r["annual_cost_usd"] and pd.isna(pd.to_numeric(r["annual_cost_usd"], errors="coerce")):
            add("Error", "technologies", row, "Invalid cost", f"{r['tech_id']}: '{r['annual_cost_usd']}'")
        if not r["owner_team"]:
            add("Warning", "technologies", row, "Missing owner", r["tech_id"])
    tech_ids = set(tech["tech_id"])
    oss_ids = set(oss["oss_id"])
    for idx, r in tech.iterrows():
        rid = r["replacement_tech_id"]
        if rid and rid not in tech_ids:
            add("Error", "technologies", idx + 2, "Unknown replacement technology", f"{r['tech_id']} -> '{rid}'")
        elif rid and rid == r["tech_id"]:
            add("Error", "technologies", idx + 2, "Technology replaces itself", r["tech_id"])
        if r["oss_id"] and r["oss_id"] not in oss_ids:
            add("Error", "technologies", idx + 2, "Unknown open-source component", f"{r['tech_id']} -> '{r['oss_id']}'")
    for idx, d in tech[tech["oss_id"].duplicated(keep=False) & (tech["oss_id"] != "")].iterrows():
        add("Warning", "technologies", idx + 2, "Open-source component linked to several technologies", f"{d['tech_id']} -> {d['oss_id']}")

    # open source
    for idx, r in oss.iterrows():
        row = idx + 2
        for col, allowed in [("license_category", LICENSE_CATEGORIES), ("approval_status", APPROVALS), ("maintainer_health", HEALTH)]:
            if r[col] not in allowed:
                add("Error", "oss", row, f"Unknown {col.replace('_', ' ')}", f"{r['oss_id']}: '{r[col]}'")
        if r["support_model"] not in SUPPORT_MODELS:
            add("Warning", "oss", row, "Unknown support model", f"{r['oss_id']}: '{r['support_model']}'")
        for col in ("last_release", "end_of_life", "vuln_checked"):
            if _is_bad_date(r[col]):
                add("Error", "oss", row, "Invalid date", f"{r['oss_id']} {col}: '{r[col]}'")
        for col in ("critical_vulns", "high_vulns"):
            v = pd.to_numeric(r[col], errors="coerce")
            if pd.isna(v) or v < 0:
                add("Error", "oss", row, "Invalid vulnerability count", f"{r['oss_id']} {col}: '{r[col]}'")
        if not r["license"]:
            add("Warning", "oss", row, "Missing licence", r["oss_id"])
        if r["approval_status"] == "Conditionally approved" and not r["conditions"]:
            add("Warning", "oss", row, "Conditionally approved without conditions", r["oss_id"])
        if not r["owner_team"]:
            add("Warning", "oss", row, "Missing owner", r["oss_id"])
        rid = r["replacement_oss_id"]
        if rid and rid not in oss_ids:
            add("Error", "oss", row, "Unknown replacement component", f"{r['oss_id']} -> '{rid}'")
        elif rid and rid == r["oss_id"]:
            add("Error", "oss", row, "Component replaces itself", r["oss_id"])

    # applications
    for idx, r in apps.iterrows():
        if r["criticality"] not in CRITICALITIES:
            add("Error", "applications", idx + 2, "Unknown criticality", f"{r['app_id']}: '{r['criticality']}'")
        if r["exposure"] not in EXPOSURES:
            add("Error", "applications", idx + 2, "Unknown exposure", f"{r['app_id']}: '{r['exposure']}'")
        if not r["owner_team"]:
            add("Warning", "applications", idx + 2, "Missing owner", r["app_id"])

    # mappings
    app_ids = set(apps["app_id"])
    for idx, r in at.iterrows():
        if r["app_id"] not in app_ids:
            add("Error", "app_technology", idx + 2, "Unknown application", r["app_id"])
        if r["tech_id"] not in tech_ids:
            add("Error", "app_technology", idx + 2, "Unknown technology", r["tech_id"])
    for idx, r in at[at.duplicated(["app_id", "tech_id"], keep=False)].iterrows():
        add("Warning", "app_technology", idx + 2, "Duplicate mapping", f"{r['app_id']} / {r['tech_id']}")
    for idx, r in ao.iterrows():
        if r["app_id"] not in app_ids:
            add("Error", "app_oss", idx + 2, "Unknown application", r["app_id"])
        if r["oss_id"] not in oss_ids:
            add("Error", "app_oss", idx + 2, "Unknown open-source component", r["oss_id"])
        if r["usage_type"] not in OSS_USAGE_TYPES:
            add("Warning", "app_oss", idx + 2, "Unknown usage type", f"{r['app_id']} / {r['oss_id']}: '{r['usage_type']}'")
        if r["link_type"] not in LINK_TYPES:
            add("Warning", "app_oss", idx + 2, "Unknown link type", f"{r['app_id']} / {r['oss_id']}: '{r['link_type']}'")
    for idx, r in ao[ao.duplicated(["app_id", "oss_id"], keep=False)].iterrows():
        add("Warning", "app_oss", idx + 2, "Duplicate mapping", f"{r['app_id']} / {r['oss_id']}")

    # coverage notes
    platform_oss = set(tech.loc[tech["oss_id"] != "", "tech_id"])
    via = set(at.loc[at["tech_id"].isin(platform_oss), "app_id"])
    has_tech, has_oss = set(at["app_id"]), set(ao["app_id"]) | via
    for idx, r in apps.iterrows():
        if r["app_id"] not in has_tech:
            add("Warning", "applications", idx + 2, "Application has no technologies", r["app_id"])
        if r["app_id"] not in has_oss:
            add("Info", "applications", idx + 2, "Application has no open-source components mapped", r["app_id"])
    used_tech = set(at["tech_id"])
    for idx, r in tech.iterrows():
        if r["tech_id"] not in used_tech and r["investment_stance"] == "Disinvest":
            add("Info", "technologies", idx + 2, "Disinvest technology unused and can be removed", f"{r['tech_id']} {r['name']} {r['version']}")
    used_oss = set(ao["oss_id"]) | set(tech.loc[tech["tech_id"].isin(used_tech), "oss_id"])
    for idx, r in oss.iterrows():
        if r["oss_id"] not in used_oss:
            add("Info", "oss", idx + 2, "Open-source component not used by any application", f"{r['oss_id']} {r['name']} {r['version']}")

    return pd.DataFrame(issues, columns=["severity", "file", "row", "check", "detail"])
