"""Sidebar, data loading and the shared model held in session state."""
from __future__ import annotations

from datetime import date
from pathlib import Path

import pandas as pd
import streamlit as st

from .data import FILES, CsvRepository, Data, UploadRepository, validate
from .model import Model, build

ROOT = Path(__file__).resolve().parent.parent
PILOT_DIR = ROOT / "data" / "ib_pilot"
SOURCES = ["Investment banking pilot", "Folder of CSV files", "Upload CSV files"]
EMPTY_ISSUES = ["severity", "file", "row", "check", "detail"]


def render_sidebar() -> tuple[Data | None, pd.DataFrame, Model | None]:
    """Draw the data-source controls, load the data, and return (data, issues, model)."""
    with st.sidebar:
        st.markdown("### Data source")
        source = st.radio("Source", SOURCES, label_visibility="collapsed", key="source")
        as_of = st.date_input("As-of date", value=date.today(), key="as_of",
                              help="Support and end-of-life dates are measured from this day.")
        if source == "Investment banking pilot":
            repo = CsvRepository(PILOT_DIR)
            st.caption("Illustrative data: applications, mappings, versions, licences, vulnerability counts and costs are made up.")
        elif source == "Folder of CSV files":
            repo = CsvRepository(st.text_input("Folder path", value=str(PILOT_DIR), key="folder"))
            st.caption("Expects: " + ", ".join(FILES.values()))
        else:
            repo = UploadRepository({key: st.file_uploader(fname, type="csv", key=f"up_{key}") for key, fname in FILES.items()})

    try:
        data = repo.load()
    except FileNotFoundError as exc:
        st.sidebar.warning(str(exc))
        return None, pd.DataFrame(columns=EMPTY_ISSUES), None
    except Exception as exc:  # unreadable file, bad encoding, and so on
        st.sidebar.error(f"Could not read the data: {exc}")
        return None, pd.DataFrame(columns=EMPTY_ISSUES), None

    issues = validate(data)
    errors = int((issues["severity"] == "Error").sum()) if len(issues) else 0
    model = build(data, pd.Timestamp(as_of)) if errors == 0 else None
    with st.sidebar:
        if errors:
            st.error(f"{errors} data error(s). Fix them on the Data quality page.")
        else:
            c = data.counts()
            st.success(f"{c['technologies']} technologies, {c['oss']} open-source components, {c['applications']} applications")
    return data, issues, model


def need_model() -> Model:
    """Used by every page except Data quality."""
    model = st.session_state.get("model")
    if model is None:
        st.warning("No usable data yet. Choose a data source in the sidebar, or fix the errors on the Data quality page.")
        st.stop()
    return model
