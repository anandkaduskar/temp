"""EA repository, MVP 2: technology lifecycle, open-source software and the applications that use them.

Run:  streamlit run app.py
"""
import streamlit as st

from ea2.state import render_sidebar

st.set_page_config(page_title="EA repository: lifecycle and open source", page_icon=":material/hub:", layout="wide")

data, issues, model = render_sidebar()
st.session_state["data"] = data
st.session_state["issues"] = issues
st.session_state["model"] = model

pages = {
    "Overview": [
        st.Page("views/overview.py", title="Overview", icon=":material/dashboard:", url_path="overview", default=True),
    ],
    "Technology and open source": [
        st.Page("views/lifecycle.py", title="Technology lifecycle", icon=":material/trending_flat:", url_path="lifecycle"),
        st.Page("views/open_source.py", title="Open source", icon=":material/code:", url_path="open-source"),
    ],
    "Applications": [
        st.Page("views/application.py", title="Application view", icon=":material/apps:", url_path="application"),
        st.Page("views/mapping.py", title="Application mapping", icon=":material/hub:", url_path="mapping"),
    ],
    "Quality": [
        st.Page("views/data_quality.py", title="Data quality", icon=":material/fact_check:", url_path="data-quality"),
    ],
}
st.navigation(pages).run()
