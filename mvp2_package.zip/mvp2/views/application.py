import pandas as pd
import plotly.express as px
import streamlit as st

from ea2.data import STANCES
from ea2.state import need_model
from ea2.ui import STANCE_COLOURS, money

model = need_model()
apps, ts, os_ = model.applications, model.tech_stack, model.oss_stack

st.title("Application view")
st.caption("One application: the technologies it runs on and the open-source components it uses, with what needs attention.")

name = st.selectbox("Application", list(apps.sort_values("name")["name"]))
a = apps[apps["name"] == name].iloc[0]
t = ts[ts["app_id"] == a["app_id"]].copy()
o = os_[os_["app_id"] == a["app_id"]].copy()

st.markdown(f"**{a['business_domain']}** | {a['criticality']} | {a['exposure']} | owner: {a['owner_team']} | lifecycle: {a['lifecycle']}")
m = st.columns(6)
m[0].metric("Technologies", int(a["technologies"]))
m[1].metric("On Disinvest tech", int(a["disinvest_techs"]))
m[2].metric("Out of support", int(a["out_of_support_techs"]))
m[3].metric("Open-source components", int(a["oss_components"]), help="Declared, plus platform products the application runs on.")
m[4].metric("Not approved", int(a["unapproved_oss"]), help="Under review or Not approved.")
m[5].metric("Exposure score", int(a["exposure_score"]), help="(Technology score + open-source score) x tier weight.")

left, right = st.columns([2, 3])
with left:
    st.subheader("Technologies by stance")
    g = t.groupby("investment_stance").size().reindex(STANCES).dropna().reset_index(name="technologies")
    fig = px.bar(g, x="investment_stance", y="technologies", color="investment_stance", color_discrete_map=STANCE_COLOURS,
                 labels={"investment_stance": "", "technologies": "Technologies"})
    fig.update_layout(height=280, showlegend=False, margin=dict(l=0, r=0, t=10, b=0))
    st.plotly_chart(fig, width="stretch")
with right:
    st.subheader("Needs attention")
    tf = t[(t["investment_stance"] == "Disinvest") | t["support_state"].isin(["Out of support", "Under 6 months", "6 to 12 months"])].copy()
    tf = tf.assign(kind="Technology", item=tf["label"], why=tf["investment_stance"] + " | " + tf["support_state"], move_to=tf["replacement"], score=tf["tech_score"])
    of = o[o["attention"] != ""].copy()
    of = of.assign(kind="Open source", item=of["label"], why=of["attention"], move_to=of["replacement"], score=of["oss_score"])
    cols = ["kind", "item", "why", "move_to", "score"]
    both = pd.concat([tf[cols], of[cols]], ignore_index=True)
    if both.empty:
        st.success("Nothing to flag. Every technology and component is in good standing.")
    else:
        st.dataframe(both.sort_values("score", ascending=False), hide_index=True, width="stretch", height=280,
                     column_config={"kind": "Type", "item": "Item", "why": "Why", "move_to": "Move to", "score": st.column_config.NumberColumn("Score", width="small")})

st.subheader("Technologies")
st.dataframe(
    t.sort_values(["area", "service"])[["area", "service", "label", "usage", "investment_stance", "support_state", "end_of_support", "replacement"]],
    hide_index=True, width="stretch",
    column_config={"area": "Area", "service": "Service", "label": "Technology", "usage": "Used for", "investment_stance": "Stance",
                   "support_state": "Support", "end_of_support": st.column_config.DateColumn("Support ends", format="DD MMM YYYY"), "replacement": "Move to"},
)
st.subheader("Open-source components")
if o.empty:
    st.warning("No open-source components are mapped to this application. Either it uses none, or the mapping has not been done.")
else:
    st.dataframe(
        o.sort_values(["priority"], ascending=False)[["label", "usage_type", "link_type", "source", "approval_status", "license_category", "maintainer_health", "critical_vulns", "high_vulns", "attention"]],
        hide_index=True, width="stretch",
        column_config={"label": "Component", "usage_type": "Use", "link_type": "Link", "source": "Mapped", "approval_status": "Approval",
                       "license_category": "Licence", "maintainer_health": "Maintainer",
                       "critical_vulns": st.column_config.NumberColumn("Critical", width="small"),
                       "high_vulns": st.column_config.NumberColumn("High", width="small"), "attention": "Needs attention"},
    )
st.caption(f"Allocated technology cost: {money(a['allocated_cost_usd'])} a year (each technology's cost split across the applications that use it).")
