import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

from ea2.data import STANCES
from ea2.model import CRITICALITY_WEIGHT, HIGH_AT, MEDIUM_AT, STANCE_POINTS, SUPPORT_ORDER, SUPPORT_POINTS
from ea2.state import need_model
from ea2.ui import STANCE_COLOURS, STANCE_MEANING, badge, money

model = need_model()
t, stack = model.technologies, model.tech_stack
in_use = t[t["app_count"] > 0].copy()

st.title("Technology lifecycle")
st.caption(f"As of {model.as_of:%d %b %Y}. Invest, maintain or disinvest, set against vendor support dates and how widely each technology is used.")

by = in_use["investment_stance"].value_counts()
dis = in_use[in_use["investment_stance"] == "Disinvest"]
c = st.columns(6)
c[0].metric("Invest", int(by.get("Invest", 0)))
c[1].metric("Maintain", int(by.get("Maintain", 0)))
c[2].metric("Disinvest", int(by.get("Disinvest", 0)))
c[3].metric("Apps on Disinvest tech", int(stack[stack["investment_stance"] == "Disinvest"]["app_id"].nunique()))
c[4].metric("Disinvest, no replacement", int((dis["replacement"] == "").sum()), help="A technology being wound down needs a named place to move to.")
c[5].metric("Stance contradictions", int((in_use["stance_conflict"] != "").sum()))

left, right = st.columns(2)
with left:
    st.subheader("Support end dates, by quarter")
    d = in_use.dropna(subset=["end_of_support"]).copy()
    d["when"] = np.where(d["end_of_support"] < model.as_of, "Already out of support", d["end_of_support"].dt.to_period("Q").astype(str))
    horizon_q = (model.as_of + pd.DateOffset(years=3)).to_period("Q").strftime("%YQ%q")
    d = d[(d["when"] == "Already out of support") | (d["when"] <= horizon_q)]
    order = ["Already out of support"] + sorted(set(d["when"]) - {"Already out of support"})
    g = d.groupby(["when", "investment_stance"]).size().reset_index(name="technologies")
    fig = px.bar(g, x="when", y="technologies", color="investment_stance", color_discrete_map=STANCE_COLOURS,
                 category_orders={"when": order, "investment_stance": STANCES},
                 labels={"when": "", "technologies": "Technologies in use", "investment_stance": "Stance"})
    fig.update_layout(height=360, margin=dict(l=0, r=0, t=10, b=0), legend_title_text="")
    st.plotly_chart(fig, width="stretch")
    st.caption("Next three years. Technologies with no vendor date are not shown.")
with right:
    st.subheader("Migration pressure")
    d = in_use.dropna(subset=["months_to_support_end"]).copy()
    d["months"] = d["months_to_support_end"].clip(-24, 60)
    d["size"] = 1 + d["tier1_apps"]
    fig = px.scatter(d, x="months", y="app_count", size="size", color="investment_stance", color_discrete_map=STANCE_COLOURS,
                     hover_name="label", category_orders={"investment_stance": STANCES},
                     hover_data={"months": False, "size": False, "tier1_apps": True, "support_state": True},
                     labels={"months": "Months until vendor support ends (negative: already ended)", "app_count": "Applications using it", "investment_stance": "Stance"})
    fig.add_vline(x=0, line_dash="dot", line_color="#64748b")
    fig.update_layout(height=360, margin=dict(l=0, r=0, t=10, b=0), legend_title_text="")
    st.plotly_chart(fig, width="stretch")
    st.caption("Top left is urgent: widely used and support has ended. Bubble size grows with Tier 1 applications.")

st.subheader("Catalogue")
f = st.columns([3, 2, 2, 2])
q = f[0].text_input("Search", placeholder="Name, vendor or service")
areas = f[1].multiselect("Area", list(t["area"].drop_duplicates()))
stances = f[2].multiselect("Stance", STANCES)
support = f[3].multiselect("Support", SUPPORT_ORDER)
only_use = st.toggle("Only technologies in use", value=True)

view = t[t["app_count"] > 0] if only_use else t
if q:
    ql = q.lower()
    view = view[view[["label", "vendor", "service"]].apply(lambda col: col.str.lower().str.contains(ql, regex=False)).any(axis=1)]
if areas:
    view = view[view["area"].isin(areas)]
if stances:
    view = view[view["investment_stance"].isin(stances)]
if support:
    view = view[view["support_state"].isin(support)]
view = view.sort_values(["priority", "app_count"], ascending=False).reset_index(drop=True)

event = st.dataframe(
    view[["label", "service", "investment_stance", "support_state", "end_of_support", "target_date", "app_count", "tier1_apps", "replacement", "risk_level"]],
    hide_index=True, width="stretch", on_select="rerun", selection_mode="single-row", height=380,
    column_config={"label": "Technology", "service": "Service", "investment_stance": "Stance", "support_state": "Support",
                   "end_of_support": st.column_config.DateColumn("Support ends", format="DD MMM YYYY"),
                   "target_date": st.column_config.DateColumn("Exit target", format="DD MMM YYYY"),
                   "app_count": st.column_config.NumberColumn("Apps", width="small"),
                   "tier1_apps": st.column_config.NumberColumn("Tier 1", width="small"), "replacement": "Move to", "risk_level": "Risk"},
)
st.download_button("Download this list (CSV)", view.to_csv(index=False).encode("utf-8"), "technology_lifecycle.csv", "text/csv")

rows = event.selection.rows if event and event.selection else []
if rows:
    r = view.iloc[rows[0]]
    st.divider()
    st.subheader(r["label"])
    st.markdown(badge(r["investment_stance"], STANCE_COLOURS.get(r["investment_stance"], "#555")) + f" &nbsp;{STANCE_MEANING.get(r['investment_stance'], '')}", unsafe_allow_html=True)
    m = st.columns(5)
    m[0].metric("Service", r["service"], help=f"{r['area']} > {r['category']}" if "category" in r else r["area"])
    m[1].metric("Used by", f"{r['app_count']} apps", help=f"{r['tier1_apps']} Tier 1; {r['external_apps']} client-facing or distributed")
    m[2].metric("Annual cost", money(r["annual_cost_usd"]))
    m[3].metric("Priority", f"{r['priority']} ({r['risk_level']})")
    m[4].metric("Open source", r["linked_oss"] if "linked_oss" in r else (r["oss_id"] or "No"), help="Linked entry on the Open source page")
    eos = f"{r['end_of_support']:%d %b %Y}" if pd.notna(r["end_of_support"]) else "no date recorded"
    st.write(f"**Support:** {r['support_state']} (ends {eos})  |  **Vendor:** {r['vendor']}  |  **Owner:** {r['tech_owner'] if 'tech_owner' in r else r['owner_team']}")
    st.write(f"**Why this stance:** {r['stance_rationale'] or 'not recorded'}")
    if r["replacement"] or pd.notna(r["target_date"]):
        tgt = f"{r['target_date']:%d %b %Y}" if pd.notna(r["target_date"]) else "no date set"
        st.info(f"Move to: {r['replacement'] or 'not named'}  |  Exit target: {tgt}")
    if r["stance_conflict"]:
        st.warning(r["stance_conflict"])
    users = stack[stack["tech_id"] == r["tech_id"]][["application", "business_domain", "criticality", "exposure", "usage", "lifecycle", "app_owner"]]
    st.markdown("**Applications using it**")
    st.dataframe(users.sort_values(["criticality", "application"]), hide_index=True, width="stretch",
                 column_config={"application": "Application", "business_domain": "Domain", "criticality": "Tier", "exposure": "Exposure",
                                "usage": "Used for", "lifecycle": "Lifecycle", "app_owner": "Owner"})
else:
    st.caption("Select a row to open its detail.")

st.subheader("Stance contradictions and gaps")
bad = in_use[in_use["stance_conflict"] != ""].sort_values("priority", ascending=False)
if bad.empty:
    st.success("No technology in use has a stance that contradicts its support date or is incomplete.")
else:
    st.dataframe(bad[["label", "investment_stance", "support_state", "end_of_support", "app_count", "stance_conflict"]], hide_index=True, width="stretch",
                 column_config={"label": "Technology", "investment_stance": "Stance", "support_state": "Support",
                                "end_of_support": st.column_config.DateColumn("Support ends", format="DD MMM YYYY"),
                                "app_count": st.column_config.NumberColumn("Apps", width="small"), "stance_conflict": "Why it needs a decision"})
    st.caption("Either the stance or the support date needs a decision, or the plan to leave needs a replacement and a date.")

with st.expander("How the priority score works"):
    st.markdown(
        f"""
Technology score = stance points + support points. Priority = score x tier weight of the most critical application that uses it.
Risk is **High** at {HIGH_AT} or more and **Medium** from {MEDIUM_AT}.

- Stance points: {', '.join(f'{k} {v}' for k, v in STANCE_POINTS.items())}
- Support points: {', '.join(f'{k} {v}' for k, v in SUPPORT_POINTS.items() if not k.startswith('No date'))}; no date and vendor managed 0; no date and self-managed 1
- Tier weight: {', '.join(f'{k} = {v}' for k, v in CRITICALITY_WEIGHT.items())}

The rules sit at the top of `ea2/model.py`.
"""
    )
