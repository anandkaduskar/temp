import pandas as pd
import plotly.express as px
import streamlit as st

from ea2.data import APPROVALS, HEALTH, LICENSE_CATEGORIES
from ea2.model import APPROVAL_POINTS, CRITICALITY_WEIGHT, HEALTH_POINTS, HIGH_AT, LICENSE_POINTS, MEDIUM_AT, VULN_CAP
from ea2.state import need_model
from ea2.ui import APPROVAL_COLOURS, LICENSE_COLOURS, badge

model = need_model()
o, stack = model.oss, model.oss_stack
in_use = o[o["app_count"] > 0].copy()
stale = int((model.as_of - o["vuln_checked"]).dt.days.gt(90).sum()) if o["vuln_checked"].notna().any() else 0

st.title("Open source")
st.caption(f"As of {model.as_of:%d %b %Y}. Approval status, licence, maintainer health and vulnerabilities of each component, and where it is used.")

c = st.columns(6)
c[0].metric("Components in use", len(in_use), help=f"Of {len(o)} in the catalogue.")
c[1].metric("Approved", int((in_use["approval_status"] == "Approved").sum()))
c[2].metric("Conditionally approved", int((in_use["approval_status"] == "Conditionally approved").sum()))
c[3].metric("In use, not approved", int(in_use["in_use_not_approved"].sum()), help="Under review or Not approved.")
c[4].metric("Copyleft in external apps", int(in_use["copyleft_apps"].sum()), help="Strong or network copyleft used by a client-facing or distributed application.")
c[5].metric("Past end of life or inactive", int(((in_use["support_state"] == "Out of support") | (in_use["maintainer_health"] == "Inactive")).sum()))
if stale:
    st.warning(f"{stale} component(s) have vulnerability data older than 90 days at the as-of date. Refresh it from your scanning tool.")

left, right = st.columns(2)
with left:
    st.subheader("Approval status by licence category")
    g = in_use.groupby(["approval_status", "license_category"]).size().reset_index(name="components")
    fig = px.bar(g, y="approval_status", x="components", color="license_category", orientation="h", color_discrete_map=LICENSE_COLOURS,
                 category_orders={"approval_status": APPROVALS, "license_category": LICENSE_CATEGORIES},
                 labels={"approval_status": "", "components": "Components in use", "license_category": "Licence"})
    fig.update_layout(height=340, margin=dict(l=0, r=0, t=10, b=0), legend_title_text="", yaxis=dict(autorange="reversed"))
    st.plotly_chart(fig, width="stretch")
with right:
    st.subheader("Maintainer health by approval status")
    g = in_use.groupby(["maintainer_health", "approval_status"]).size().reset_index(name="components")
    fig = px.bar(g, y="maintainer_health", x="components", color="approval_status", orientation="h", color_discrete_map=APPROVAL_COLOURS,
                 category_orders={"maintainer_health": HEALTH, "approval_status": APPROVALS},
                 labels={"maintainer_health": "", "components": "Components in use", "approval_status": "Approval"})
    fig.update_layout(height=340, margin=dict(l=0, r=0, t=10, b=0), legend_title_text="", yaxis=dict(autorange="reversed"))
    st.plotly_chart(fig, width="stretch")

st.subheader("Catalogue")
f = st.columns([3, 2, 2, 2])
q = f[0].text_input("Search", placeholder="Name, licence or support vendor")
appr = f[1].multiselect("Approval", APPROVALS)
lic = f[2].multiselect("Licence category", LICENSE_CATEGORIES)
health = f[3].multiselect("Maintainer health", HEALTH)
only_use = st.toggle("Only components in use", value=True)

view = o[o["app_count"] > 0] if only_use else o
if q:
    ql = q.lower()
    view = view[view[["label", "license", "support_vendor"]].apply(lambda col: col.str.lower().str.contains(ql, regex=False)).any(axis=1)]
if appr:
    view = view[view["approval_status"].isin(appr)]
if lic:
    view = view[view["license_category"].isin(lic)]
if health:
    view = view[view["maintainer_health"].isin(health)]
view = view.sort_values(["priority", "app_count"], ascending=False).reset_index(drop=True)

event = st.dataframe(
    view[["label", "approval_status", "license", "license_category", "maintainer_health", "support_state", "critical_vulns", "high_vulns", "app_count", "tier1_apps", "risk_level"]],
    hide_index=True, width="stretch", on_select="rerun", selection_mode="single-row", height=380,
    column_config={"label": "Component", "approval_status": "Approval", "license": "Licence", "license_category": "Category",
                   "maintainer_health": "Maintainer", "support_state": "End of life",
                   "critical_vulns": st.column_config.NumberColumn("Critical", width="small"),
                   "high_vulns": st.column_config.NumberColumn("High", width="small"),
                   "app_count": st.column_config.NumberColumn("Apps", width="small"),
                   "tier1_apps": st.column_config.NumberColumn("Tier 1", width="small"), "risk_level": "Risk"},
)
st.download_button("Download this list (CSV)", view.to_csv(index=False).encode("utf-8"), "open_source_components.csv", "text/csv")

rows = event.selection.rows if event and event.selection else []
if rows:
    r = view.iloc[rows[0]]
    st.divider()
    st.subheader(r["label"])
    st.markdown(badge(r["approval_status"], APPROVAL_COLOURS.get(r["approval_status"], "#555")) + f" &nbsp;{r['license']} ({r['license_category']})", unsafe_allow_html=True)
    m = st.columns(5)
    m[0].metric("Used by", f"{r['app_count']} apps", help=f"{r['tier1_apps']} Tier 1; {r['external_apps']} client-facing or distributed")
    m[1].metric("Support", r["support_model"], help=r["support_vendor"] or "No named vendor")
    m[2].metric("Maintainer", r["maintainer_health"], help=f"Last release {r['last_release']:%d %b %Y}" if pd.notna(r["last_release"]) else "No release date")
    m[3].metric("Vulnerabilities", f"{r['critical_vulns']} critical, {r['high_vulns']} high", help=f"Checked {r['vuln_checked']:%d %b %Y}" if pd.notna(r["vuln_checked"]) else "")
    m[4].metric("Priority", f"{r['priority']} ({r['risk_level']})")
    if r["conditions"]:
        st.info(f"Condition of use: {r['conditions']}")
    if r["linked_technology"]:
        st.write(f"**Also a technology:** {r['linked_technology']} (lifecycle stance is on the Technology lifecycle page)")
    if r["replacement"]:
        st.write(f"**Move to:** {r['replacement']}")
    if r["governance_gap"]:
        st.warning(r["governance_gap"])
    users = stack[stack["oss_id"] == r["oss_id"]][["application", "business_domain", "criticality", "exposure", "usage_type", "link_type", "source", "attention"]]
    st.markdown("**Applications using it**")
    st.dataframe(users.sort_values(["criticality", "application"]), hide_index=True, width="stretch",
                 column_config={"application": "Application", "business_domain": "Domain", "criticality": "Tier", "exposure": "Exposure",
                                "usage_type": "Use", "link_type": "Link", "source": "Mapped", "attention": "Needs attention"})
else:
    st.caption("Select a row to open its detail.")

st.subheader("Findings")
tabs = st.tabs(["Copyleft in external applications", "In use but not approved", "Past end of life or inactive", "Critical vulnerabilities", "Approvals to revisit"])
with tabs[0]:
    x = stack[stack["copyleft_exposed"]]
    if x.empty:
        st.success("No strong or network copyleft component is used by a client-facing or distributed application.")
    else:
        st.dataframe(x[["application", "exposure", "label", "license", "license_category", "approval_status", "usage_type"]].sort_values("application"), hide_index=True, width="stretch",
                     column_config={"application": "Application", "exposure": "Exposure", "label": "Component", "license": "Licence",
                                    "license_category": "Category", "approval_status": "Approval", "usage_type": "Use"})
        st.caption("Copyleft obligations can reach code that is shown to clients or shipped to others. Legal review decides; this list tells you where to look.")
with tabs[1]:
    x = in_use[in_use["in_use_not_approved"]].sort_values("priority", ascending=False)
    if x.empty:
        st.success("Every component in use is approved or conditionally approved.")
    else:
        st.dataframe(x[["label", "approval_status", "license_category", "app_count", "tier1_apps", "replacement", "conditions"]], hide_index=True, width="stretch",
                     column_config={"label": "Component", "approval_status": "Approval", "license_category": "Licence",
                                    "app_count": st.column_config.NumberColumn("Apps", width="small"),
                                    "tier1_apps": st.column_config.NumberColumn("Tier 1", width="small"), "replacement": "Move to", "conditions": "Note"})
with tabs[2]:
    x = in_use[(in_use["support_state"] == "Out of support") | (in_use["maintainer_health"] == "Inactive")].sort_values("priority", ascending=False)
    st.dataframe(x[["label", "approval_status", "maintainer_health", "support_state", "end_of_life", "app_count", "replacement"]], hide_index=True, width="stretch",
                 column_config={"label": "Component", "approval_status": "Approval", "maintainer_health": "Maintainer", "support_state": "End of life",
                                "end_of_life": st.column_config.DateColumn("End of life date", format="DD MMM YYYY"),
                                "app_count": st.column_config.NumberColumn("Apps", width="small"), "replacement": "Move to"})
with tabs[3]:
    x = in_use[in_use["critical_vulns"] > 0].sort_values(["critical_vulns", "high_vulns"], ascending=False)
    if x.empty:
        st.success("No component in use has a critical vulnerability on record.")
    else:
        st.dataframe(x[["label", "critical_vulns", "high_vulns", "approval_status", "app_count", "tier1_apps", "replacement"]], hide_index=True, width="stretch",
                     column_config={"label": "Component", "critical_vulns": "Critical", "high_vulns": "High", "approval_status": "Approval",
                                    "app_count": st.column_config.NumberColumn("Apps", width="small"),
                                    "tier1_apps": st.column_config.NumberColumn("Tier 1", width="small"), "replacement": "Move to"})
with tabs[4]:
    x = o[o["governance_gap"] != ""].sort_values("app_count", ascending=False)
    if x.empty:
        st.success("Every approved component still meets the approval criteria.")
    else:
        st.dataframe(x[["label", "approval_status", "governance_gap", "app_count"]], hide_index=True, width="stretch",
                     column_config={"label": "Component", "approval_status": "Approval", "governance_gap": "Why to revisit",
                                    "app_count": st.column_config.NumberColumn("Apps", width="small")})

with st.expander("How the open-source score works"):
    st.markdown(
        f"""
Score = approval + licence + maintainer health + vulnerabilities + end of life. Priority = score x tier weight of the most critical
application that uses it. Risk is **High** at {HIGH_AT} or more and **Medium** from {MEDIUM_AT}.

- Approval points: {', '.join(f'{k} {v}' for k, v in APPROVAL_POINTS.items())}
- Licence points: {', '.join(f'{k} {v}' for k, v in LICENSE_POINTS.items())}
- Maintainer health points: {', '.join(f'{k} {v}' for k, v in HEALTH_POINTS.items())}
- Vulnerability points: 3 per critical and 1 per high, capped at {VULN_CAP}
- End of life points: same table as technology support (past end of life 5, under 6 months 4, and so on)
- Tier weight: {', '.join(f'{k} = {v}' for k, v in CRITICALITY_WEIGHT.items())}

Copyleft is flagged separately: strong or network copyleft used by a client-facing or distributed application.
The scoring and flags are a prompt for review, not a legal opinion.
"""
    )
