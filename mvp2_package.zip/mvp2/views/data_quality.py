import streamlit as st

from ea2.data import FILES, REQUIRED_COLUMNS

st.title("Data quality")
st.caption("Checks run every time the data loads. Errors stop the other pages; warnings and notes do not.")

data = st.session_state.get("data")
issues = st.session_state.get("issues")

if data is None:
    st.warning("No data loaded. Choose a data source in the sidebar.")
    st.stop()

counts = data.counts()
for col, (key, fname) in zip(st.columns(len(FILES)), FILES.items()):
    col.metric(fname, counts[key])

if issues is None or issues.empty:
    st.success("All checks passed.")
else:
    by = issues["severity"].value_counts()
    k = st.columns(3)
    k[0].metric("Errors", int(by.get("Error", 0)))
    k[1].metric("Warnings", int(by.get("Warning", 0)))
    k[2].metric("Notes", int(by.get("Info", 0)))
    sev = st.multiselect("Show", ["Error", "Warning", "Info"], default=["Error", "Warning", "Info"])
    shown = issues[issues["severity"].isin(sev)]
    st.dataframe(shown, hide_index=True, width="stretch",
                 column_config={"severity": "Severity", "file": "File", "row": st.column_config.TextColumn("Row", width="small"), "check": "Check", "detail": "Detail"})
    st.download_button("Download issues (CSV)", shown.to_csv(index=False).encode("utf-8"), "data_issues.csv", "text/csv")

with st.expander("What the checks cover"):
    st.markdown(
        """
- Required columns are present in every file; IDs are present and unique.
- Investment stance, licence category, approval status, maintainer health, criticality and exposure use the agreed values.
- Dates, costs and vulnerability counts are valid; replacements and linked open-source components exist.
- Every mapping row points to a known application, technology and component; duplicate mappings are listed.
- Notes list applications with no open source mapped, Disinvest technologies nobody uses, and components nobody uses.
"""
    )
with st.expander("Expected CSV columns"):
    for key, cols in REQUIRED_COLUMNS.items():
        st.markdown(f"**{FILES[key]}**: `{', '.join(cols)}`")
    st.markdown("Optional extra columns are ignored: `technologies.csv` may also carry `category` and `date_source`; `applications.csv` may carry `last_reviewed`.")
