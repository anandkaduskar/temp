import plotly.express as px
import streamlit as st

from ea2.data import APPROVALS, LICENSE_CATEGORIES, STANCES
from ea2.state import need_model
from ea2.ui import APPROVAL_COLOURS, LICENSE_COLOURS, STANCE_COLOURS

model = need_model()
t, o, apps = model.technologies, model.oss, model.applications
t_in, o_in = t[t["app_count"] > 0], o[o["app_count"] > 0]

st.title("Technology lifecycle and open source")
st.caption(f"As of {model.as_of:%d %b %Y}. {len(apps)} applications, {len(t_in)} technologies and "
           f"{len(o_in)} open-source components in use.")

c = st.columns(6)
c[0].metric("Disinvest in use", int(((t_in["investment_stance"] == "Disinvest")).sum()), help="Technologies marked Disinvest that applications still run on.")
c[1].metric("Out of support", int((t_in["support_state"] == "Out of support").sum()))
c[2].metric("Stance conflicts", int((t_in["stance_conflict"] != "").sum()), help="For example Invest on a product whose support ends within 12 months.")
c[3].metric("Unapproved OSS", int(o["in_use_not_approved"].sum()), help="Under review or Not approved, and used by at least one application.")
c[4].metric("OSS critical vulns", int((o_in["critical_vulns"] > 0).sum()))
c[5].metric("Copyleft, external", int(o_in["copyleft_apps"].sum()), help="Strong or network copyleft used by a client-facing or distributed application.")

left, right = st.columns(2)
with left:
    st.subheader("Technologies in use, by area and stance")
    g = t_in.groupby(["area", "investment_stance"]).size().reset_index(name="technologies")
    fig = px.bar(g, y="area", x="technologies", color="investment_stance", orientation="h", color_discrete_map=STANCE_COLOURS,
                 category_orders={"investment_stance": STANCES}, labels={"area": "", "technologies": "Technologies", "investment_stance": "Stance"})
    fig.update_layout(height=360, margin=dict(l=0, r=0, t=10, b=0), legend_title_text="", yaxis=dict(autorange="reversed"))
    st.plotly_chart(fig, width="stretch")
with right:
    st.subheader("Open source in use, by approval and licence")
    g = o_in.groupby(["approval_status", "license_category"]).size().reset_index(name="components")
    fig = px.bar(g, y="approval_status", x="components", color="license_category", orientation="h", color_discrete_map=LICENSE_COLOURS,
                 category_orders={"approval_status": APPROVALS, "license_category": LICENSE_CATEGORIES},
                 labels={"approval_status": "", "components": "Components", "license_category": "Licence"})
    fig.update_layout(height=360, margin=dict(l=0, r=0, t=10, b=0), legend_title_text="", yaxis=dict(autorange="reversed"))
    st.plotly_chart(fig, width="stretch")

a, b = st.columns(2)
with a:
    st.subheader("Technologies to act on first")
    top = t_in.sort_values(["priority", "app_count"], ascending=False).head(8)
    st.dataframe(top[["label", "investment_stance", "support_state", "app_count", "priority"]], hide_index=True, width="stretch",
                 column_config={"label": "Technology", "investment_stance": "Stance", "support_state": "Support",
                                "app_count": st.column_config.NumberColumn("Apps", width="small"),
                                "priority": st.column_config.ProgressColumn("Priority", min_value=0, max_value=30, format="%d")})
with b:
    st.subheader("Open source to act on first")
    top = o_in.sort_values(["priority", "app_count"], ascending=False).head(8)
    st.dataframe(top[["label", "approval_status", "license_category", "app_count", "priority"]], hide_index=True, width="stretch",
                 column_config={"label": "Component", "approval_status": "Approval", "license_category": "Licence",
                                "app_count": st.column_config.NumberColumn("Apps", width="small"),
                                "priority": st.column_config.ProgressColumn("Priority", min_value=0, max_value=60, format="%d")})
st.subheader("Most exposed applications")
if True:
    top = apps.sort_values("exposure_score", ascending=False).head(8)
    st.dataframe(top[["name", "criticality", "disinvest_techs", "unapproved_oss", "exposure_score"]], hide_index=True, width="stretch",
                 column_config={"name": "Application", "criticality": "Tier",
                                "disinvest_techs": st.column_config.NumberColumn("Disinvest tech", width="small"),
                                "unapproved_oss": st.column_config.NumberColumn("Unapproved OSS", width="small"),
                                "exposure_score": st.column_config.ProgressColumn("Exposure", min_value=0, max_value=max(1, int(apps["exposure_score"].max())), format="%d")})

st.caption("Priority = score x tier weight of the most critical application that uses the item. "
           "The scoring rules are on the Technology lifecycle and Open source pages.")
