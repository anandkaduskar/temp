import plotly.express as px
import streamlit as st

from ea2.data import CRITICALITIES, EXPOSURES
from ea2.state import need_model

model = need_model()
apps, t, o = model.applications, model.technologies, model.oss

st.title("Application mapping")
st.caption("How applications map onto technologies and open-source components, which applications carry the most exposure, and where the mapping is incomplete.")

linked_tech = set(t.loc[t["oss_id"] != "", "tech_id"])
no_tech = apps[apps["technologies"] == 0]
no_oss = apps[apps["oss_components"] == 0]
c = st.columns(5)
c[0].metric("Applications", len(apps))
c[1].metric("No technology mapped", len(no_tech))
c[2].metric("No open source mapped", len(no_oss), help="Counts declared components and platform products such as Python or Kafka.")
c[3].metric("Technologies unused", int((t["app_count"] == 0).sum()), help="In the catalogue but no application uses them.")
c[4].metric("Open source unused", int((o["app_count"] == 0).sum()))

f = st.columns(4)
dom = f[0].multiselect("Business domain", sorted(apps["business_domain"].unique()))
tier = f[1].multiselect("Tier", CRITICALITIES)
expo = f[2].multiselect("Exposure", EXPOSURES)
life = f[3].multiselect("Lifecycle", sorted(apps["lifecycle"].unique()))
view = apps
if dom:
    view = view[view["business_domain"].isin(dom)]
if tier:
    view = view[view["criticality"].isin(tier)]
if expo:
    view = view[view["exposure"].isin(expo)]
if life:
    view = view[view["lifecycle"].isin(life)]

left, right = st.columns([5, 4])
with left:
    st.subheader("Technology debt against open-source risk")
    if view.empty:
        st.info("No applications match the filters.")
    else:
        d = view.copy()
        fig = px.scatter(d, x="tech_debt", y="oss_debt", color="criticality", hover_name="name",
                         category_orders={"criticality": CRITICALITIES},
                         hover_data={"exposure": True, "disinvest_techs": True, "unapproved_oss": True},
                         labels={"tech_debt": "Technology score (sum across the stack)", "oss_debt": "Open-source score (sum across components)", "criticality": "Tier"})
        fig.update_traces(marker=dict(size=11, opacity=0.8))
        fig.update_layout(height=400, margin=dict(l=0, r=0, t=10, b=0), legend_title_text="")
        st.plotly_chart(fig, width="stretch")
        st.caption("Top right is exposed on both counts. Colour shows the tier; hover for the application.")
with right:
    st.subheader("By business domain")
    if not view.empty:
        g = view.groupby("business_domain").agg(
            apps=("app_id", "nunique"),
            on_disinvest=("disinvest_techs", lambda s: int((s > 0).sum())),
            with_unapproved=("unapproved_oss", lambda s: int((s > 0).sum())),
            copyleft=("copyleft_flags", "sum"),
        ).reset_index().sort_values("on_disinvest", ascending=False)
        st.dataframe(g, hide_index=True, width="stretch", height=400,
                     column_config={"business_domain": "Domain", "apps": st.column_config.NumberColumn("Apps", width="small"),
                                    "on_disinvest": st.column_config.NumberColumn("Disinvest", width="small"),
                                    "with_unapproved": st.column_config.NumberColumn("Unapproved", width="small"),
                                    "copyleft": st.column_config.NumberColumn("Copyleft", width="small")})

st.subheader("Applications ranked by exposure")
st.dataframe(
    view.sort_values("exposure_score", ascending=False)[["name", "business_domain", "criticality", "exposure", "lifecycle", "technologies", "disinvest_techs",
                                                         "out_of_support_techs", "oss_components", "unapproved_oss", "critical_vulns_total", "copyleft_flags", "exposure_score"]],
    hide_index=True, width="stretch",
    column_config={"name": "Application", "business_domain": "Domain", "criticality": "Tier", "exposure": "Exposure", "lifecycle": "Lifecycle",
                   "technologies": st.column_config.NumberColumn("Tech", width="small"),
                   "disinvest_techs": st.column_config.NumberColumn("Disinvest", width="small"),
                   "out_of_support_techs": st.column_config.NumberColumn("Out of support", width="small"),
                   "oss_components": st.column_config.NumberColumn("OSS", width="small"),
                   "unapproved_oss": st.column_config.NumberColumn("Unapproved", width="small"),
                   "critical_vulns_total": st.column_config.NumberColumn("Critical vulns", width="small"),
                   "copyleft_flags": st.column_config.NumberColumn("Copyleft", width="small"),
                   "exposure_score": st.column_config.ProgressColumn("Exposure", min_value=0, max_value=max(1, int(apps["exposure_score"].max())), format="%d")},
)
st.download_button("Download this table (CSV)", view.to_csv(index=False).encode("utf-8"), "application_exposure.csv", "text/csv")

st.subheader("Mapping gaps")
g1, g2 = st.columns(2)
with g1:
    st.markdown("**Applications with no open-source components mapped**")
    if no_oss.empty:
        st.success("Every application has at least one component.")
    else:
        st.dataframe(no_oss[["name", "business_domain", "criticality", "owner_team"]], hide_index=True, width="stretch",
                     column_config={"name": "Application", "business_domain": "Domain", "criticality": "Tier", "owner_team": "Owner"})
        st.caption("Either the application uses none, or nobody has recorded them. A software composition scan would settle it.")
with g2:
    st.markdown("**Technologies in the catalogue that no application uses**")
    unused = t[t["app_count"] == 0]
    if unused.empty:
        st.success("Every technology is used by at least one application.")
    else:
        st.dataframe(unused[["label", "investment_stance", "service"]], hide_index=True, width="stretch", height=240,
                     column_config={"label": "Technology", "investment_stance": "Stance", "service": "Service"})
st.caption(f"{len(linked_tech)} catalogue technologies are also open-source components. An application that runs one is counted as using that component.")
