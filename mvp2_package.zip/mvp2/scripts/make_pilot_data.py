"""Generate the Investment Banking pilot dataset for MVP 2.

Reads the technology seed in ../data/seed (a one-off copy of the MVP 1 catalogue, kept inside this
module so MVP 2 stays independent) and writes five CSV files to ../data/ib_pilot/. Standard library
only. Deterministic: re-run any time.

ILLUSTRATIVE DATA. Application names describe generic capability-supporting systems, not any real
organisation's systems. Versions, dates, licences, vulnerability counts, costs and every mapping are
made up for the prototype; check licences and vulnerabilities against your own SCA tool before use.
"""
import csv
from datetime import date
from pathlib import Path

HERE = Path(__file__).resolve().parent
SEED = HERE.parent / "data" / "seed"
OUT = HERE.parent / "data" / "ib_pilot"
AS_OF = date(2026, 11, 1)
VULN_CHECKED = "2026-10-15"

# ------------------------------------------------------------------ technologies
STANCE_FROM_STATUS = {"Strategic": "Invest", "Emerging": "Invest", "Standard": "Maintain",
                      "Contain": "Disinvest", "Retire": "Disinvest", "Prohibited": "Disinvest"}
STANCE_OVERRIDE = {
    "TECH-023": ("Maintain", "Core to several Tier 1 applications; no approved replacement yet"),
    "TECH-043": ("Maintain", "Retained until the integration migration completes"),
    "TECH-031": ("Invest", "Target analytics platform for risk data aggregation"),
    "TECH-013": ("Maintain", "Vendor extension lapsed; migration to OpenShift-hosted runtimes in progress"),
}
REPLACEMENT = {
    "TECH-003": "TECH-001", "TECH-006": "TECH-004", "TECH-009": "TECH-007", "TECH-012": "TECH-010",
    "TECH-013": "TECH-018", "TECH-014": "TECH-015", "TECH-022": "TECH-020", "TECH-025": "TECH-026",
    "TECH-027": "TECH-028", "TECH-030": "TECH-029", "TECH-034": "TECH-033", "TECH-035": "TECH-033",
    "TECH-039": "TECH-037", "TECH-042": "TECH-041", "TECH-044": "TECH-041", "TECH-047": "TECH-045",
    "TECH-050": "TECH-048", "TECH-051": "TECH-048", "TECH-053": "TECH-052", "TECH-060": "TECH-059",
    "TECH-065": "TECH-064", "TECH-068": "TECH-067", "TECH-071": "TECH-070", "TECH-075": "TECH-074",
    "TECH-077": "TECH-076", "TECH-079": "TECH-078", "TECH-084": "TECH-083",
}
EXPLICIT_TARGET = {"TECH-056": "2028-03-31", "TECH-054": "2027-12-31"}
QUARTER_ENDS = ["2027-03-31", "2027-06-30", "2027-09-30"]

# technology -> open-source component it is (the OSS-id side is defined below)
OSS_OF_TECH = {
    "TECH-001": "OSS-001", "TECH-002": "OSS-002", "TECH-004": "OSS-003", "TECH-005": "OSS-004",
    "TECH-006": "OSS-005", "TECH-010": "OSS-006", "TECH-011": "OSS-007", "TECH-012": "OSS-008",
    "TECH-015": "OSS-009", "TECH-016": "OSS-010", "TECH-024": "OSS-011", "TECH-037": "OSS-012",
    "TECH-039": "OSS-013", "TECH-077": "OSS-014", "TECH-079": "OSS-015", "TECH-081": "OSS-016",
    "TECH-082": "OSS-017", "TECH-084": "OSS-018", "TECH-086": "OSS-019", "TECH-025": "OSS-020",
    "TECH-071": "OSS-021",
}

# ------------------------------------------------------------------ open source
# (oss_id, name, version, licence, category, approval, conditions, support model, support vendor,
#  health, last release, end of life, critical, high, replacement)
C = "Community"
F = "Foundation-backed"
V = "Commercial support"
OSS = [
    ("OSS-001", "OpenJDK", "21", "GPL-2.0-with-classpath-exception", "Weak copyleft", "Approved", "", F, "Eclipse Adoptium", "Active", "2026-10-21", "", 0, 1, ""),
    ("OSS-002", "OpenJDK", "17", "GPL-2.0-with-classpath-exception", "Weak copyleft", "Approved", "", F, "Eclipse Adoptium", "Active", "2026-10-21", "", 0, 2, ""),
    ("OSS-003", "Python", "3.12", "PSF-2.0", "Permissive", "Approved", "", F, "Python Software Foundation", "Active", "2026-10-09", "", 0, 0, ""),
    ("OSS-004", "Python", "3.11", "PSF-2.0", "Permissive", "Approved", "", F, "Python Software Foundation", "Active", "2026-10-09", "", 0, 1, ""),
    ("OSS-005", "Python", "3.9", "PSF-2.0", "Permissive", "Conditionally approved", "Legacy applications only, until migrated to 3.12", F, "Python Software Foundation", "Inactive", "2025-04-08", "", 0, 2, "OSS-003"),
    ("OSS-006", "Node.js", "22", "MIT", "Permissive", "Approved", "", F, "OpenJS Foundation", "Active", "2026-10-15", "", 0, 0, ""),
    ("OSS-007", "Node.js", "20", "MIT", "Permissive", "Conditionally approved", "Migrate to 22 by 2026-12-31", F, "OpenJS Foundation", "Slowing", "2026-04-28", "", 0, 1, "OSS-006"),
    ("OSS-008", "Node.js", "18", "MIT", "Permissive", "Not approved", "", F, "OpenJS Foundation", "Inactive", "2025-03-27", "", 0, 3, "OSS-006"),
    ("OSS-009", "Apache Tomcat", "9", "Apache-2.0", "Permissive", "Approved", "", F, "Apache Software Foundation", "Active", "2026-09-18", "", 0, 1, ""),
    ("OSS-010", "NGINX", "1.26", "BSD-2-Clause", "Permissive", "Approved", "", V, "F5", "Active", "2026-08-12", "", 0, 0, ""),
    ("OSS-011", "PostgreSQL", "15", "PostgreSQL", "Permissive", "Approved", "", C, "", "Active", "2026-08-13", "", 0, 0, ""),
    ("OSS-012", "Apache Kafka", "3.7", "Apache-2.0", "Permissive", "Approved", "", F, "Apache Software Foundation", "Active", "2026-07-02", "", 0, 1, ""),
    ("OSS-013", "RabbitMQ", "3.12", "MPL-2.0", "Weak copyleft", "Conditionally approved", "No new use; legacy messaging only", V, "Broadcom", "Slowing", "2025-10-30", "", 0, 2, "OSS-012"),
    ("OSS-014", "Subversion", "1.14", "Apache-2.0", "Permissive", "Conditionally approved", "Read-only archive use; no new repositories", F, "Apache Software Foundation", "Slowing", "2025-12-04", "", 0, 0, ""),
    ("OSS-015", "Jenkins", "2.440", "MIT", "Permissive", "Approved", "", V, "CloudBees", "Active", "2026-05-14", "", 0, 2, ""),
    ("OSS-016", "Terraform", "1.9", "BUSL-1.1", "Source-available", "Under review", "Legal review of the licence change in progress", V, "HashiCorp", "Active", "2026-09-24", "", 0, 0, ""),
    ("OSS-017", "Ansible", "2.16", "GPL-3.0-or-later", "Strong copyleft", "Conditionally approved", "Internal automation only; do not embed in distributed products", V, "Red Hat", "Active", "2026-06-17", "", 0, 1, ""),
    ("OSS-018", "Zabbix", "6.0", "GPL-2.0-or-later", "Strong copyleft", "Conditionally approved", "Internal monitoring only", V, "Zabbix SIA", "Active", "2026-08-05", "", 0, 1, ""),
    ("OSS-019", "Elastic Stack", "8.12", "Elastic-2.0", "Source-available", "Under review", "Confirm acceptable use under the Elastic licence", V, "Elastic", "Active", "2026-03-19", "", 0, 1, ""),
    ("OSS-020", "MongoDB", "6.0", "SSPL-1.0", "Source-available", "Not approved", "Server Side Public Licence; not approved for client-facing services", V, "MongoDB Inc", "Slowing", "2025-06-12", "", 0, 2, ""),
    ("OSS-021", "HashiCorp Vault", "1.15", "BUSL-1.1", "Source-available", "Under review", "Legal review of the licence change in progress", V, "HashiCorp", "Slowing", "2025-11-20", "", 0, 1, ""),
    ("OSS-022", "Spring Framework", "6.2", "Apache-2.0", "Permissive", "Approved", "", V, "Broadcom", "Active", "2026-10-14", "2027-06-30", 0, 0, ""),
    ("OSS-023", "Spring Framework", "5.3", "Apache-2.0", "Permissive", "Conditionally approved", "Legacy applications only, until migrated to 6.x", V, "Broadcom", "Inactive", "2024-08-15", "2024-08-31", 1, 4, "OSS-022"),
    ("OSS-024", "Apache Log4j", "2.23", "Apache-2.0", "Permissive", "Approved", "", F, "Apache Software Foundation", "Active", "2026-09-02", "", 0, 0, ""),
    ("OSS-025", "Apache Log4j", "1.2", "Apache-2.0", "Permissive", "Not approved", "", F, "Apache Software Foundation", "Inactive", "2012-05-13", "2015-08-05", 3, 5, "OSS-024"),
    ("OSS-026", "Jackson Databind", "2.17", "Apache-2.0", "Permissive", "Approved", "", C, "", "Active", "2026-08-21", "", 0, 0, ""),
    ("OSS-027", "Hibernate ORM", "6.4", "LGPL-2.1-only", "Weak copyleft", "Approved", "", V, "Red Hat", "Active", "2026-09-11", "", 0, 0, ""),
    ("OSS-028", "Apache Struts", "2.5", "Apache-2.0", "Permissive", "Not approved", "", F, "Apache Software Foundation", "Inactive", "2024-12-18", "2025-12-31", 2, 3, "OSS-022"),
    ("OSS-029", "Netty", "4.1", "Apache-2.0", "Permissive", "Approved", "", C, "", "Active", "2026-09-30", "", 0, 1, ""),
    ("OSS-030", "Guava", "33", "Apache-2.0", "Permissive", "Approved", "", C, "", "Active", "2026-07-18", "", 0, 0, ""),
    ("OSS-031", "pandas", "2.2", "BSD-3-Clause", "Permissive", "Approved", "", F, "NumFOCUS", "Active", "2026-06-05", "", 0, 0, ""),
    ("OSS-032", "NumPy", "1.26", "BSD-3-Clause", "Permissive", "Approved", "", F, "NumFOCUS", "Active", "2026-05-27", "", 0, 0, ""),
    ("OSS-033", "scikit-learn", "1.4", "BSD-3-Clause", "Permissive", "Approved", "", F, "NumFOCUS", "Active", "2026-08-08", "", 0, 0, ""),
    ("OSS-034", "Requests", "2.31", "Apache-2.0", "Permissive", "Approved", "", F, "Python Software Foundation", "Active", "2026-04-22", "", 0, 1, ""),
    ("OSS-035", "Flask", "3.0", "BSD-3-Clause", "Permissive", "Approved", "", F, "Pallets", "Active", "2026-07-09", "", 0, 0, ""),
    ("OSS-036", "FastAPI", "0.110", "MIT", "Permissive", "Conditionally approved", "Pin versions; API is pre-1.0", C, "", "Active", "2026-10-02", "", 0, 0, ""),
    ("OSS-037", "React", "18", "MIT", "Permissive", "Approved", "", C, "", "Active", "2026-06-24", "", 0, 0, ""),
    ("OSS-038", "AngularJS", "1.8", "MIT", "Permissive", "Not approved", "", C, "", "Inactive", "2021-04-07", "2021-12-31", 0, 4, "OSS-039"),
    ("OSS-039", "Angular", "17", "MIT", "Permissive", "Approved", "", C, "", "Active", "2026-09-16", "2026-05-15", 0, 0, ""),
    ("OSS-040", "jQuery", "3.7", "MIT", "Permissive", "Approved", "", F, "OpenJS Foundation", "Slowing", "2025-08-28", "", 0, 0, ""),
    ("OSS-041", "Lodash", "4.17", "MIT", "Permissive", "Conditionally approved", "Use patched releases (4.17.21 or later)", C, "", "Slowing", "2025-03-14", "", 0, 1, ""),
    ("OSS-042", "Express", "4.19", "MIT", "Permissive", "Approved", "", F, "OpenJS Foundation", "Active", "2026-05-06", "", 0, 0, ""),
    ("OSS-043", "iText", "5.5", "AGPL-3.0-or-later", "Network copyleft", "Not approved", "", V, "Apryse", "Inactive", "2018-12-06", "", 0, 1, "OSS-044"),
    ("OSS-044", "Apache PDFBox", "3.0", "Apache-2.0", "Permissive", "Approved", "", F, "Apache Software Foundation", "Active", "2026-07-30", "", 0, 0, ""),
    ("OSS-045", "MySQL Connector/J", "8.0", "GPL-2.0-with-FOSS-exception", "Strong copyleft", "Under review", "Confirm FOSS exception applies to our use", V, "Oracle", "Active", "2026-07-21", "2026-04-30", 0, 1, ""),
    ("OSS-046", "OpenSSL", "3.0", "Apache-2.0", "Permissive", "Approved", "", F, "OpenSSL Software Foundation", "Active", "2026-08-26", "2026-09-07", 0, 1, ""),
    ("OSS-047", "OpenSSL", "1.1.1", "OpenSSL", "Permissive", "Not approved", "", F, "OpenSSL Software Foundation", "Inactive", "2023-09-11", "2023-09-11", 0, 3, "OSS-046"),
    ("OSS-048", "Apache Camel", "4.4", "Apache-2.0", "Permissive", "Approved", "", F, "Apache Software Foundation", "Active", "2026-09-04", "", 0, 0, ""),
    ("OSS-049", "SLF4J", "2.0", "MIT", "Permissive", "Approved", "", C, "", "Active", "2026-02-11", "", 0, 0, ""),
    ("OSS-050", "Apache Commons Text", "1.10", "Apache-2.0", "Permissive", "Approved", "", F, "Apache Software Foundation", "Active", "2026-01-23", "", 0, 0, ""),
]
OSS_USAGE = {  # usage_type for the library-style components; link type
    "Framework": ["OSS-022", "OSS-023", "OSS-027", "OSS-028", "OSS-035", "OSS-036", "OSS-037", "OSS-038", "OSS-039", "OSS-042", "OSS-048"],
    "Library": ["OSS-024", "OSS-025", "OSS-026", "OSS-029", "OSS-030", "OSS-031", "OSS-032", "OSS-033", "OSS-034", "OSS-040", "OSS-041",
                "OSS-043", "OSS-044", "OSS-045", "OSS-049", "OSS-050"],
    "Embedded component": ["OSS-046", "OSS-047"],
}
TRANSITIVE = {"OSS-026", "OSS-029", "OSS-030", "OSS-049", "OSS-050", "OSS-046", "OSS-047"}

# ------------------------------------------------------------------ applications
T = dict(J21="TECH-001", J17="TECH-002", J8="TECH-003", PY312="TECH-004", PY311="TECH-005", PY39="TECH-006",
         NET8="TECH-007", NETFW="TECH-009", NODE22="TECH-010", NODE20="TECH-011", NODE18="TECH-012",
         JBOSS="TECH-013", WAS="TECH-014", TOMCAT="TECH-015", NGINX="TECH-016", IIS="TECH-017", OCP="TECH-018",
         AKS="TECH-019", SQL22="TECH-020", SQL19="TECH-021", SQL16="TECH-022", ORA="TECH-023", PG="TECH-024",
         MONGO="TECH-025", COSMOS="TECH-026", PBI="TECH-029", DBX="TECH-031", ADF="TECH-033", INFA="TECH-034",
         PURVIEW="TECH-036", KAFKA="TECH-037", MQ="TECH-038", RMQ="TECH-039", APIM="TECH-041", RHEL9="TECH-045",
         RHEL8="TECH-046", RHEL7="TECH-047", W22="TECH-048", W19="TECH-049", W16="TECH-050", VS8="TECH-052",
         VS7="TECH-053", AZURE="TECH-055", ENTRA="TECH-064", VAULT="TECH-071", SVN="TECH-077", JENKINS="TECH-079",
         TERRA="TECH-081", ANSIBLE="TECH-082", MON="TECH-083", ZABBIX="TECH-084", ELK="TECH-086", SNOW="TECH-087",
         FABRIC="TECH-028")
USAGE = {"Runtime": "J21 J17 J8 PY312 PY311 PY39 NET8 NETFW NODE22 NODE20 NODE18", "Hosting": "JBOSS WAS TOMCAT",
         "Web": "IIS NGINX", "Containers": "OCP AKS", "Database": "SQL22 SQL19 SQL16 ORA PG MONGO COSMOS",
         "Operating system": "RHEL9 RHEL8 RHEL7 W22 W19 W16", "Messaging": "KAFKA MQ RMQ", "Virtualisation": "VS8 VS7",
         "Cloud": "AZURE", "API": "APIM", "Reporting": "PBI", "Data science": "DBX", "Data integration": "ADF INFA",
         "Warehouse": "FABRIC", "Data catalogue": "PURVIEW", "Log management": "ELK", "CI/CD": "JENKINS",
         "Automation": "TERRA ANSIBLE", "Secrets": "VAULT", "Source control": "SVN", "Monitoring": "ZABBIX MON",
         "Identity": "ENTRA", "Service management": "SNOW"}
USAGE_OF = {code: u for u, codes in USAGE.items() for code in codes.split()}
COMMON = "ENTRA MON SNOW"

D1, D2, D3, D4 = "Client Coverage and Origination", "Global Markets", "Corporate and Transaction Banking", "Risk Management and Treasury"
D5, D6, D7, D8, D9 = "Trade Capture and Booking", "Clearing, Settlement and Collateral", "Finance, Regulatory and Data", "Control Functions", "Cross-Cutting Enablers"
BANK, MKT, TXN, RISK = "Banking and Coverage Technology", "Global Markets Technology", "Transaction Banking Technology", "Risk and Treasury Technology"
OPS, FIN, CTRL, DATA, EA = "Operations Technology", "Finance and Regulatory Technology", "Control Functions Technology", "Data and Platform Engineering", "Enterprise Architecture"
I, CF, DI = "Internal", "Client-facing", "Distributed"

# (name, domain, tier, owner, lifecycle, exposure, last reviewed, technologies, open-source OSS numbers)
APPS = [
    ("Client Coverage CRM", D1, 2, BANK, "Live", I, "2026-09-14", "NET8 IIS SQL19 W19 VS8 NODE20", "37 41 40"),
    ("Deal Pipeline Tracker", D1, 2, BANK, "Live", I, "2026-08-30", "J17 TOMCAT SQL19 RHEL8 VS8 MONGO", "22 24 26 38 46"),
    ("Information Barrier Register", D8, 1, CTRL, "Live", I, "2026-10-05", "J21 OCP PG RHEL9", "22 24 26 29 49 46"),
    ("Deal Data Room Gateway", D1, 2, BANK, "Live", CF, "2026-07-21", "NET8 IIS SQL19 W19 NODE18", "38 40 41 46"),
    ("ECM Book-building Platform", D1, 1, BANK, "Live", I, "2026-09-02", "J17 JBOSS ORA RHEL8 MQ VS8", "22 24 26 27 30 46"),
    ("DCM Issuance Platform", D1, 1, BANK, "Live", I, "2026-09-02", "J17 JBOSS ORA RHEL8 MQ VS8", "22 24 26 27 30 46"),
    ("Leveraged Finance Workflow", D1, 2, BANK, "Live", I, "2025-11-18", "J8 WAS ORA RHEL7 MQ VS7 JENKINS", "23 25 28 27 47"),
    ("Securitisation Structuring Tool", D1, 2, BANK, "Live", I, "2026-06-11", "PY311 SQL19 W19", "31 32 33 34"),
    ("Fixed Income Trading Platform", D2, 1, MKT, "Live", I, "2026-10-12", "J21 OCP KAFKA SQL22 RHEL9 TERRA NGINX", "22 24 26 29 49 46"),
    ("FX Trading Platform", D2, 1, MKT, "Live", I, "2026-10-12", "J17 OCP KAFKA SQL19 RHEL8", "22 24 26 29 46"),
    ("Equities Order and Execution", D2, 1, MKT, "Live", I, "2026-09-27", "J17 TOMCAT KAFKA ORA RHEL8 VS8 JENKINS", "22 24 26 29 30 46"),
    ("Derivatives Pricing Engine", D2, 1, MKT, "Live", I, "2026-08-19", "PY312 OCP DBX SQL22 RHEL9", "31 32 33 34 46"),
    ("XVA Analytics Engine", D2, 1, RISK, "Live", I, "2026-08-19", "PY311 OCP DBX AZURE RHEL8 TERRA", "31 32 33 46"),
    ("Futures and Options Clearing Gateway", D6, 1, OPS, "Live", CF, "2026-02-03", "J8 WAS MQ ORA RHEL7 VS7 JENKINS ZABBIX", "23 25 27 47"),
    ("Research Publishing Platform", D2, 3, MKT, "Live", DI, "2026-03-09", "NETFW IIS SQL16 W16 VS8 SVN", "43 40"),
    ("Corporate Lending System", D3, 1, TXN, "Live", I, "2026-09-30", "J17 WAS ORA RHEL8 MQ VS8", "22 24 26 27 46"),
    ("Trade Finance Processing", D3, 1, TXN, "Live", CF, "2026-05-22", "NETFW IIS SQL16 W16 VS8", "40 41"),
    ("Cash Management and Payments Hub", D3, 1, TXN, "Live", CF, "2026-10-20", "J21 OCP KAFKA PG RHEL9 APIM NODE22 VAULT NGINX", "22 24 26 29 37 42 45 46"),
    ("Client Onboarding and KYC Workflow", D8, 1, CTRL, "Live", CF, "2026-10-08", "NET8 AKS AZURE SQL22 COSMOS TERRA", "37 41"),
    ("Market Risk Engine", D4, 1, RISK, "Live", I, "2026-09-15", "J17 OCP ORA RHEL8 KAFKA", "22 24 26 29 46"),
    ("Counterparty Exposure System", D4, 1, RISK, "Live", I, "2026-01-27", "J8 JBOSS ORA RHEL7 VS7 ZABBIX", "23 25 27 47"),
    ("Liquidity and Funding Monitor", D4, 2, RISK, "Live", I, "2026-07-02", "PY311 SQL19 W19 PBI", "31 32 34"),
    ("Capital and RWA Calculator", D4, 1, RISK, "Live", I, "2026-09-09", "PY312 DBX AZURE ADF TERRA", "31 32 33 34"),
    ("Model Inventory and Validation Tracker", D4, 3, RISK, "Live", I, "2026-04-14", "NET8 SQL19 W19", ""),
    ("Trade Capture Hub", D5, 1, OPS, "Live", I, "2026-10-22", "J21 OCP KAFKA PG RHEL9", "22 24 26 48 29 46"),
    ("Confirmation Matching Service", D5, 1, OPS, "Live", I, "2026-10-22", "J17 JBOSS MQ SQL19 RHEL8", "22 24 26 48 46"),
    ("Settlement Engine", D6, 1, OPS, "Live", I, "2026-08-11", "J17 WAS MQ ORA RHEL8 VS8 JENKINS", "22 24 26 48 46"),
    ("Collateral and Margin Manager", D6, 1, OPS, "Live", I, "2026-09-18", "J21 OCP KAFKA SQL22 RHEL9", "22 24 26 46"),
    ("Legacy Margin Calculator", D6, 3, OPS, "Sunset", I, "2025-09-12", "J8 TOMCAT SQL16 W16 VS7 SVN ZABBIX", "23 25 47"),
    ("Reconciliation Platform", D6, 2, OPS, "Live", I, "2026-10-01", "J17 OCP PG RHEL8", "22 24 26 46"),
    ("Legacy Reconciliation Tool", D6, 3, OPS, "Sunset", I, "2025-10-03", "PY39 SQL16 W16 VS7 RMQ", "31 34"),
    ("Corporate Actions Processor", D6, 2, OPS, "Live", I, "2026-06-25", "J17 TOMCAT ORA RHEL8 VS8", "22 24 26 27"),
    ("Product Control P&L System", D7, 1, FIN, "Live", I, "2026-09-04", "NET8 SQL19 W19 PBI NODE22", "37"),
    ("Regulatory Reporting Hub", D7, 1, FIN, "Live", I, "2026-10-15", "PY311 DBX INFA SQL19 RHEL8", "31 32 34 46"),
    ("Risk Data Aggregation Platform", D7, 1, DATA, "Build", I, "2026-10-28", "PY312 DBX FABRIC ADF PURVIEW AZURE TERRA", "31 32 33 35 34"),
    ("Reference Data Hub", D7, 1, DATA, "Live", I, "2026-10-10", "J17 OCP SQL19 KAFKA RHEL8", "22 24 26 29 46"),
    ("Market Data Platform", D9, 1, DATA, "Live", I, "2026-09-22", "J17 KAFKA SQL22 RHEL8 MQ", "22 24 26 29 50 46"),
    ("Trade and Communications Surveillance", D8, 1, CTRL, "Live", I, "2026-08-27", "PY311 ELK RHEL8 DBX MONGO", "31 32 33 36"),
    ("Operational Risk GRC Platform", D8, 2, CTRL, "Live", I, "2026-05-05", "NET8 SQL19 W19 NODE20", "39 40"),
    ("Audit Evidence Collector", D8, 3, CTRL, "Build", I, "2026-10-30", "PY312 OCP PG RHEL9 ANSIBLE", "35 34"),
    ("AI Use-Case Register", D9, 2, EA, "Build", I, "2026-10-26", "NET8 AKS AZURE COSMOS NODE22 TERRA", "37 36"),
    ("Legacy Desk Reporting Tool", D2, 3, MKT, "Sunset", I, "2025-06-30", "NETFW IIS SQL16 W16", "40 41"),
]


def read(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write(name, header, rows):
    with open(OUT / name, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    services = {r["service_id"]: r for r in read(SEED / "services.csv")}
    seed = read(SEED / "technologies.csv")
    tech_eos = {t["tech_id"]: t["end_of_support"] for t in seed}

    # technologies
    trows = []
    for n, t in enumerate(seed, start=1):
        tid = t["tech_id"]
        stance, why = STANCE_OVERRIDE.get(tid, (STANCE_FROM_STATUS[t["standard_status"]], ""))
        rep = REPLACEMENT.get(tid, "")
        if not why:
            why = {"Invest": "Preferred platform for new work",
                   "Maintain": "Supported; no new strategic investment",
                   "Disinvest": "Being phased out" + (" in favour of the replacement" if rep else "")}[stance]
        target = ""
        if stance == "Disinvest":
            eos = t["end_of_support"]
            if tid in EXPLICIT_TARGET:
                target = EXPLICIT_TARGET[tid]
            elif rep:
                target = eos if eos and eos > AS_OF.isoformat() else QUARTER_ENDS[n % 3]
        svc = services[t["service_id"]]
        trows.append([tid, t["name"], t["vendor"], t["version"], svc["service_area"], svc["service_category"], svc["service"],
                      stance, why, rep, target, t["deployment_model"], t["end_of_support"], t["date_source"],
                      t["owner_team"], t["annual_cost_usd"], OSS_OF_TECH.get(tid, "")])
    write("technologies.csv", ["tech_id", "name", "vendor", "version", "area", "category", "service", "investment_stance",
                               "stance_rationale", "replacement_tech_id", "target_date", "deployment_model", "end_of_support",
                               "date_source", "owner_team", "annual_cost_usd", "oss_id"], trows)

    # open source: a platform component takes its end-of-life from the technology it is
    eol_of = {oss: tech_eos[t] for t, oss in OSS_OF_TECH.items()}
    team_of = {oss: next(r["owner_team"] for r in seed if r["tech_id"] == t) for t, oss in OSS_OF_TECH.items()}
    orows = []
    for (oid, name, ver, lic, cat, appr, cond, sup, vendor, health, rel, eol, crit, high, rep) in OSS:
        orows.append([oid, name, ver, lic, cat, appr, cond, sup, vendor, health, rel, eol_of.get(oid, eol), crit, high,
                      VULN_CHECKED, team_of.get(oid, "Open Source Governance"), rep])
    write("oss_components.csv", ["oss_id", "name", "version", "license", "license_category", "approval_status", "conditions",
                                 "support_model", "support_vendor", "maintainer_health", "last_release", "end_of_life",
                                 "critical_vulns", "high_vulns", "vuln_checked", "owner_team", "replacement_oss_id"], orows)

    # applications and the two mapping tables
    arows, links, olinks = [], [], []
    usage_type = {o: u for u, ids in OSS_USAGE.items() for o in ids}
    for i, (name, domain, tier, owner, life, expo, rev, stack, libs) in enumerate(APPS, start=1):
        aid = f"APP-{i:03d}"
        arows.append([aid, name, domain, f"Tier {tier}", owner, life, expo, rev])
        for code in stack.split() + COMMON.split():
            links.append([aid, T[code], USAGE_OF[code]])
        for num in libs.split():
            oid = f"OSS-{int(num):03d}"
            olinks.append([aid, oid, usage_type[oid], "Transitive" if oid in TRANSITIVE else "Direct"])
    write("applications.csv", ["app_id", "name", "business_domain", "criticality", "owner_team", "lifecycle", "exposure", "last_reviewed"], arows)
    write("app_technology.csv", ["app_id", "tech_id", "usage"], links)
    write("app_oss.csv", ["app_id", "oss_id", "usage_type", "link_type"], olinks)

    print(f"Wrote {OUT}")
    print(f"  technologies {len(trows)} | open source {len(orows)} | applications {len(arows)} | "
          f"app-technology {len(links)} | app-oss {len(olinks)}")


if __name__ == "__main__":
    main()
