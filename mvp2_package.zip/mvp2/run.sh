#!/usr/bin/env bash
# Creates a virtual environment on first run, installs the requirements and starts the app.
set -e
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  python3 -m venv .venv
  . .venv/bin/activate
  pip install -r requirements.txt
else
  . .venv/bin/activate
fi
streamlit run app.py
