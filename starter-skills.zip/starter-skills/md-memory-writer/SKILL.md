---
name: md-memory-writer
description: Use at the end of a work session or after a significant decision, when the user says "update memory", "log this decision", "close out", "save state", "wrap up", or when a decision, status change or open question has emerged. Updates the memory markdown files so future sessions have the context.
---

# Markdown Memory Writer

The model has no memory between sessions. These files are the memory. Write to them deliberately, tersely and in a consistent format.

## Files (create if missing)
```
memory/
├── decisions.md        # append-only dated log of decisions
├── state.md            # current status: what is in progress, what is next
└── open-questions.md   # unresolved questions and commitments
```
If the project uses different paths, follow CLAUDE.md / AGENTS.md.

## Steps

### 1. Read before writing
Read all three files first. Never overwrite blindly. Do not re-record something already there.

### 2. Decide what qualifies
**Record:**
- A decision with a rationale (chosen option, rejected alternatives, why)
- A change of status: what was finished, what is in progress, what is blocked
- A question that is unresolved and who or what it depends on
- A commitment or deadline

**Don't record:**
- Routine steps, transient debugging detail, or anything re-derivable from the code or git history
- Secrets, credentials, account numbers or personal sensitive data
- Your own speculation presented as fact. Mark it as a hypothesis, or leave it out.

### 3. Write

**decisions.md**: append only, newest at the bottom:
```markdown
## 2026-11-18: <short decision title>
- Decision: <what was chosen>
- Why: <rationale in 1-3 lines>
- Rejected: <alternatives and why, one line each>
- Status: proposed | accepted | superseded by <link/title>
- Revisit when: <trigger, optional>
```
Never edit an old entry to change history. If a decision changes, add a new entry and mark the old one `superseded`.

**state.md**: rewrite as a snapshot, keep under ~60 lines:
```markdown
# State (updated 2026-11-18)
## In progress
- <item>: <where it stands>, next step: <action>
## Done recently
- <item> (date)
## Blocked / waiting
- <item>: waiting on <who/what>
```
Remove finished items older than ~2 weeks.

**open-questions.md**: one bullet per question with owner and date raised. Move answered questions into decisions.md and delete them here.

### 4. Keep it lean
- One idea per bullet, no narrative
- Use dates in ISO format (YYYY-MM-DD) and absolute names, not "yesterday" or "the thing"
- If a file passes ~200 lines, summarize old material into a short section and move detail to an archive file

### 5. Confirm
Tell the user what you added or changed, in one short list. Don't paste the full files.

## Done criteria
- [ ] Files read before editing
- [ ] Decisions logged with rationale, append-only
- [ ] state.md reflects reality now
- [ ] No secrets or sensitive data written
