---
name: data-analysis
description: Use when the user asks to analyze data, a CSV/Excel/database table, investigate a trend or drop, compare segments, validate a backtest, or produce numbers for a decision. Triggers on "analyze", "what's driving", "compare", "is this significant", "backtest", "check this data". Computes everything in code and validates before reporting.
---

# Data Analysis

Evidence first: every number reported comes from code you ran, never from estimation. Conclusions must survive a validation pass.

## Steps

### 1. Frame the question
Write down before touching data:
- The decision or question this answers
- The metric(s) and their exact definitions (units, time window, filters, currency, adjusted vs unadjusted)
- The hypothesis, and **what result would prove it wrong**

If the question is ambiguous, ask one sharp clarifying question, then proceed.

### 2. Profile the data
Before any analysis, check and report briefly:
- Shape, dtypes, date range, grain (what one row represents)
- Null rates per column, duplicates (on the intended key), obviously impossible values
- Join keys: cardinality before and after every join (row counts must match expectations)
- Survivorship, look-ahead and selection issues in how the data was built

Fix or flag problems; do not silently drop rows. Report how many rows were affected.

### 3. Analyze
- Use scripts or notebooks saved to a file, so the work is reproducible. Never hand-compute in prose.
- Start with simple descriptive cuts; add complexity only if it changes the answer.
- Prefer robust statistics (median, percentiles) when distributions are skewed.
- For comparisons: report effect size, sample size and uncertainty (CI or equivalent), not just a p-value.
- Multiple cuts of the same data inflate false positives. State how many were tried.

### 4. Backtests and strategy results (extra rules)
- No look-ahead: signals use only data available at decision time; check the lag.
- Include costs, slippage and realistic execution assumptions.
- Use out-of-sample or walk-forward results; report in-sample and out-of-sample separately.
- Report drawdown, hit rate, turnover and regime dependence, not just return.
- Treat a surprisingly good result as a bug until proven otherwise.

### 5. Validate (required before reporting)
- Re-derive 2-3 headline numbers a second way (different query or method)
- Check totals reconcile with the source
- Spot-check a few individual rows end to end
- Sensitivity: does the conclusion hold under reasonable changes to window, filter or parameter?
- Try to break the conclusion: what is the strongest alternative explanation?

### 6. Report
Structure:
1. **Answer** in 1-3 sentences (lead with the insight)
2. **Evidence**: key numbers and the table or chart that carries them
3. **Assumptions** and data limitations
4. **What would invalidate this**
5. **Confidence** and recommended next step

Charts: one message per chart, labelled axes and units, consistent palette, no truncated axes that exaggerate.

### 7. Save
Keep the script, the query and the output files together in a named folder. Note the data source and extraction date.

## Done criteria
- [ ] Every number traceable to code
- [ ] Validation step completed and results stated
- [ ] Assumptions and invalidation conditions stated
- [ ] Row counts and exclusions reported

## Model routing hint
Study design and interpretation of ambiguous results: Opus. Analysis code and charts: Sonnet. Profiling, formatting and summarizing tables: Haiku.
