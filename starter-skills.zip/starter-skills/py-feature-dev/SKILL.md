---
name: py-feature-dev
description: Use when the user asks to add, change, fix or implement Python code (a feature, function, module, script, bug fix), says "implement", "build", "write a script", "add support for", or "fix this in Python". Runs a plan, implement, test, lint loop with verification before declaring done.
---

# Python Feature Development

Disciplined loop for Python changes. Never declare done without running the checks in step 5.

## Before starting
1. Read `memory/state.md` and `memory/decisions.md` if they exist, so you don't contradict prior decisions.
2. Find the project's commands (CLAUDE.md / AGENTS.md / pyproject.toml / Makefile). Use the project's own test, lint and typecheck commands. If none are documented, ask once, then record them in CLAUDE.md.

## Steps

### 1. Understand and plan (no edits yet)
State in 5-10 lines:
- What is being asked, in your own words
- Assumptions you are making (flag any you cannot verify)
- Files likely to change, and files that import them
- Test plan: what behaviour will be tested, including edge cases and failure paths

For changes touching more than ~3 files, a new dependency, a data schema, or a public interface: **stop and get approval on the plan** before editing.

### 2. Tests first where practical
Write or extend a failing test that captures the requirement. For bug fixes, the test must reproduce the bug before the fix.

### 3. Implement
- Smallest change that satisfies the tests; follow existing patterns in the codebase over personal preference.
- Type hints on all public functions; docstrings on public functions and classes (one-line summary plus non-obvious behaviour).
- Raise specific exceptions with actionable messages; no bare `except:`; no silent failures.
- No `print()` in library code; use `logging`.
- No hard-coded paths, credentials or environment-specific values. Use config or env vars.
- Don't add dependencies without asking.

### 4. Edge-case pass
Check: empty input, None, wrong types, very large input, duplicate keys, timezone/locale handling, concurrency or re-entrancy if relevant, idempotency for anything that writes data.

### 5. Verify (required)
Run, in order, and read the actual output:
1. Formatter / linter (e.g. `ruff check`, `ruff format --check`)
2. Type checker (e.g. `mypy` or `pyright`) on changed modules
3. Tests: the new ones, then the full suite

If a check fails, fix the cause. Don't weaken the test, add `# type: ignore` or `noqa` to silence it, unless justified in a comment and reported to the user.

### 6. Report
Give: what changed (files + one line each), what you ran and the result, what you did not verify, and any follow-ups. Do not claim "all tests pass" unless you ran them and saw it.

### 7. Record
If a non-trivial design decision was made, append a dated entry to `memory/decisions.md` (decision, rationale). Update `memory/state.md` if work remains.

## Done criteria
- [ ] Tests exist for new behaviour and pass
- [ ] Lint and typecheck clean (or exceptions explained)
- [ ] No unrelated changes in the diff
- [ ] Verification output reported honestly

## Model routing hint
Planning for ambiguous or cross-cutting changes: Opus. Implementation and tests: Sonnet. Mechanical edits (renames, formatting): Haiku.
