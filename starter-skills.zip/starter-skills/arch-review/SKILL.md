---
name: arch-review
description: Use when the user asks to review an architecture, solution design, HLD/LLD, technology choice or proposal against standards, or says "arch review", "design review", "governance review", "does this comply", "review this solution". Produces a scored review with findings, severity and required actions.
---

# Architecture Review

Peer-level review that is evidence-based and actionable. The goal is to find the risks that matter, not to produce a long list.

## Reference files (load if present, in the skill folder or project docs)
- `references/principles.md`: architecture principles
- `references/standards.md`: approved technologies, patterns, security and data standards
- `references/review-criteria.md`: scoring rubric, if the organisation has one

If these are missing, say so at the top of the review and state which general criteria you used instead. Do not invent organisational standards.

## Steps

### 1. Establish scope and inputs
Identify what is being reviewed (solution, platform, decision), the artefacts provided, and what is missing. List missing inputs as findings rather than guessing: context diagram, data flows, NFRs, deployment topology, integration list, security model, cost estimate, ownership and run model.

### 2. Understand before judging
Summarize the design back in 5-8 lines: purpose, key components, data flows, integrations, hosting, who operates it. Flag anything you could not determine.

### 3. Assess across dimensions
For each, give a rating (Green / Amber / Red / Not assessable) with 1-3 lines of evidence:

| Dimension | Questions to answer |
|---|---|
| Business alignment | Does it serve a stated need? Is scope clear? Is there an owner? |
| Principles and standards | Compliant, or deviating? Is any deviation justified and recorded? |
| Capability and reuse | Does it duplicate an existing capability, platform or service? |
| Data | Ownership, lineage, quality, classification, retention, residency, master data impact |
| Integration | Interfaces, patterns, coupling, contracts, versioning, failure handling |
| Security and compliance | Authn/authz, secrets, encryption, audit, regulatory and privacy obligations |
| Resilience and operations | Availability and recovery targets, failure modes, monitoring, runbooks, support model |
| Performance and scale | Load assumptions, bottlenecks, growth headroom |
| Technology fit | Approved stack? Lifecycle and support status? Lock-in and exit cost? Skills available? |
| Cost and sustainability | Build and run cost, licensing, scaling cost curve |
| Delivery risk | Dependencies, complexity, team readiness, phasing |

### 4. Probe failure modes
Ask explicitly, and record the answers or the absence of answers:
- What happens when each external dependency is down or slow?
- What is the blast radius of a bad deploy or bad data?
- What are the single points of failure?
- How is it recovered, and has recovery been tested?
- Which assumption, if wrong, breaks the design?

### 5. Record findings
Each finding:
```markdown
### F-<n>: <short title>
- Severity: Critical | High | Medium | Low | Advisory
- Dimension: <from the table>
- Evidence: <what in the artefacts shows this, or what is absent>
- Risk / impact: <what could go wrong>
- Recommendation: <specific action>
- Owner / needed by: <suggested>
```
Severity guide: Critical = must fix before approval; High = fix before go-live or accept risk formally; Medium = fix in plan; Low and Advisory = improvement.

### 6. Outcome
Give one of: **Approve**, **Approve with conditions** (list them), **Rework required**, **Reject**, or **Insufficient information**. Tie it to the findings, not to tone.

### 7. Write up
```markdown
# Architecture Review: <solution name>
Date | Reviewer | Version reviewed | Artefacts reviewed
## Summary and outcome (3-5 lines, outcome first)
## Design as understood
## Dimension ratings (table)
## Findings (ordered by severity)
## Deviations and exceptions needed
## Conditions for approval
## Open questions
## Missing information
```

## Conduct
- Disagree explicitly where the design is weak; do not soften findings into vague suggestions
- Separate facts from opinion, and say which is which
- Credit sound decisions briefly. A balanced review is more credible.
- Don't endorse a design on the basis of intent; judge what is documented and ask for what isn't

## Done criteria
- [ ] Scope and artefacts stated
- [ ] Every rating has evidence
- [ ] Failure modes probed
- [ ] Findings have severity and a specific recommendation
- [ ] Outcome stated and consistent with findings
- [ ] Deviations flagged for the exception register

## Model routing hint
Full reviews of high-risk or cross-cutting designs: Opus. Routine reviews and write-up: Sonnet. Haiku for extracting component and interface lists from documents.
