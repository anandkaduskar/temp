---
name: adr-writer
description: Use when the user asks to record, draft, review or supersede an Architecture Decision Record, or says "ADR", "decision record", "why did we choose X", "document this decision", "options analysis". Produces a structured ADR with options, trade-offs and consequences, and updates the decision log.
---

# ADR Writer

An ADR records one architecturally significant decision, why it was made, and what follows. It must stand alone for a reader a year from now.

## When an ADR is warranted
Write one when a decision is costly to reverse, affects multiple teams or systems, sets a standard, introduces or retires a technology, or deviates from an existing standard. Don't write one for local, easily reversed choices.

## Steps

### 1. Gather context
- Read `memory/decisions.md` and existing ADRs (e.g. `docs/adr/`) for related or conflicting decisions
- Identify: the problem, drivers (business and technical), constraints, stakeholders, deadline
- Ask for what is missing rather than inventing it. Typical gaps: NFRs (availability, latency, scale, security, compliance), cost, skills, vendor or contract limits, existing landscape.

### 2. Frame options
- At least 2 genuine options plus "do nothing / defer" where realistic
- For each option: description, pros, cons, cost and effort, risks, NFR impact, reversibility
- Keep options MECE: they should differ in a real way, not be minor variants
- Mark any claim you could not verify as an assumption

### 3. Stress-test before recommending
Answer explicitly:
- What are the failure modes and how does each option degrade?
- What does it do to operational burden and skills needs?
- What would make this decision wrong? Which assumption, if false, flips it?
- What is the exit cost if we need to reverse it?

### 4. Draft using the template

```markdown
# ADR-<NNN>: <Decision title, as a statement>

- Status: proposed | accepted | rejected | deprecated | superseded by ADR-<NNN>
- Date: YYYY-MM-DD
- Deciders: <names/roles>
- Consulted / Informed: <names/roles>

## Context
<Problem, drivers, constraints. Facts, not advocacy.>

## Decision drivers
- <driver 1, e.g. NFR or constraint>
- <driver 2>

## Options considered
### Option A: <name>
- Description:
- Pros:
- Cons:
- Cost / effort:
- Risks:
### Option B: <name>
...

## Decision
We will <chosen option>, because <the 2-3 reasons that decided it, tied to drivers>.

## Consequences
- Positive:
- Negative / trade-offs accepted:
- Risks and mitigations:
- Follow-up actions (owner, date):

## Assumptions and invalidation
- Assumes: <...>
- Revisit if: <trigger conditions or date>

## Compliance / governance
- Standards affected, exceptions required, approvals needed

## Links
- Related ADRs, diagrams, tickets, docs
```

### 5. Quality check
- [ ] Title states the decision, not the topic
- [ ] Rejected options have recorded reasons
- [ ] Consequences include the negative ones
- [ ] Revisit triggers are concrete
- [ ] A reader with no context can follow it

### 6. File and log
- Number sequentially and save as `docs/adr/ADR-<NNN>-<kebab-title>.md` (follow the project's existing convention if different)
- Append a one-line entry with a link to `memory/decisions.md`
- When superseding, edit the old ADR's status line only; never rewrite its body

## Style
Plain, direct, no marketing language. Present trade-offs; the recommendation must follow from the drivers. State uncertainty where it exists.

## Model routing hint
Option framing and stress-testing: Opus. Drafting and formatting: Sonnet.
