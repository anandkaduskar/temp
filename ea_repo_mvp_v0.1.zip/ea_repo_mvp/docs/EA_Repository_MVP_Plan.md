# EA Repository: Phased Plan and MVP Scope

*Drafted 2026-11-01. Builds on the Logical Data Model (51 entities, three phases) and the working `mvp/trm_mvp` Streamlit prototype already in this folder.*

## 1. Goal and principles

**Goal:** end-to-end governance of the technology estate: who owns what, what business capability it supports, what technology it runs on, what it is running on today (CIs), and what change is in flight.

**Principles**

1. **Relationships are the product.** Each dimension is a flat table of things. The value is in the mapping tables between them, so those are first-class CSV files with their own owners and quality checks.
2. **Stable IDs from day one.** Every entity has a permanent ID (`APP-001`, `CAP-2.3.1`, `TECH-014`). Names change; IDs never do. This is what makes the later move from CSV to MS SQL or ServiceNow painless.
3. **Declared vs observed.** Applications declare their technology (`app_technology`). CIs show what is actually installed. Keeping both lets the repository reconcile them. That reconciliation is a governance feature, not a data-cleaning chore.
4. **Storage behind an interface.** The prototype already isolates loading in `trm/data.py` (`CsvRepository`). Keep that rule; the SQL repository in Phase 4 should be a drop-in.
5. **Derived, not duplicated.** Capability-to-technology exposure is computed by joins (capability → application → technology). It is never stored.

## 2. Dimensions and how they map

| Dimension | Core table | Links to (mapping table) |
|---|---|---|
| Organisation unit | `org_units` (hierarchy) | `org_unit` column on applications, projects, capabilities (owner) |
| People | `people`, `role_assignments` | Role (owner, architect, steward) on any entity |
| Business capability | `capabilities` (L1 to L3) | `app_capability` |
| Application | `applications` | `app_capability`, `app_technology`, `config_items`, `project_impact` |
| Technology | `services` (TRM), `technologies` (product + version) | `app_technology`, `config_items` |
| Configuration item | `config_items` | belongs to one application; runs one technology version |
| Project | `projects` | `project_impact` (project → application / technology, with action: introduce, change, retire) |

Reading it as a chain: **Org unit → Capability → Application → Technology ← CI**, with **People** attached by role to every node and **Projects** attached through impact.

## 3. Phases

### Phase 0: Foundations (1 to 2 weeks)
- Settle the two open points from the LDM that block data work: **application granularity** (business application vs deployable component) and **whether an L1 to L3 capability model already exists** or must be built.
- Agree the data contract: ID formats, mandatory columns, controlled code lists (standard status, criticality, lifecycle, investment stance).
- Name a **data owner per file** and the master it comes from (CMDB for apps and CIs, HR for people and org, PMO for projects).
- Set up the repo: CSVs under version control (Git history gives you an audit trail for free), `data/` split into `sample/` and `live/`.

**Exit:** signed-off column dictionary; every file has a named owner.

### Phase 1: MVP (target 6 to 8 weeks)
Three use cases, in this order.

**1A. Technology Reference Model and lifecycle** *(largely built: harden and extend)*
- Already in the prototype: TRM map, catalogue, application stack view, lifecycle/risk scoring, data-quality page.
- Add an **investment stance** on every technology: `Invest`, `Maintain`, `Disinvest`.
  - Suggested default mapping from the existing standard status: Strategic and Emerging → Invest; Standard → Maintain; Contain, Retire, Prohibited → Disinvest.
  - Store it as a declared column with a validation rule that flags contradictions (for example, `Invest` on a product that is out of support). Declared is better than purely derived, because a conscious "Maintain until the migration lands" is a decision worth recording.
- Add an **end-of-life view**: out of support, under 6, 12, 24 months, grouped by stance, with count of applications and criticality tier affected.

**1B. Business capability to application mapping**
- Load `capabilities` (L1 to L3) and `app_capability`.
- Mapping attributes: `support_level` (Primary / Supporting), `fit` (Good / Partial / Poor), optional `coverage_pct`.
- Views: capability tree with application counts; per-capability application list; per-application capability list.
- Built-in findings: **gaps** (capability with no application), **overlap** (capability with several Primary applications), **orphans** (application with no capability).

**1C. MI dashboards across the chain**
| Dashboard | Question it answers |
|---|---|
| Capability heatmap | Which capabilities sit on weak or retiring technology? (capability coloured by worst-stance technology beneath it) |
| Technology exposure by business area | How much of each domain / org unit depends on Disinvest or out-of-support technology? |
| Rationalisation | Which capabilities have the most overlapping applications and what do they cost? |
| Application 360 | One application: capabilities served, stack with stance and EOL, owners |
| Technology 360 | One product/version: where it is used, which capabilities depend on it, what replaces it |
| Data quality scorecard | Completeness and referential integrity per file, trend over time |

**MVP CSV set** (new files marked ★; the four existing files stay as they are)

| File | Key columns |
|---|---|
| `services.csv` | service_id, service_area, service_category, service |
| `technologies.csv` | existing columns + ★`investment_stance`, ★`replacement_tech_id` |
| `applications.csv` | existing columns + ★`org_unit_id` |
| `app_technology.csv` | app_id, tech_id, usage |
| ★`capabilities.csv` | cap_id, parent_cap_id, level, name, description, owner_org_unit_id |
| ★`app_capability.csv` | app_id, cap_id, support_level, fit |
| ★`org_units.csv` | org_unit_id, parent_org_unit_id, name, type |

**Exit:** the three use cases run on real data for one pilot domain end to end; data-quality page shows no broken links.

### Phase 2: People, projects and CIs (next 6 to 8 weeks)
This is where the remaining dimensions in your brief arrive.
- ★`people.csv`, ★`role_assignments.csv` (person, role, entity_type, entity_id): owners, architects and stewards on applications, capabilities and technologies. Roles as rows, not owner columns, so any entity can have several.
- ★`projects.csv`, ★`project_impact.csv`: which projects introduce, change or retire which applications and technologies. Enables **roadmap overlays** ("what retires in 2027, and which project owns it").
- ★`config_items.csv` (ci_id, ci_class, name, environment, app_id, tech_id, version, status), exported from the CMDB. Add **declared-vs-observed reconciliation**: technologies a CI runs but the application hasn't declared, and the reverse; CIs running versions past end of support.
- New dashboards: ownership coverage, project-to-estate impact, CI exposure, org-unit scorecard.

### Phase 3: Governance workflow
- ADRs, blueprints and exceptions linked to applications and technologies (the LDM Artefact / Exception entities).
- Owner attestation: periodic survey asking each application owner to confirm their capability and technology mappings; responses written back, stale data flagged.
- Standards exceptions with expiry dates; Architecture Review Council decisions linked to the entities they concern.
- Auditor / regulator view: read-only pages answering the standard questions (what runs this critical service, who owns it, what is out of support, what exceptions exist).

### Phase 4: Platform hardening and integration
- Swap `CsvRepository` for the MS SQL repository on Azure; scheduled loads from ServiceNow CMDB, HR and PMO sources replace manual CSV drops.
- SSO and role-based access; change history on edits; containerised deployment (the prototype already has a Dockerfile).
- Cost and risk: cost at application grain with TCO calculated, licence and contract data, risk and control mappings (LDM phase 3 entities).
- Decide the long-term home for edits (in-app forms vs ServiceNow as master) once the data is trusted.

## 4. MVP architecture (kept deliberately small)

```
data/live/*.csv  →  repo layer (load + validate)  →  model (joins, scoring)  →  Streamlit views
                       CsvRepository (now)              pure functions             one file per page
                       SqlRepository (Phase 4)          unit-tested with pytest
```
- Validation runs on load: missing columns, duplicate IDs, unknown code values, and **every foreign key resolving** (the mapping files are where bad data hides).
- Joins and scoring live in `model.py` as pure functions, so the same logic serves the dashboards, tests and later any API.
- Streamlit pages stay read-only in the MVP. Edits happen in the CSVs via Git, which also gives review and rollback.

## 5. Risks and how the plan handles them

| Risk | Mitigation |
|---|---|
| Capability model doesn't exist or is contested | Start with L1 and L2 only for the pilot domain; refine L3 where applications actually map |
| Application mapping goes stale | Owner attestation (Phase 3); "last reviewed" column from MVP onward, shown on every page |
| CSV files drift apart | Referential-integrity checks block publishing; one named owner per file |
| EOL dates wrong or missing | Keep `date_source` column (prototype already does); show "no date" as its own bucket, not as "safe" |
| Over-building before data is trusted | Cost, risk and workflow deliberately held back until Phase 3 and 4 |
| Tool sprawl with ServiceNow / Waltz-style alternatives | Keep CSV schema aligned to LDM entity names so data is portable to any of them |

## 6. Decisions needed before Phase 1 starts

1. **Application granularity:** business application or deployable component? (Decides what `app_id` means in every file.)
2. **Capability model:** existing L1 to L3 to load, or build from scratch for the pilot?
3. **Pilot domain:** which business area goes end to end first?
4. **Investment stance:** declared with validation (recommended) or fully derived from status and EOL?
5. **Data sources:** which CSVs can be exported from the CMDB or other masters in week 1, and which must be hand-built?
