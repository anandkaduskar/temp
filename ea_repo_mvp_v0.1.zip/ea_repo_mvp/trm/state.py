"""Sidebar, data loading and the shared model held in session state."""
from __future__ import annotations

from datetime import date
from pathlib import Path

import pandas as pd
import streamlit as st

from .data import FILES, OPTIONAL_FILES, CsvRepository, TrmData, UploadRepository, validate
from .model import Model, build

ROOT = Path(__file__).resolve().parent.parent
SAMPLE_DIR = ROOT / "data" / "sample"
IB_DIR = ROOT / "data" / "ib_pilot"

SOURCES = ["Investment banking pilot", "Sample data", "Folder of CSV files", "Upload CSV files"]
EMPTY_ISSUES = ["severity", "file", "row", "check", "detail"]


def render_sidebar() -> tuple[TrmData | None, pd.DataFrame, Model | None]:
    """Draw the data-source controls, load the data, and return (data, issues, model)."""
    with st.sidebar:
        st.markdown("### Data source")
        source = st.radio("Source", SOURCES, label_visibility="collapsed", key="source")
        as_of = st.date_input("As-of date", value=date.today(), key="as_of", help="Support dates are measured from this day.")

        repo = None
        if source == "Investment banking pilot":
            repo = CsvRepository(IB_DIR)
            st.caption("Illustrative data: applications, mappings, versions, dates and costs are made up. "
                       "Capabilities follow the CIB capability map.")
        elif source == "Sample data":
            repo = CsvRepository(SAMPLE_DIR)
            st.caption("Illustrative data. Vendor dates are approximate; check them before real use.")
        elif source == "Folder of CSV files":
            folder = st.text_input("Folder path", value=str(IB_DIR), key="folder")
            repo = CsvRepository(folder)
            st.caption("Required: " + ", ".join(FILES.values()) + ". Optional: " + ", ".join(OPTIONAL_FILES.values()))
        else:
            uploads = {}
            for key, fname in FILES.items():
                uploads[key] = st.file_uploader(fname, type="csv", key=f"up_{key}")
            with st.expander("Optional: capabilities"):
                for key, fname in OPTIONAL_FILES.items():
                    uploads[key] = st.file_uploader(fname, type="csv", key=f"up_{key}")
            repo = UploadRepository(uploads)

    try:
        data = repo.load()
    except FileNotFoundError as exc:
        st.sidebar.warning(str(exc))
        return None, pd.DataFrame(columns=EMPTY_ISSUES), None
    except Exception as exc:  # unreadable file, bad encoding, and so on
        st.sidebar.error(f"Could not read the data: {exc}")
        return None, pd.DataFrame(columns=EMPTY_ISSUES), None

    issues = validate(data)
    errors = int((issues["severity"] == "Error").sum()) if len(issues) else 0
    model = None
    if errors == 0:
        model = build(data, pd.Timestamp(as_of))
    with st.sidebar:
        if errors:
            st.error(f"{errors} data error(s). Fix them on the Data quality page.")
        else:
            c = data.counts()
            msg = f"{c['technologies']} technologies, {c['applications']} applications, {c['links']} links"
            if data.has_capabilities:
                msg += f", {c['capabilities']} capabilities"
            st.success(msg)
    return data, issues, model


def need_model() -> Model:
    """Used by every page except Data quality."""
    model = st.session_state.get("model")
    if model is None:
        st.warning("No usable data yet. Choose a data source in the sidebar, or fix the errors on the Data quality page.")
        st.stop()
    return model


def need_capabilities() -> Model:
    """Used by the capability pages: needs the three optional files as well."""
    model = need_model()
    if not model.has_capabilities:
        st.info("This page needs capabilities.csv and app_capability.csv (org_units.csv is optional). "
                "Choose the Investment banking pilot in the sidebar, or add those files to your folder.")
        st.stop()
    return model
