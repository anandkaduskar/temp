"""Capability tree helpers and roll-ups.

Pure functions on DataFrames, so they serve the validation, the model and the pages alike.
A capability's numbers include everything beneath it in the tree.
"""
from __future__ import annotations

import pandas as pd

RISK_RANK = {"Low": 0, "Medium": 1, "High": 2}


# ------------------------------------------------------------------ tree
def parent_map(caps: pd.DataFrame) -> dict[str, str]:
    return dict(zip(caps["cap_id"], caps["parent_cap_id"]))


def children_map(caps: pd.DataFrame) -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for cid, pid in zip(caps["cap_id"], caps["parent_cap_id"]):
        if pid:
            out.setdefault(pid, []).append(cid)
    return out


def ancestors(cap_id: str, parent: dict[str, str]) -> list[str]:
    """Parents from nearest to the root. Stops on a loop or an unknown parent."""
    out, seen, cur = [], {cap_id}, parent.get(cap_id, "")
    while cur and cur in parent and cur not in seen:
        out.append(cur)
        seen.add(cur)
        cur = parent.get(cur, "")
    return out


def subtree(cap_id: str, children: dict[str, list[str]]) -> set[str]:
    """The capability and everything beneath it."""
    out, stack = set(), [cap_id]
    while stack:
        c = stack.pop()
        if c in out:
            continue
        out.add(c)
        stack.extend(children.get(c, []))
    return out


def root_of(cap_id: str, parent: dict[str, str]) -> str:
    anc = ancestors(cap_id, parent)
    return anc[-1] if anc else cap_id


def paths(caps: pd.DataFrame) -> dict[str, str]:
    """cap_id -> 'Level 1 > Level 2 > Level 3' using names."""
    parent, name = parent_map(caps), dict(zip(caps["cap_id"], caps["name"]))
    return {c: " > ".join(name.get(a, a) for a in reversed([c] + ancestors(c, parent))) for c in caps["cap_id"]}


# -------------------------------------------------------------- findings
def findings(caps: pd.DataFrame, ac: pd.DataFrame, apps: pd.DataFrame) -> dict:
    """Gaps, overlaps and orphans.

    gap      leaf capability that no application supports, directly or through a parent mapping
    overlap  capability with more than one Primary application
    orphan   application mapped to no capability
    """
    parent, children = parent_map(caps), children_map(caps)
    direct = set(ac["cap_id"])
    gaps = [c for c in caps["cap_id"]
            if c not in children and c not in direct and not any(a in direct for a in ancestors(c, parent))]
    prim = ac[ac["support_level"] == "Primary"].groupby("cap_id")["app_id"].apply(lambda s: sorted(set(s)))
    overlaps = {c: a for c, a in prim.items() if len(a) > 1}
    orphans = [a for a in apps["app_id"] if a not in set(ac["app_id"])]
    return {"gaps": gaps, "overlaps": overlaps, "orphans": orphans}


# --------------------------------------------------------------- roll-up
def rollup(caps: pd.DataFrame, ac: pd.DataFrame, apps: pd.DataFrame) -> pd.DataFrame:
    """One row per capability with application and technology-exposure numbers for its whole subtree.

    `apps` must carry the scored columns from the model: criticality, high_risk_techs,
    medium_risk_techs, disinvest_techs, out_of_support.
    """
    children = children_map(caps)
    a = apps.set_index("app_id")
    rows = []
    for _, c in caps.iterrows():
        sub = subtree(c["cap_id"], children)
        m = ac[ac["cap_id"].isin(sub)]
        ids = sorted(set(m["app_id"]) & set(a.index))
        s = a.loc[ids] if ids else a.iloc[0:0]
        prim = m[m["support_level"] == "Primary"]["app_id"].nunique()
        high = int((s["high_risk_techs"] > 0).sum()) if len(s) else 0
        med = int(((s["high_risk_techs"] == 0) & (s["medium_risk_techs"] > 0)).sum()) if len(s) else 0
        rows.append({
            "cap_id": c["cap_id"], "apps": len(ids), "primary_apps": prim,
            "tier1_apps": int((s["criticality"] == "Tier 1").sum()) if len(s) else 0,
            "high_risk_apps": high,
            "disinvest_apps": int((s["disinvest_techs"] > 0).sum()) if len(s) else 0,
            "oos_apps": int((s["out_of_support"] > 0).sum()) if len(s) else 0,
            "worst_risk": "High" if high else ("Medium" if med else ("Low" if len(s) else "None")),
        })
    out = caps.merge(pd.DataFrame(rows), on="cap_id", how="left")
    out["is_gap"] = out["apps"] == 0
    return out


def technologies_under(stack: pd.DataFrame, ac: pd.DataFrame, caps: pd.DataFrame, cap_id: str) -> pd.DataFrame:
    """Technologies used by the applications beneath a capability, with how many of those applications use each."""
    sub = subtree(cap_id, children_map(caps))
    ids = set(ac[ac["cap_id"].isin(sub)]["app_id"])
    s = stack[stack["app_id"].isin(ids)]
    if s.empty:
        return s
    g = s.groupby("tech_id").agg(apps_in_capability=("app_id", "nunique")).reset_index()
    cols = ["tech_id", "label", "service", "standard_status", "investment_stance", "support_state",
            "end_of_support", "replacement", "priority", "risk_level"]
    t = s.drop_duplicates("tech_id")[cols]
    return g.merge(t, on="tech_id").sort_values(["priority", "apps_in_capability"], ascending=False)


# ------------------------------------------------------ area membership
def membership(apps: pd.DataFrame, caps: pd.DataFrame | None, ac: pd.DataFrame | None,
               org: pd.DataFrame | None, dimension: str) -> pd.DataFrame:
    """app_id -> area label for one dimension: 'Organisation unit', 'Business domain' or 'L1 capability'."""
    if dimension == "Business domain":
        return apps[["app_id", "business_domain"]].rename(columns={"business_domain": "area"})
    if dimension == "Organisation unit":
        names = dict(zip(org["org_unit_id"], org["name"]))
        out = apps[["app_id", "org_unit_id"]].copy()
        out["area"] = out["org_unit_id"].map(names).fillna("(no org unit)")
        return out[["app_id", "area"]]
    parent, names = parent_map(caps), dict(zip(caps["cap_id"], caps["name"]))
    m = ac[["app_id", "cap_id"]].copy()
    m["area"] = m["cap_id"].map(lambda c: names.get(root_of(c, parent), c))
    return m[["app_id", "area"]].drop_duplicates()


def area_table(apps: pd.DataFrame, stack: pd.DataFrame, mem: pd.DataFrame) -> pd.DataFrame:
    """Exposure numbers per area. An application can sit in several areas (capabilities), once in each."""
    a = mem.merge(apps, on="app_id", how="left")
    g = a.groupby("area").agg(
        apps=("app_id", "nunique"),
        tier1_apps=("criticality", lambda s: int((s == "Tier 1").sum())),
        high_risk_apps=("high_risk_techs", lambda s: int((s > 0).sum())),
        disinvest_apps=("disinvest_techs", lambda s: int((s > 0).sum())),
        oos_apps=("out_of_support", lambda s: int((s > 0).sum())),
        debt_score=("debt_priority", "sum"),
    ).reset_index()
    g["pct_high_risk"] = (100 * g["high_risk_apps"] / g["apps"]).round(0)
    g["pct_disinvest"] = (100 * g["disinvest_apps"] / g["apps"]).round(0)
    return g.sort_values("high_risk_apps", ascending=False)


def stance_mix(stack: pd.DataFrame, mem: pd.DataFrame) -> pd.DataFrame:
    """Distinct technologies per area and investment stance."""
    s = mem.merge(stack[["app_id", "tech_id", "investment_stance"]], on="app_id")
    return s.groupby(["area", "investment_stance"])["tech_id"].nunique().reset_index(name="technologies")
