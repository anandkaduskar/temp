"""Capability heatmap HTML. Colour is never the only signal: every tile also says it in words."""
from __future__ import annotations

import html

import pandas as pd

from .capability import children_map

HEAT_RISK = "Worst technology risk"
HEAT_DISINVEST = "Applications on Disinvest technology"
HEAT_METRICS = [HEAT_RISK, HEAT_DISINVEST]

COLOURS = {"High": "#b91c1c", "Medium": "#b45309", "Low": "#0f766e", "None": "#64748b"}

_CSS = """
<style>
.cap-legend{display:flex;flex-wrap:wrap;gap:.5rem 1rem;margin:.25rem 0 1rem 0;font-size:.85rem}
.cap-legend .sw{display:inline-block;width:.8rem;height:.8rem;border-radius:3px;margin-right:.35rem;vertical-align:-1px}
.cap-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(330px,1fr));gap:1rem}
.cap-l1{border:1px solid rgba(128,128,128,.35);border-radius:10px;overflow:hidden}
.cap-l1 h4{margin:0;padding:.55rem .8rem;font-size:.95rem;background:rgba(128,128,128,.14);border-bottom:1px solid rgba(128,128,128,.25);display:flex;justify-content:space-between;gap:.5rem}
.cap-l1 h4 span{font-weight:400;font-size:.78rem;opacity:.8;white-space:nowrap}
.cap-body{padding:.6rem .7rem;display:flex;flex-direction:column;gap:.4rem}
.cap-tile{color:#fff;border-radius:7px;padding:.35rem .6rem}
.cap-tile .t{font-size:.82rem;font-weight:600}
.cap-tile .s{font-size:.72rem;opacity:.92}
.cap-kids{display:flex;flex-wrap:wrap;gap:.25rem;margin-top:.3rem}
.cap-kid{font-size:.7rem;padding:.08rem .45rem;border-radius:999px;background:rgba(255,255,255,.22);border:1px solid rgba(255,255,255,.5)}
.cap-kid.gap{background:transparent;border:1px dashed rgba(255,255,255,.8)}
.cap-tile.gap{background:transparent;color:inherit;border:2px dashed rgba(128,128,128,.7)}
.cap-tile.gap .s{opacity:.75}
.cap-tile.gap .cap-kid{border:1px dashed rgba(128,128,128,.7);background:transparent}
</style>
"""


def legend_html(metric: str) -> str:
    if metric == HEAT_RISK:
        items = [("High", "High: an application beneath has a High-risk technology"),
                 ("Medium", "Medium: Medium-risk technology, none High"),
                 ("Low", "Low: all technologies Low risk"),
                 ("None", "Gap: no application supports it (dashed)")]
    else:
        items = [("High", "Over 25% of applications run on a Disinvest technology"),
                 ("Medium", "Up to 25%"),
                 ("Low", "None"),
                 ("None", "Gap: no application supports it (dashed)")]
    parts = [f'<span><span class="sw" style="background:{COLOURS[k]}"></span>{html.escape(v)}</span>' for k, v in items]
    return _CSS + '<div class="cap-legend">' + "".join(parts) + "</div>"


def _heat(row: pd.Series, metric: str) -> str:
    if row["apps"] == 0:
        return "None"
    if metric == HEAT_RISK:
        return row["worst_risk"]
    pct = row["disinvest_apps"] / row["apps"]
    return "High" if pct > 0.25 else ("Medium" if pct > 0 else "Low")


def _words(row: pd.Series, metric: str) -> str:
    if row["apps"] == 0:
        return "no application"
    n = f'{int(row["apps"])} app' + ("" if row["apps"] == 1 else "s")
    if metric == HEAT_RISK:
        return f'{n} | {row["worst_risk"]} risk | {int(row["high_risk_apps"])} High'
    return f'{n} | {int(row["disinvest_apps"])} on Disinvest'


def _tip(row: pd.Series) -> str:
    return (f'{row["cap_id"]} {row["name"]} | confidence: {row["source_confidence"] or "n/a"} | '
            f'{int(row["apps"])} apps ({int(row["tier1_apps"])} Tier 1) | '
            f'{int(row["high_risk_apps"])} with High-risk tech | {int(row["disinvest_apps"])} on Disinvest | '
            f'{int(row["oos_apps"])} with out-of-support tech')


def capability_map_html(rollup: pd.DataFrame, metric: str) -> str:
    """L1 domains as cards; L2 as coloured tiles; L3 as small chips inside their L2 tile."""
    kids = children_map(rollup)
    by_id = rollup.set_index("cap_id", drop=False)
    out = [_CSS, '<div class="cap-grid">']
    for _, l1 in rollup[rollup["level"] == "L1"].iterrows():
        out.append(f'<div class="cap-l1"><h4>{html.escape(l1["name"])}<span>{_words(l1, metric)}</span></h4><div class="cap-body">')
        for l2_id in kids.get(l1["cap_id"], []):
            l2 = by_id.loc[l2_id]
            heat = _heat(l2, metric)
            cls = "cap-tile gap" if heat == "None" else "cap-tile"
            style = "" if heat == "None" else f' style="background:{COLOURS[heat]}"'
            out.append(f'<div class="{cls}"{style} title="{html.escape(_tip(l2))}">'
                       f'<div class="t">{html.escape(l2["name"])}</div><div class="s">{html.escape(_words(l2, metric))}</div>')
            l3s = kids.get(l2_id, [])
            if l3s:
                out.append('<div class="cap-kids">')
                for l3_id in l3s:
                    l3 = by_id.loc[l3_id]
                    h3 = _heat(l3, metric)
                    mark = "gap" if h3 == "None" else f'{h3.lower()}'
                    kid_style = "" if h3 == "None" else f' style="background:{COLOURS[h3]};color:#fff"'
                    out.append(f'<span class="cap-kid{" gap" if h3 == "None" else ""}"{kid_style} title="{html.escape(_tip(l3))}">'
                               f'{html.escape(l3["name"])} ({"gap" if h3 == "None" else mark})</span>')
                out.append("</div>")
            out.append("</div>")
        out.append("</div></div>")
    out.append("</div>")
    return "".join(out)
