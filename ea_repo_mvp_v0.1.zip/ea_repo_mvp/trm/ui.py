"""Shared colours and small HTML components."""
from __future__ import annotations

import html

import pandas as pd

from .data import STATUSES
from .model import Model

# White text reads on all of these. Status is always also shown as text (tooltip, table).
STATUS_COLOURS = {
    "Strategic": "#0f766e",
    "Standard": "#1d4ed8",
    "Emerging": "#6d28d9",
    "Contain": "#b45309",
    "Retire": "#b91c1c",
    "Prohibited": "#4c0519",
}
RISK_COLOURS = {"High": "#b91c1c", "Medium": "#d97706", "Low": "#0f766e"}
STATUS_MEANING = {
    "Strategic": "Preferred for new work",
    "Standard": "Approved for use",
    "Emerging": "Being piloted or evaluated",
    "Contain": "No new use; keep running",
    "Retire": "Planned removal",
    "Prohibited": "Must not be used",
}

_CSS = """
<style>
.trm-legend{display:flex;flex-wrap:wrap;gap:.5rem 1rem;margin:.25rem 0 1rem 0;font-size:.85rem}
.trm-legend span.sw{display:inline-block;width:.8rem;height:.8rem;border-radius:3px;margin-right:.35rem;vertical-align:-1px}
.trm-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:1rem}
.trm-area{border:1px solid rgba(128,128,128,.35);border-radius:10px;overflow:hidden}
.trm-area h4{margin:0;padding:.55rem .8rem;font-size:.95rem;background:rgba(128,128,128,.14);border-bottom:1px solid rgba(128,128,128,.25)}
.trm-cat{padding:.5rem .8rem .2rem .8rem}
.trm-cat .cat{font-size:.72rem;letter-spacing:.04em;text-transform:uppercase;opacity:.7;margin-bottom:.25rem}
.trm-svc{display:flex;gap:.5rem;align-items:flex-start;margin-bottom:.45rem}
.trm-svc .name{flex:0 0 7.2rem;font-size:.8rem;opacity:.85;padding-top:.2rem}
.trm-chips{display:flex;flex-wrap:wrap;gap:.25rem}
.chip{color:#fff;font-size:.75rem;padding:.12rem .5rem;border-radius:999px;white-space:nowrap}
.chip.dim{opacity:.22}
.chip.hl{outline:3px solid #facc15;outline-offset:1px;font-weight:600}
.chip.empty{background:transparent;color:inherit;opacity:.45;border:1px dashed rgba(128,128,128,.6)}
</style>
"""


def legend_html() -> str:
    parts = [
        f'<span><span class="sw" style="background:{STATUS_COLOURS[s]}"></span><b>{s}</b> &middot; {STATUS_MEANING[s]}</span>'
        for s in STATUSES
    ]
    return _CSS + '<div class="trm-legend">' + "".join(parts) + "</div>"


def trm_map_html(model: Model, statuses: list[str], areas: list[str], highlight: set[str] | None = None) -> str:
    """The classic layered reference model: area > category > service > product chips."""
    t = model.technologies
    t = t[t["standard_status"].isin(statuses)]
    out = [_CSS, '<div class="trm-grid">']
    svc = model.services
    for area in [a for a in svc["service_area"].drop_duplicates() if a in areas]:
        out.append(f'<div class="trm-area"><h4>{html.escape(area)}</h4>')
        area_svc = svc[svc["service_area"] == area]
        for cat in area_svc["service_category"].drop_duplicates():
            out.append(f'<div class="trm-cat"><div class="cat">{html.escape(cat)}</div>')
            for _, s in area_svc[area_svc["service_category"] == cat].iterrows():
                chips = []
                for _, r in t[t["service_id"] == s["service_id"]].sort_values(["standard_status", "label"], key=lambda c: c.map({v: i for i, v in enumerate(STATUSES)}) if c.name == "standard_status" else c).iterrows():
                    cls = "chip"
                    if highlight is not None:
                        cls += " hl" if r["tech_id"] in highlight else " dim"
                    warn = " !" if r["support_state"] == "Out of support" else ""
                    eos = r["end_of_support"].strftime("%d %b %Y") if pd.notna(r["end_of_support"]) else "no date"
                    tip = f'{r["label"]} | {r["standard_status"]} | support ends: {eos} | used by {r["app_count"]} application(s)'
                    chips.append(f'<span class="{cls}" style="background:{STATUS_COLOURS.get(r["standard_status"], "#555")}" title="{html.escape(tip)}">{html.escape(r["label"])}{warn}</span>')
                if not chips:
                    chips.append('<span class="chip empty">none</span>')
                out.append(f'<div class="trm-svc"><div class="name">{html.escape(s["service"])}</div><div class="trm-chips">{"".join(chips)}</div></div>')
            out.append("</div>")
        out.append("</div>")
    out.append("</div>")
    return "".join(out)


def money(v: float) -> str:
    if v >= 1_000_000:
        return f"${v/1_000_000:.1f}M"
    if v >= 1_000:
        return f"${v/1_000:.0f}K"
    return f"${v:.0f}"
