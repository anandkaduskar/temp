"""Loading and validating the TRM data.

The app only talks to `TrmRepository`. Today the implementation reads CSV files;
a SQL implementation can replace it later without touching the pages.

Four files are required (services, technologies, applications, app_technology).
Three are optional and switch on the capability pages: capabilities, app_capability, org_units.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO, Mapping, Protocol

import pandas as pd

from .capability import ancestors, findings, parent_map

STATUSES = ["Strategic", "Standard", "Emerging", "Contain", "Retire", "Prohibited"]
CRITICALITIES = ["Tier 1", "Tier 2", "Tier 3"]
DEPLOYMENT_MODELS = ["SaaS", "PaaS", "Self-managed", "Appliance"]
INVESTMENT_STANCES = ["Invest", "Maintain", "Disinvest"]
SUPPORT_LEVELS = ["Primary", "Supporting"]
FITS = ["Good", "Partial", "Poor"]

# When a technology file has no investment_stance column, this default is used.
STANCE_FROM_STATUS = {
    "Strategic": "Invest", "Emerging": "Invest", "Standard": "Maintain",
    "Contain": "Disinvest", "Retire": "Disinvest", "Prohibited": "Disinvest",
}

FILES = {
    "services": "services.csv",
    "technologies": "technologies.csv",
    "applications": "applications.csv",
    "links": "app_technology.csv",
}
OPTIONAL_FILES = {
    "capabilities": "capabilities.csv",
    "app_capability": "app_capability.csv",
    "org_units": "org_units.csv",
}
ALL_FILES = {**FILES, **OPTIONAL_FILES}

REQUIRED_COLUMNS = {
    "services": ["service_id", "service_area", "service_category", "service"],
    "technologies": ["tech_id", "name", "vendor", "version", "service_id", "standard_status",
                     "deployment_model", "end_of_support", "owner_team", "annual_cost_usd"],
    "applications": ["app_id", "name", "business_domain", "criticality", "owner_team", "lifecycle"],
    "links": ["app_id", "tech_id", "usage"],
}
OPTIONAL_COLUMNS = {
    "capabilities": ["cap_id", "parent_cap_id", "level", "name", "owner_org_unit_id"],
    "app_capability": ["app_id", "cap_id", "support_level", "fit"],
    "org_units": ["org_unit_id", "parent_org_unit_id", "name"],
}


@dataclass
class TrmData:
    services: pd.DataFrame
    technologies: pd.DataFrame
    applications: pd.DataFrame
    links: pd.DataFrame
    capabilities: pd.DataFrame | None = None
    app_capability: pd.DataFrame | None = None
    org_units: pd.DataFrame | None = None

    def counts(self) -> dict[str, int]:
        out = {k: len(getattr(self, k)) for k in FILES}
        for k in OPTIONAL_FILES:
            df = getattr(self, k)
            if df is not None:
                out[k] = len(df)
        return out

    @property
    def has_capabilities(self) -> bool:
        return self.capabilities is not None and self.app_capability is not None


class TrmRepository(Protocol):
    def load(self) -> TrmData: ...


def _read(source) -> pd.DataFrame:
    # Everything is read as text so versions such as "3.9" and "2012 R2" survive.
    df = pd.read_csv(source, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    df.columns = [c.strip() for c in df.columns]
    return df.apply(lambda col: col.str.strip())


class CsvRepository:
    """Reads the CSV files from a folder. The three capability files are optional."""

    def __init__(self, folder: str | Path):
        self.folder = Path(folder)

    def load(self) -> TrmData:
        frames = {}
        for key, fname in FILES.items():
            path = self.folder / fname
            if not path.exists():
                raise FileNotFoundError(f"Missing file: {path}")
            frames[key] = _read(path)
        for key, fname in OPTIONAL_FILES.items():
            path = self.folder / fname
            if path.exists():
                frames[key] = _read(path)
        return TrmData(**frames)


class UploadRepository:
    """Reads CSV files from uploaded file objects, keyed by logical name."""

    def __init__(self, files: Mapping[str, BinaryIO]):
        self.files = files

    def load(self) -> TrmData:
        missing = [k for k in FILES if k not in self.files or self.files[k] is None]
        if missing:
            raise FileNotFoundError("Missing uploads: " + ", ".join(FILES[m] for m in missing))
        frames = {k: _read(self.files[k]) for k in FILES}
        for k in OPTIONAL_FILES:
            if self.files.get(k) is not None:
                frames[k] = _read(self.files[k])
        return TrmData(**frames)


# --------------------------------------------------------------- validation
def validate(data: TrmData) -> pd.DataFrame:
    """Return one row per problem found. An empty frame means the data is clean."""
    issues: list[dict] = []

    def add(severity, file, row, check, detail):
        issues.append({"severity": severity, "file": ALL_FILES[file], "row": row, "check": check, "detail": detail})

    frames = {k: getattr(data, k) for k in FILES}

    for key, cols in REQUIRED_COLUMNS.items():
        missing = [c for c in cols if c not in frames[key].columns]
        for c in missing:
            add("Error", key, "", "Missing column", c)
    for key, cols in OPTIONAL_COLUMNS.items():
        df = getattr(data, key)
        if df is None:
            continue
        for c in [c for c in cols if c not in df.columns]:
            add("Error", key, "", "Missing column", c)
    if any(i["check"] == "Missing column" for i in issues):
        return pd.DataFrame(issues)

    svc, tech, apps, links = data.services, data.technologies, data.applications, data.links

    # duplicate keys
    for key, col in [("services", "service_id"), ("technologies", "tech_id"), ("applications", "app_id")]:
        dup = frames[key][frames[key][col].duplicated(keep=False) & (frames[key][col] != "")]
        for idx, r in dup.iterrows():
            add("Error", key, idx + 2, "Duplicate id", r[col])

    # blank ids
    for key, col in [("services", "service_id"), ("technologies", "tech_id"), ("applications", "app_id")]:
        for idx in frames[key].index[frames[key][col] == ""]:
            add("Error", key, idx + 2, "Blank id", col)

    # vocabularies
    for idx, r in tech.iterrows():
        if r["standard_status"] not in STATUSES:
            add("Error", "technologies", idx + 2, "Unknown status", f"{r['tech_id']}: '{r['standard_status']}'")
        if r["deployment_model"] not in DEPLOYMENT_MODELS:
            add("Warning", "technologies", idx + 2, "Unknown deployment model", f"{r['tech_id']}: '{r['deployment_model']}'")
        if r["end_of_support"] and pd.isna(pd.to_datetime(r["end_of_support"], errors="coerce")):
            add("Error", "technologies", idx + 2, "Invalid date", f"{r['tech_id']}: '{r['end_of_support']}'")
        if r["annual_cost_usd"] and pd.isna(pd.to_numeric(r["annual_cost_usd"], errors="coerce")):
            add("Error", "technologies", idx + 2, "Invalid cost", f"{r['tech_id']}: '{r['annual_cost_usd']}'")
        if not r["owner_team"]:
            add("Warning", "technologies", idx + 2, "Missing owner", r["tech_id"])
    for idx, r in apps.iterrows():
        if r["criticality"] not in CRITICALITIES:
            add("Error", "applications", idx + 2, "Unknown criticality", f"{r['app_id']}: '{r['criticality']}'")
        if not r["owner_team"]:
            add("Warning", "applications", idx + 2, "Missing owner", r["app_id"])

    # referential integrity
    service_ids = set(svc["service_id"])
    for idx, r in tech.iterrows():
        if r["service_id"] not in service_ids:
            add("Error", "technologies", idx + 2, "Unknown service", f"{r['tech_id']} -> '{r['service_id']}'")
    tech_ids, app_ids = set(tech["tech_id"]), set(apps["app_id"])
    for idx, r in links.iterrows():
        if r["app_id"] not in app_ids:
            add("Error", "links", idx + 2, "Unknown application", r["app_id"])
        if r["tech_id"] not in tech_ids:
            add("Error", "links", idx + 2, "Unknown technology", r["tech_id"])
    dup_links = links[links.duplicated(["app_id", "tech_id"], keep=False)]
    for idx, r in dup_links.iterrows():
        add("Warning", "links", idx + 2, "Duplicate link", f"{r['app_id']} / {r['tech_id']}")

    # coverage
    used_apps, used_tech = set(links["app_id"]), set(links["tech_id"])
    for idx, r in apps.iterrows():
        if r["app_id"] not in used_apps:
            add("Warning", "applications", idx + 2, "Application has no technologies", r["app_id"])
    for idx, r in tech.iterrows():
        if r["tech_id"] not in used_tech and r["standard_status"] in ("Retire", "Contain", "Prohibited"):
            add("Info", "technologies", idx + 2, "Technology unused and can be removed", f"{r['tech_id']} {r['name']} {r['version']}")

    _validate_extensions(data, add)

    cols = ["severity", "file", "row", "check", "detail"]
    return pd.DataFrame(issues, columns=cols)


def _validate_extensions(data: TrmData, add) -> None:
    """Investment stance, org units, capabilities and the capability mapping. All optional."""
    tech, apps = data.technologies, data.applications

    if "investment_stance" in tech.columns:
        for idx, r in tech.iterrows():
            if r["investment_stance"] not in INVESTMENT_STANCES:
                add("Error", "technologies", idx + 2, "Unknown investment stance", f"{r['tech_id']}: '{r['investment_stance']}'")
    if "replacement_tech_id" in tech.columns:
        ids = set(tech["tech_id"])
        for idx, r in tech.iterrows():
            rid = r["replacement_tech_id"]
            if rid and rid not in ids:
                add("Error", "technologies", idx + 2, "Unknown replacement technology", f"{r['tech_id']} -> '{rid}'")
            elif rid and rid == r["tech_id"]:
                add("Error", "technologies", idx + 2, "Technology replaces itself", r["tech_id"])

    org_ids = None
    if data.org_units is not None:
        ou = data.org_units
        for idx, r in ou[ou["org_unit_id"].duplicated(keep=False)].iterrows():
            add("Error", "org_units", idx + 2, "Duplicate id", r["org_unit_id"])
        org_ids = set(ou["org_unit_id"])
        for idx, r in ou.iterrows():
            if r["parent_org_unit_id"] and r["parent_org_unit_id"] not in org_ids:
                add("Error", "org_units", idx + 2, "Unknown parent org unit", f"{r['org_unit_id']} -> '{r['parent_org_unit_id']}'")
        if "org_unit_id" in apps.columns:
            for idx, r in apps.iterrows():
                if not r["org_unit_id"]:
                    add("Warning", "applications", idx + 2, "Missing org unit", r["app_id"])
                elif r["org_unit_id"] not in org_ids:
                    add("Error", "applications", idx + 2, "Unknown org unit", f"{r['app_id']} -> '{r['org_unit_id']}'")

    caps = data.capabilities
    if caps is not None:
        cap_ids = set(caps["cap_id"])
        for idx, r in caps[caps["cap_id"].duplicated(keep=False)].iterrows():
            add("Error", "capabilities", idx + 2, "Duplicate id", r["cap_id"])
        parent = parent_map(caps)
        for idx, r in caps.iterrows():
            p = r["parent_cap_id"]
            if p and p not in cap_ids:
                add("Error", "capabilities", idx + 2, "Unknown parent capability", f"{r['cap_id']} -> '{p}'")
            elif not p and r["level"] != "L1":
                add("Error", "capabilities", idx + 2, "Missing parent", f"{r['cap_id']} is {r['level']} but has no parent")
            else:
                depth = len(ancestors(r["cap_id"], parent)) + 1
                if r["level"] != f"L{depth}":
                    add("Warning", "capabilities", idx + 2, "Level does not match hierarchy", f"{r['cap_id']}: {r['level']} but depth is {depth}")
            if org_ids is not None and r["owner_org_unit_id"] and r["owner_org_unit_id"] not in org_ids:
                add("Error", "capabilities", idx + 2, "Unknown owner org unit", f"{r['cap_id']} -> '{r['owner_org_unit_id']}'")

    ac = data.app_capability
    if ac is not None:
        app_ids = set(apps["app_id"])
        cap_ids = set(caps["cap_id"]) if caps is not None else None
        for idx, r in ac.iterrows():
            if r["app_id"] not in app_ids:
                add("Error", "app_capability", idx + 2, "Unknown application", r["app_id"])
            if cap_ids is not None and r["cap_id"] not in cap_ids:
                add("Error", "app_capability", idx + 2, "Unknown capability", r["cap_id"])
            if r["support_level"] not in SUPPORT_LEVELS:
                add("Error", "app_capability", idx + 2, "Unknown support level", f"{r['app_id']} / {r['cap_id']}: '{r['support_level']}'")
            if r["fit"] not in FITS:
                add("Error", "app_capability", idx + 2, "Unknown fit", f"{r['app_id']} / {r['cap_id']}: '{r['fit']}'")
        for idx, r in ac[ac.duplicated(["app_id", "cap_id"], keep=False)].iterrows():
            add("Warning", "app_capability", idx + 2, "Duplicate mapping", f"{r['app_id']} / {r['cap_id']}")

    # findings are only meaningful when the references above are sound
    if caps is not None and ac is not None:
        known = ac[ac["app_id"].isin(set(apps["app_id"])) & ac["cap_id"].isin(set(caps["cap_id"]))]
        f = findings(caps, known, apps)
        names = dict(zip(caps["cap_id"], caps["name"]))
        row_of = {c: i + 2 for i, c in enumerate(caps["cap_id"])}
        for c in f["gaps"]:
            add("Info", "capabilities", row_of[c], "Capability has no application", f"{c} {names[c]}")
        for c, a in f["overlaps"].items():
            add("Info", "app_capability", "", "Several primary applications", f"{c} {names.get(c, '')}: {', '.join(a)}")
        arow = {a: i + 2 for i, a in enumerate(apps["app_id"])}
        for a in f["orphans"]:
            add("Info", "applications", arow[a], "Application supports no capability", a)
