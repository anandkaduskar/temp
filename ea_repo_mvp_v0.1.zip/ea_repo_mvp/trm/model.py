"""Derived measures: support state, risk score and per-application views.

The scoring rules are deliberately simple and written down so reviewers can
challenge them. Change the tables below to change the model.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from . import capability as cap
from .data import STANCE_FROM_STATUS, TrmData

# Points for the standards position of a technology.
STATUS_POINTS = {"Strategic": 0, "Standard": 0, "Emerging": 1, "Contain": 2, "Retire": 4, "Prohibited": 5}

# Points for how close the vendor end-of-support date is.
SUPPORT_ORDER = ["Out of support", "Under 6 months", "6 to 12 months", "12 to 24 months", "Supported", "No date (vendor managed)", "No date (self-managed)"]
SUPPORT_POINTS = {
    "Out of support": 5,
    "Under 6 months": 4,
    "6 to 12 months": 3,
    "12 to 24 months": 1,
    "Supported": 0,
    "No date (vendor managed)": 0,
    "No date (self-managed)": 1,
}

# Weight of the most critical application that depends on the technology.
CRITICALITY_WEIGHT = {"Tier 1": 3, "Tier 2": 2, "Tier 3": 1}

HIGH_AT, MEDIUM_AT = 15, 6  # priority score thresholds

# Support states that count as "ending soon" when checking an Invest stance.
ENDING_SOON = ("Out of support", "Under 6 months", "6 to 12 months")


def support_state(eos: pd.Timestamp, deployment: str, as_of: pd.Timestamp) -> str:
    if pd.isna(eos):
        return "No date (vendor managed)" if deployment in ("SaaS", "PaaS") else "No date (self-managed)"
    months = (eos.year - as_of.year) * 12 + (eos.month - as_of.month) + (eos.day - as_of.day) / 30
    if eos < as_of:
        return "Out of support"
    if months < 6:
        return "Under 6 months"
    if months < 12:
        return "6 to 12 months"
    if months < 24:
        return "12 to 24 months"
    return "Supported"


def risk_level(priority: float) -> str:
    if priority >= HIGH_AT:
        return "High"
    if priority >= MEDIUM_AT:
        return "Medium"
    return "Low"


def stance_conflict(stance: str, status: str, support: str) -> str:
    """Explain why a declared investment stance contradicts the rest of the record, or return ''."""
    if stance == "Invest" and support in ENDING_SOON:
        return "Invest, but vendor support has ended or ends within 12 months"
    if stance == "Invest" and status in ("Contain", "Retire", "Prohibited"):
        return f"Invest, but standards status is {status}"
    if stance == "Disinvest" and status == "Strategic":
        return "Disinvest, but standards status is Strategic"
    return ""


@dataclass
class Model:
    """Everything the pages need, already joined and scored."""

    as_of: pd.Timestamp
    technologies: pd.DataFrame     # one row per technology, with service, usage and risk
    applications: pd.DataFrame     # one row per application, with stack risk
    stack: pd.DataFrame            # one row per application-technology link, fully joined
    services: pd.DataFrame
    # present only when the capability files are loaded
    capabilities: pd.DataFrame | None = None
    app_capability: pd.DataFrame | None = None
    org_units: pd.DataFrame | None = None
    cap_rollup: pd.DataFrame | None = None
    findings: dict | None = None

    @property
    def has_capabilities(self) -> bool:
        return self.cap_rollup is not None


def build(data: TrmData, as_of: pd.Timestamp) -> Model:
    svc = data.services.copy()
    tech = data.technologies.copy()
    apps = data.applications.copy()
    links = data.links.drop_duplicates(["app_id", "tech_id"]).copy()

    tech["end_of_support"] = pd.to_datetime(tech["end_of_support"], errors="coerce")
    tech["annual_cost_usd"] = pd.to_numeric(tech["annual_cost_usd"], errors="coerce").fillna(0.0)
    tech["label"] = (tech["name"] + " " + tech["version"]).str.strip()

    # investment stance: declared in the file, or derived from the standards status
    derived = tech["standard_status"].map(STANCE_FROM_STATUS).fillna("Maintain")
    if "investment_stance" in tech.columns:
        tech["stance_source"] = np.where(tech["investment_stance"] != "", "declared", "derived")
        tech["investment_stance"] = tech["investment_stance"].where(tech["investment_stance"] != "", derived)
    else:
        tech["investment_stance"], tech["stance_source"] = derived, "derived"
    for col in ("replacement_tech_id", "stance_note"):
        if col not in tech.columns:
            tech[col] = ""
    tech["derived_stance"] = derived
    tech["replacement"] = tech["replacement_tech_id"].map(dict(zip(tech["tech_id"], tech["label"]))).fillna("")

    tech = tech.merge(svc, on="service_id", how="left")
    tech["support_state"] = [support_state(e, d, as_of) for e, d in zip(tech["end_of_support"], tech["deployment_model"])]
    tech["status_points"] = tech["standard_status"].map(STATUS_POINTS).fillna(0).astype(int)
    tech["support_points"] = tech["support_state"].map(SUPPORT_POINTS).fillna(0).astype(int)
    tech["tech_score"] = tech["status_points"] + tech["support_points"]
    tech["months_to_support_end"] = ((tech["end_of_support"] - as_of).dt.days / 30.4).round(1)
    tech["stance_conflict"] = [stance_conflict(a, b, c) for a, b, c in zip(tech["investment_stance"], tech["standard_status"], tech["support_state"])]

    stack = (
        links.merge(apps, on="app_id", how="left", suffixes=("", "_app"))
        .merge(tech, on="tech_id", how="left", suffixes=("_app", ""))
    )
    # after the merges: `name_app` is the application name, `name` is the technology name
    stack = stack.rename(columns={"name_app": "application", "owner_team_app": "app_owner", "owner_team": "tech_owner"})
    stack["crit_weight"] = stack["criticality"].map(CRITICALITY_WEIGHT).fillna(1).astype(int)

    usage = stack.groupby("tech_id").agg(
        app_count=("app_id", "nunique"),
        max_crit_weight=("crit_weight", "max"),
        tier1_apps=("criticality", lambda s: int((s == "Tier 1").sum())),
    )
    tech = tech.merge(usage, on="tech_id", how="left")
    tech[["app_count", "max_crit_weight", "tier1_apps"]] = tech[["app_count", "max_crit_weight", "tier1_apps"]].fillna(0).astype(int)
    tech["priority"] = tech["tech_score"] * tech["max_crit_weight"]
    tech["risk_level"] = tech["priority"].map(risk_level)
    tech.loc[tech["app_count"] == 0, "risk_level"] = "Low"

    stack = stack.merge(tech[["tech_id", "priority", "risk_level", "app_count"]], on="tech_id", how="left", suffixes=("", "_t"))
    # a shared technology's cost is split across the applications that use it
    stack["cost_share_usd"] = stack["annual_cost_usd"] / stack["app_count"].clip(lower=1)

    app_stats = stack.groupby("app_id").agg(
        technologies=("tech_id", "nunique"),
        retire_or_prohibited=("standard_status", lambda s: int(s.isin(["Retire", "Prohibited"]).sum())),
        out_of_support=("support_state", lambda s: int((s == "Out of support").sum())),
        disinvest_techs=("investment_stance", lambda s: int((s == "Disinvest").sum())),
        high_risk_techs=("risk_level", lambda s: int((s == "High").sum())),
        medium_risk_techs=("risk_level", lambda s: int((s == "Medium").sum())),
        stack_debt=("tech_score", "sum"),
        allocated_cost_usd=("cost_share_usd", "sum"),
    ).reset_index()
    zero = {c: 0 for c in ("technologies", "retire_or_prohibited", "out_of_support", "disinvest_techs",
                           "high_risk_techs", "medium_risk_techs", "stack_debt", "allocated_cost_usd")}
    apps = apps.merge(app_stats, on="app_id", how="left").fillna(zero)
    apps["crit_weight"] = apps["criticality"].map(CRITICALITY_WEIGHT).fillna(1).astype(int)
    apps["debt_priority"] = apps["stack_debt"] * apps["crit_weight"]
    apps["worst_risk"] = np.where(apps["high_risk_techs"] > 0, "High", np.where(apps["medium_risk_techs"] > 0, "Medium", "Low"))

    model = Model(as_of=as_of, technologies=tech, applications=apps, stack=stack, services=svc)

    if data.has_capabilities:
        ac = data.app_capability.drop_duplicates(["app_id", "cap_id"])
        ac = ac[ac["app_id"].isin(set(apps["app_id"])) & ac["cap_id"].isin(set(data.capabilities["cap_id"]))]
        model.capabilities = data.capabilities.copy()
        model.app_capability = ac.copy()
        model.org_units = data.org_units.copy() if data.org_units is not None else None
        model.cap_rollup = cap.rollup(model.capabilities, ac, apps)
        model.findings = cap.findings(model.capabilities, ac, apps)
    return model


def alternatives(model: Model, service_id: str, exclude_tech_id: str) -> str:
    """Strategic or Standard products on the same service, as a suggestion."""
    t = model.technologies
    pick = t[(t["service_id"] == service_id) & (t["tech_id"] != exclude_tech_id) & t["standard_status"].isin(["Strategic", "Standard"])]
    pick = pick.sort_values("standard_status", key=lambda s: s.map({"Strategic": 0, "Standard": 1}))
    return ", ".join(pick["label"].head(3)) if len(pick) else ""
