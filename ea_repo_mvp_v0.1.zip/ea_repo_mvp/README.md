# EA repository prototype: technology reference model, lifecycle and capability mapping

A small Streamlit app that shows a Technology Reference Model: the layered catalogue of technology
services and the products placed on them, with each product's standards position, vendor support
dates and the applications that use it. Data comes from four CSV files.

## What it shows

| Page | Purpose |
| --- | --- |
| Overview | Headline numbers, standards position by service area, support status, top risks |
| TRM map | The model as layers (area, category, service, products), coloured by status; highlight one application's stack |
| Technology catalogue | Search and filter every product and version; open one to see where it is used and what to move to |
| Application view | One application's stack against the model, with what needs attention |
| Lifecycle and risk | Support timeline and a ranked priority list; the scoring rules are shown on the page |
| Data quality | Checks on the CSV files (missing columns, bad IDs, unknown statuses, broken links) |

## Capability pages and investment stance

Three optional CSV files switch on the business-capability pages. Without them the app behaves as before.

| Page | Purpose |
| --- | --- |
| Invest / disinvest | Stance by service area and support status, end-of-life view, stance contradictions |
| Capability map | Capability tree coloured by the technology risk beneath it; drill into a capability's applications and technologies |
| Capability mapping | Capability to applications, application to capabilities, and findings: gaps, overlaps, orphans |
| Exposure by area | Applications with High-risk or Disinvest technology, by organisation unit, business domain or L1 capability |

| File (optional) | One row per | Columns |
| --- | --- | --- |
| `capabilities.csv` | Capability (L1 to L3) | `cap_id`, `parent_cap_id`, `level`, `name`, `description`, `source_confidence`, `owner_org_unit_id` |
| `app_capability.csv` | Application supporting a capability | `app_id`, `cap_id`, `support_level` (Primary, Supporting), `fit` (Good, Partial, Poor) |
| `org_units.csv` | Organisation unit | `org_unit_id`, `parent_org_unit_id`, `name`, `type` |

Optional extra columns: `technologies.csv` gets `investment_stance` (Invest, Maintain, Disinvest), `replacement_tech_id`, `stance_note`;
`applications.csv` gets `org_unit_id`, `last_reviewed`. With no `investment_stance` column, stance is derived from the standards status
(Strategic, Emerging: Invest; Standard: Maintain; Contain, Retire, Prohibited: Disinvest).

**Pilot data.** `data/ib_pilot/` is an illustrative Investment Banking dataset (68 capabilities from the CIB capability map, 42 applications).
Regenerate it with `python scripts/make_ib_pilot_data.py`; the script also prints the gaps, overlaps and orphans it was designed to contain.

**Rules.** A capability's numbers include everything beneath it. A leaf capability is a gap when no application supports it, directly or
through a parent mapping. An overlap is a capability with more than one Primary application. An application counts once in each area it belongs to.

## Run it

Python 3.10 or later.

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows;  source .venv/bin/activate on macOS or Linux
pip install -r requirements.txt
streamlit run app.py
```

Open http://localhost:8501. The sidebar lets you use the sample data, point at a folder of your own CSV
files, or upload the four files.

To run the checks: `pip install -r requirements-dev.txt` then `pytest`.

## The data files

All four files go in one folder (sample: `data/sample/`). Column names must match exactly.

| File | One row per | Columns |
| --- | --- | --- |
| `services.csv` | Service in the model | `service_id`, `service_area`, `service_category`, `service` |
| `technologies.csv` | Product and version | `tech_id`, `name`, `vendor`, `version`, `service_id`, `standard_status`, `deployment_model`, `end_of_support`, `date_source`, `owner_team`, `annual_cost_usd` |
| `applications.csv` | Application | `app_id`, `name`, `business_domain`, `criticality`, `owner_team`, `lifecycle` |
| `app_technology.csv` | Application using a technology | `app_id`, `tech_id`, `usage` |

Allowed values:

- `standard_status`: Strategic (preferred for new work), Standard (approved), Emerging (being piloted), Contain (no new use), Retire (planned removal), Prohibited (must not be used)
- `criticality`: Tier 1, Tier 2, Tier 3
- `deployment_model`: SaaS, PaaS, Self-managed, Appliance
- `end_of_support`: a date such as `2027-01-12`, or blank when the vendor publishes none
- `annual_cost_usd`: a number, or blank

Re-create the sample files with `python scripts/make_sample_data.py`.

**The sample data is illustrative.** Product names are real, but versions, dates, costs, owners and
application names are made up for the prototype. Check vendor support dates against vendor sources before
using real data.

## How the risk score works

Priority = (status points + support points) x tier weight of the most critical application that uses the technology.

- Status points: Strategic 0, Standard 0, Emerging 1, Contain 2, Retire 4, Prohibited 5
- Support points: out of support 5, under 6 months 4, 6 to 12 months 3, 12 to 24 months 1, supported 0, no date and vendor managed 0, no date and self-managed 1
- Tier weight: Tier 1 = 3, Tier 2 = 2, Tier 3 = 1
- Risk level: High at 15 or more, Medium from 6, otherwise Low

The rules sit at the top of `trm/model.py`; change them there. Shared technology costs are split across the
applications that use them.

## Layout

```
app.py               entry point and navigation
views/               one file per page
trm/data.py          loading (CSV, upload) and validation; swap CsvRepository for a SQL one later
trm/model.py         support state, scoring, per-application measures
trm/ui.py            colours and the TRM map HTML
trm/state.py         sidebar and data source handling
data/sample/         sample CSV files
scripts/             sample data generator
tests/               unit tests and a smoke test of every page
```

## Next steps towards the platform design

- Replace `CsvRepository` with a repository that reads Azure SQL (same four tables); the pages do not change.
- Add Microsoft Entra ID sign-in and role checks in a service layer before any editing is allowed.
- Load applications and links from ServiceNow instead of CSV; keep the TRM taxonomy and statuses in the platform.
