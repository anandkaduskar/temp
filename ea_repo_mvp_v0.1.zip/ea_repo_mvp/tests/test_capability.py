from pathlib import Path

import pandas as pd
import pytest

from trm import capability as cap
from trm.data import CsvRepository, validate
from trm.model import build, stance_conflict

PILOT = Path(__file__).resolve().parent.parent / "data" / "ib_pilot"
AS_OF = pd.Timestamp("2026-11-01")


@pytest.fixture(scope="module")
def data():
    return CsvRepository(PILOT).load()


@pytest.fixture(scope="module")
def model(data):
    return build(data, AS_OF)


def test_pilot_data_has_no_errors(data):
    issues = validate(data)
    assert not (issues["severity"] == "Error").any(), issues[issues["severity"] == "Error"]


def test_findings_match_the_designed_cases(model):
    f = model.findings
    assert set(f["gaps"]) == {"CAP-1.1.3", "CAP-1.2.2", "CAP-1.2.3", "CAP-1.2.4", "CAP-3.4", "CAP-3.5", "CAP-9.3", "CAP-9.4"}
    assert set(f["overlaps"]) == {"CAP-6.3", "CAP-6.4"}
    assert len(f["orphans"]) == 1


def test_rollup_includes_children(model):
    r = model.cap_rollup.set_index("cap_id")
    # a parent counts every application beneath it, so it is at least as large as any child
    for child, row in r.iterrows():
        if row["parent_cap_id"]:
            assert r.loc[row["parent_cap_id"], "apps"] >= row["apps"]
    assert r.loc["CAP-6", "apps"] >= r.loc["CAP-6.3", "apps"] == 2


def test_gap_capability_has_no_risk_rating(model):
    r = model.cap_rollup.set_index("cap_id")
    assert r.loc["CAP-9.3", "apps"] == 0 and r.loc["CAP-9.3", "worst_risk"] == "None"


def test_paths_and_roots():
    caps = pd.DataFrame({"cap_id": ["A", "B", "C"], "parent_cap_id": ["", "A", "B"], "name": ["One", "Two", "Three"]})
    assert cap.paths(caps)["C"] == "One > Two > Three"
    assert cap.root_of("C", cap.parent_map(caps)) == "A"
    assert cap.subtree("A", cap.children_map(caps)) == {"A", "B", "C"}


def test_parent_mapping_covers_children():
    caps = pd.DataFrame({"cap_id": ["A", "B"], "parent_cap_id": ["", "A"], "name": ["One", "Two"]})
    ac = pd.DataFrame({"app_id": ["X"], "cap_id": ["A"], "support_level": ["Primary"], "fit": ["Good"]})
    apps = pd.DataFrame({"app_id": ["X"]})
    assert cap.findings(caps, ac, apps)["gaps"] == []


def test_tree_loop_does_not_hang():
    parent = {"A": "B", "B": "A"}
    assert cap.ancestors("A", parent) == ["B"]


def test_stance_conflict_rules():
    assert stance_conflict("Invest", "Standard", "Under 6 months")
    assert stance_conflict("Invest", "Retire", "Supported")
    assert stance_conflict("Disinvest", "Strategic", "Supported")
    assert stance_conflict("Maintain", "Contain", "Out of support") == ""


def test_bad_references_are_errors(data):
    broken = pd.concat([data.app_capability, pd.DataFrame([{"app_id": "APP-999", "cap_id": "CAP-404", "support_level": "Main", "fit": "Great"}])], ignore_index=True)
    data2 = type(data)(**{**data.__dict__, "app_capability": broken})
    checks = set(validate(data2).query("severity == 'Error'")["check"])
    assert {"Unknown application", "Unknown capability", "Unknown support level", "Unknown fit"} <= checks


def test_stance_defaults_when_column_missing(data):
    t = data.technologies.drop(columns=["investment_stance", "replacement_tech_id", "stance_note"])
    m = build(type(data)(**{**data.__dict__, "technologies": t}), AS_OF)
    row = m.technologies.set_index("tech_id").loc["TECH-001"]
    assert row["investment_stance"] == "Invest" and row["stance_source"] == "derived"


def test_exposure_table_counts_each_app_once_per_area(model):
    mem = cap.membership(model.applications, model.capabilities, model.app_capability, model.org_units, "Organisation unit")
    tbl = cap.area_table(model.applications, model.stack, mem)
    assert tbl["apps"].sum() == len(model.applications)
