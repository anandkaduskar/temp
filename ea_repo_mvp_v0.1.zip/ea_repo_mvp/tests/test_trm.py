from pathlib import Path

import pandas as pd
import pytest

from trm.data import CsvRepository, TrmData, validate
from trm.model import build, support_state

SAMPLE = Path(__file__).resolve().parent.parent / "data" / "sample"
AS_OF = pd.Timestamp("2026-10-27")


@pytest.fixture(scope="module")
def data():
    return CsvRepository(SAMPLE).load()


def test_sample_data_is_clean(data):
    issues = validate(data)
    assert not (issues["severity"] == "Error").any(), issues[issues["severity"] == "Error"]


def test_versions_stay_text(data):
    assert "3.9" in set(data.technologies["version"])
    assert "2012 R2" in set(data.technologies["version"])


def test_support_state_rules():
    assert support_state(pd.Timestamp("2026-01-01"), "Self-managed", AS_OF) == "Out of support"
    assert support_state(pd.Timestamp("2027-01-12"), "Self-managed", AS_OF) == "Under 6 months"
    assert support_state(pd.Timestamp("2027-06-30"), "Self-managed", AS_OF) == "6 to 12 months"
    assert support_state(pd.Timestamp("2028-04-30"), "Self-managed", AS_OF) == "12 to 24 months"
    assert support_state(pd.Timestamp("2031-01-01"), "Self-managed", AS_OF) == "Supported"
    assert support_state(pd.NaT, "SaaS", AS_OF) == "No date (vendor managed)"
    assert support_state(pd.NaT, "Self-managed", AS_OF) == "No date (self-managed)"


def test_model_scores(data):
    m = build(data, AS_OF)
    t = m.technologies.set_index("label")
    # Prohibited (5) + out of support (5) = 10, on a Tier 1 or Tier 3 application
    w2012 = t.loc["Windows Server 2012 R2"]
    assert w2012["tech_score"] == 10
    assert w2012["priority"] == 10 * w2012["max_crit_weight"]
    # a strategic SaaS product has no points at all
    assert t.loc["Power BI n/a", "tech_score"] == 0
    assert t.loc["Power BI n/a", "risk_level"] == "Low"
    # every application has a stack
    assert (m.applications["technologies"] > 0).all()


def test_validation_catches_problems(data):
    bad = TrmData(
        services=data.services.copy(),
        technologies=data.technologies.copy(),
        applications=data.applications.copy(),
        links=data.links.copy(),
    )
    bad.technologies.loc[0, "standard_status"] = "Maybe"
    bad.technologies.loc[1, "service_id"] = "SVC-999"
    bad.technologies.loc[2, "end_of_support"] = "31/31/2030"
    bad.links.loc[0, "app_id"] = "APP-999"
    issues = validate(bad)
    checks = set(issues["check"])
    assert {"Unknown status", "Unknown service", "Invalid date", "Unknown application"} <= checks


def test_missing_column_is_reported(data):
    bad = TrmData(data.services, data.technologies.drop(columns=["owner_team"]), data.applications, data.links)
    issues = validate(bad)
    assert (issues["check"] == "Missing column").any()


def test_cost_is_allocated_not_double_counted(data):
    m = build(data, AS_OF)
    in_use_cost = m.technologies.loc[m.technologies["app_count"] > 0, "annual_cost_usd"].sum()
    assert m.applications["allocated_cost_usd"].sum() == pytest.approx(in_use_cost)
