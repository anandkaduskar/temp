"""Smoke test: every page script renders without an exception, on both datasets."""
from pathlib import Path

import pandas as pd
import pytest
from streamlit.testing.v1 import AppTest

from trm.data import CsvRepository, validate
from trm.model import build

ROOT = Path(__file__).resolve().parent.parent
PAGES = ["overview", "trm_map", "catalogue", "application", "lifecycle_risk", "stance", "data_quality"]
CAPABILITY_PAGES = ["capability_map", "capability_mapping", "exposure"]


def _state(folder):
    data = CsvRepository(ROOT / "data" / folder).load()
    return data, validate(data), build(data, pd.Timestamp("2026-11-01"))


@pytest.fixture(scope="module")
def sample():
    return _state("sample")


@pytest.fixture(scope="module")
def pilot():
    return _state("ib_pilot")


def _run(page, state):
    data, issues, model = state
    at = AppTest.from_file(str(ROOT / "views" / f"{page}.py"), default_timeout=60)
    at.session_state["data"] = data
    at.session_state["issues"] = issues
    at.session_state["model"] = model
    at.run()
    return at


@pytest.mark.parametrize("page", PAGES)
def test_page_renders_on_sample(page, sample):
    at = _run(page, sample)
    assert not at.exception, [e.value for e in at.exception]


@pytest.mark.parametrize("page", PAGES + CAPABILITY_PAGES)
def test_page_renders_on_pilot(page, pilot):
    at = _run(page, pilot)
    assert not at.exception, [e.value for e in at.exception]


@pytest.mark.parametrize("page", CAPABILITY_PAGES)
def test_capability_pages_explain_missing_files(page, sample):
    at = _run(page, sample)
    assert not at.exception, [e.value for e in at.exception]
    assert any("capabilities.csv" in i.value for i in at.info)


def test_app_entry_renders():
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60)
    at.run()
    assert not at.exception, [e.value for e in at.exception]
