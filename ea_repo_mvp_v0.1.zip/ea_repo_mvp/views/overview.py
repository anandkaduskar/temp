import plotly.express as px
import streamlit as st

from trm.data import STATUSES
from trm.model import SUPPORT_ORDER
from trm.state import need_model
from trm.ui import RISK_COLOURS, STATUS_COLOURS, money

model = need_model()
t, apps = model.technologies, model.applications

st.title("Technology Reference Model")
st.caption(f"As of {model.as_of:%d %b %Y}. Standards position, support status and use across {len(apps)} applications.")

in_use = t[t["app_count"] > 0]
non_std = in_use[in_use["standard_status"].isin(["Contain", "Retire", "Prohibited"])]
oos = in_use[in_use["support_state"] == "Out of support"]
soon = in_use[in_use["support_state"].isin(["Under 6 months", "6 to 12 months"])]
high = in_use[in_use["risk_level"] == "High"]

c = st.columns(5)
c[0].metric("Technologies in use", len(in_use), help="Technologies linked to at least one application.")
c[1].metric("Not recommended", len(non_std), help="Contain, Retire or Prohibited, and still in use.")
c[2].metric("Out of support", len(oos), help="Vendor support date is before the as-of date.")
c[3].metric("Support ends within 12 months", len(soon))
c[4].metric("High-risk technologies", len(high), help="Priority score of 15 or more. See Lifecycle and risk.")

left, right = st.columns([3, 2])
with left:
    st.subheader("Standards position by service area")
    g = in_use.groupby(["service_area", "standard_status"]).size().reset_index(name="technologies")
    fig = px.bar(
        g, y="service_area", x="technologies", color="standard_status", orientation="h",
        color_discrete_map=STATUS_COLOURS, category_orders={"standard_status": STATUSES},
        labels={"service_area": "", "technologies": "Technologies in use", "standard_status": "Status"},
    )
    fig.update_layout(height=380, margin=dict(l=0, r=0, t=10, b=0), legend_title_text="", yaxis=dict(autorange="reversed"))
    st.plotly_chart(fig, width="stretch")
with right:
    st.subheader("Support status")
    s = in_use["support_state"].value_counts().reindex(SUPPORT_ORDER).dropna().reset_index()
    s.columns = ["support_state", "technologies"]
    fig = px.bar(s, y="support_state", x="technologies", orientation="h", labels={"support_state": "", "technologies": "Technologies in use"})
    fig.update_traces(marker_color="#475569")
    fig.update_layout(height=380, margin=dict(l=0, r=0, t=10, b=0), yaxis=dict(autorange="reversed"))
    st.plotly_chart(fig, width="stretch")

left, right = st.columns(2)
with left:
    st.subheader("Highest-priority technologies")
    top = in_use.sort_values(["priority", "app_count"], ascending=False).head(8)
    st.dataframe(
        top[["label", "standard_status", "support_state", "app_count", "priority"]],
        hide_index=True, width="stretch",
        column_config={
            "label": "Technology", "standard_status": "Status", "support_state": "Support",
            "app_count": st.column_config.NumberColumn("Apps", width="small"),
            "priority": st.column_config.ProgressColumn("Priority", min_value=0, max_value=30, format="%d"),
        },
    )
with right:
    st.subheader("Applications carrying the most technology debt")
    top = apps.sort_values("debt_priority", ascending=False).head(8)
    st.dataframe(
        top[["name", "criticality", "retire_or_prohibited", "out_of_support", "debt_priority"]],
        hide_index=True, width="stretch",
        column_config={
            "name": "Application", "criticality": "Tier",
            "retire_or_prohibited": st.column_config.NumberColumn("Retire / prohibited", width="small"),
            "out_of_support": st.column_config.NumberColumn("Out of support", width="small"),
            "debt_priority": st.column_config.ProgressColumn("Debt score", min_value=0, max_value=max(1, int(apps["debt_priority"].max()))),
        },
    )

st.caption(f"Annual cost of technologies in use (sample figures): {money(in_use['annual_cost_usd'].sum())}. "
           "Risk scoring rules are listed on the Lifecycle and risk page.")
