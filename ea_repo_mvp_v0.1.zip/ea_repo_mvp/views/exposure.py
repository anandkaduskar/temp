import plotly.express as px
import streamlit as st

from trm import capability as cap
from trm.data import INVESTMENT_STANCES
from trm.state import need_capabilities

model = need_capabilities()
apps, stack = model.applications, model.stack

st.title("Exposure by area")
st.caption("How much of each part of the business depends on risky technology. An application counts once in each area it belongs to.")

dims = ["Organisation unit", "Business domain", "L1 capability"]
if model.org_units is None:
    dims.remove("Organisation unit")
dim = st.radio("Group by", dims, horizontal=True)
mem = cap.membership(apps, model.capabilities, model.app_capability, model.org_units, dim)
tbl = cap.area_table(apps, stack, mem)

left, right = st.columns(2)
with left:
    st.subheader("Applications with a High-risk technology")
    d = tbl.sort_values("high_risk_apps")
    fig = px.bar(d, y="area", x="high_risk_apps", orientation="h", labels={"area": "", "high_risk_apps": "Applications"},
                 hover_data={"apps": True, "pct_high_risk": True})
    fig.update_traces(marker_color="#b91c1c")
    fig.update_layout(height=420, margin=dict(l=0, r=0, t=10, b=0))
    st.plotly_chart(fig, width="stretch")
with right:
    st.subheader("Technologies by stance")
    mix = cap.stance_mix(stack, mem)
    fig = px.bar(mix, y="area", x="technologies", color="investment_stance", orientation="h",
                 color_discrete_map={"Invest": "#0f766e", "Maintain": "#1d4ed8", "Disinvest": "#b91c1c"},
                 category_orders={"investment_stance": INVESTMENT_STANCES, "area": list(tbl.sort_values("high_risk_apps")["area"])},
                 labels={"area": "", "technologies": "Distinct technologies", "investment_stance": "Stance"})
    fig.update_layout(height=420, margin=dict(l=0, r=0, t=10, b=0), legend_title_text="")
    st.plotly_chart(fig, width="stretch")

st.subheader("Detail")
st.dataframe(
    tbl[["area", "apps", "tier1_apps", "high_risk_apps", "pct_high_risk", "disinvest_apps", "pct_disinvest", "oos_apps", "debt_score"]],
    hide_index=True, width="stretch",
    column_config={"area": "Area", "apps": st.column_config.NumberColumn("Apps", width="small"),
                   "tier1_apps": st.column_config.NumberColumn("Tier 1", width="small"),
                   "high_risk_apps": st.column_config.NumberColumn("With High-risk tech", width="small"),
                   "pct_high_risk": st.column_config.NumberColumn("% High-risk", format="%d%%", width="small"),
                   "disinvest_apps": st.column_config.NumberColumn("On Disinvest tech", width="small"),
                   "pct_disinvest": st.column_config.NumberColumn("% Disinvest", format="%d%%", width="small"),
                   "oos_apps": st.column_config.NumberColumn("Out-of-support tech", width="small"),
                   "debt_score": st.column_config.ProgressColumn("Debt score", min_value=0, max_value=max(1, int(tbl["debt_score"].max())), format="%d")},
)
st.download_button("Download this table (CSV)", tbl.to_csv(index=False).encode("utf-8"), "exposure_by_area.csv", "text/csv")
st.caption("High-risk follows the scoring rules on the Lifecycle and risk page. Debt score is the sum of each application's stack debt times its tier weight.")
