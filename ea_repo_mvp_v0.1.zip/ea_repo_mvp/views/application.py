import plotly.express as px
import streamlit as st

from trm.data import STATUSES
from trm.model import alternatives
from trm.state import need_model
from trm.ui import STATUS_COLOURS, money

model = need_model()
apps, stack = model.applications, model.stack

st.title("Application view")
st.caption("The technology stack of one application, checked against the reference model.")

names = list(apps.sort_values("name")["name"])
name = st.selectbox("Application", names)
a = apps[apps["name"] == name].iloc[0]
s = stack[stack["app_id"] == a["app_id"]].copy()

st.markdown(f"**{a['business_domain']}** | {a['criticality']} | owner: {a['owner_team']} | lifecycle: {a['lifecycle']}")
m = st.columns(5)
m[0].metric("Technologies", int(a["technologies"]))
m[1].metric("Retire or prohibited", int(a["retire_or_prohibited"]))
m[2].metric("Out of support", int(a["out_of_support"]))
m[3].metric("Debt score", int(a["debt_priority"]), help="Sum of each technology's status and support points, times the application's tier weight.")
m[4].metric("Allocated tech cost", money(a["allocated_cost_usd"]), help="Each technology's annual cost divided across the applications that use it.")

left, right = st.columns([2, 3])
with left:
    st.subheader("Stack by status")
    g = s.groupby("standard_status").size().reindex(STATUSES).dropna().reset_index(name="technologies")
    fig = px.bar(g, x="standard_status", y="technologies", color="standard_status", color_discrete_map=STATUS_COLOURS,
                 labels={"standard_status": "", "technologies": "Technologies"})
    fig.update_layout(height=300, showlegend=False, margin=dict(l=0, r=0, t=10, b=0))
    st.plotly_chart(fig, width="stretch")
with right:
    st.subheader("Needs attention")
    flag = s[(s["standard_status"].isin(["Retire", "Prohibited", "Contain"])) | (s["support_state"].isin(["Out of support", "Under 6 months", "6 to 12 months"]))].copy()
    if flag.empty:
        st.success("Nothing to flag. Every technology is standard and supported.")
    else:
        flag["target"] = [alternatives(model, sid, tid) for sid, tid in zip(flag["service_id"], flag["tech_id"])]
        flag = flag.sort_values("tech_score", ascending=False)
        st.dataframe(
            flag[["label", "standard_status", "support_state", "target"]], hide_index=True, width="stretch",
            column_config={"label": "Technology", "standard_status": "Status", "support_state": "Support", "target": "Move towards"},
        )

st.subheader("Full stack")
full = s.sort_values(["service_area", "service"])[["service_area", "service", "label", "usage", "standard_status", "support_state", "end_of_support", "tech_owner", "cost_share_usd"]]
st.dataframe(
    full[["service", "label", "usage", "standard_status", "support_state", "end_of_support"]], hide_index=True, width="stretch",
    column_config={"service": "Service", "label": "Technology", "usage": "Used for", "standard_status": "Status",
                   "support_state": "Support", "end_of_support": st.column_config.DateColumn("Support ends", format="DD MMM YYYY")},
)
st.download_button("Download this stack (CSV)", full.to_csv(index=False).encode("utf-8"), f"{a['app_id']}_stack.csv", "text/csv")

if model.has_capabilities:
    from trm import capability as cap

    st.subheader("Capabilities served")
    paths = cap.paths(model.capabilities)
    mine = model.app_capability[model.app_capability["app_id"] == a["app_id"]].copy()
    if mine.empty:
        st.warning("This application is not mapped to any capability.")
    else:
        mine["path"] = mine["cap_id"].map(paths)
        st.dataframe(mine[["path", "support_level", "fit"]], hide_index=True, width="stretch",
                     column_config={"path": "Capability", "support_level": "Role", "fit": "Fit"})
