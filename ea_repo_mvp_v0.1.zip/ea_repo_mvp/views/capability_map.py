import streamlit as st

from trm import capability as cap
from trm.capability_ui import HEAT_METRICS, capability_map_html, legend_html
from trm.state import need_capabilities

model = need_capabilities()
r = model.cap_rollup
paths = cap.paths(model.capabilities)

st.title("Capability map")
st.caption("Business capabilities coloured by the technology risk beneath them: capability, then the applications that support it, "
           "then the technologies those applications run on. Dashed tiles have no application.")

metric = st.radio("Colour by", HEAT_METRICS, horizontal=True)
st.markdown(legend_html(metric), unsafe_allow_html=True)
st.markdown(capability_map_html(r, metric), unsafe_allow_html=True)

leaf_gaps = len(model.findings["gaps"])
c = st.columns(4)
c[0].metric("Capabilities", len(r))
c[1].metric("Gaps (no application)", leaf_gaps, help="Leaf capabilities with no supporting application. See Capability mapping.")
c[2].metric("With a High-risk technology beneath", int(((r["level"] == "L2") & (r["worst_risk"] == "High")).sum()), help="Level 2 capabilities.")
c[3].metric("Several primary applications", len(model.findings["overlaps"]), help="Possible duplication to rationalise.")

st.divider()
st.subheader("Drill into a capability")
order = r.copy()
order["label"] = order["cap_id"] + "  " + order["name"]
pick = st.selectbox("Capability", list(order["cap_id"]),
                    format_func=lambda cid: ("      " * (int(order.set_index("cap_id").loc[cid, "level"][1]) - 1)) + order.set_index("cap_id").loc[cid, "label"])
row = r[r["cap_id"] == pick].iloc[0]
st.markdown(f"**{paths[pick]}** | confidence: {row['source_confidence'] or 'n/a'}")
m = st.columns(5)
m[0].metric("Applications", int(row["apps"]))
m[1].metric("Tier 1", int(row["tier1_apps"]))
m[2].metric("With High-risk tech", int(row["high_risk_apps"]))
m[3].metric("On Disinvest tech", int(row["disinvest_apps"]))
m[4].metric("With out-of-support tech", int(row["oos_apps"]))

sub = cap.subtree(pick, cap.children_map(model.capabilities))
ids = model.app_capability[model.app_capability["cap_id"].isin(sub)]
if ids.empty:
    st.warning("No application supports this capability, or anything beneath it.")
else:
    names = dict(zip(model.capabilities["cap_id"], model.capabilities["name"]))
    apps = ids.merge(model.applications, on="app_id")
    apps["capability"] = apps["cap_id"].map(names)
    st.markdown("**Applications**")
    st.dataframe(
        apps.sort_values(["support_level", "criticality", "name"])[["name", "capability", "support_level", "fit", "criticality", "lifecycle", "worst_risk", "disinvest_techs", "out_of_support"]],
        hide_index=True, width="stretch",
        column_config={"name": "Application", "capability": "Supports", "support_level": "Role", "fit": "Fit", "criticality": "Tier",
                       "lifecycle": "Lifecycle", "worst_risk": "Worst tech risk", "disinvest_techs": "Disinvest techs", "out_of_support": "Out of support"},
    )
    t = cap.technologies_under(model.stack, model.app_capability, model.capabilities, pick)
    st.markdown("**Technologies beneath it** (highest priority first)")
    st.dataframe(
        t[["label", "service", "standard_status", "investment_stance", "support_state", "end_of_support", "apps_in_capability", "risk_level", "replacement"]],
        hide_index=True, width="stretch", height=320,
        column_config={"label": "Technology", "service": "Service", "standard_status": "Status", "investment_stance": "Stance",
                       "support_state": "Support", "end_of_support": st.column_config.DateColumn("Support ends", format="DD MMM YYYY"),
                       "apps_in_capability": st.column_config.NumberColumn("Apps here", width="small"), "risk_level": "Risk", "replacement": "Move to"},
    )
