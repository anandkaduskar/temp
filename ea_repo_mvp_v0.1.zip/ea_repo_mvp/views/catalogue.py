import streamlit as st

from trm.data import DEPLOYMENT_MODELS, STATUSES
from trm.model import alternatives
from trm.state import need_model
from trm.ui import STATUS_COLOURS, STATUS_MEANING, money

model = need_model()
t, stack = model.technologies, model.stack

st.title("Technology catalogue")
st.caption("Every product and version in the reference model. Pick a row to see where it is used.")

f = st.columns([3, 2, 2, 2])
q = f[0].text_input("Search", placeholder="Name, vendor or service")
areas = f[1].multiselect("Service area", list(model.services["service_area"].drop_duplicates()))
statuses = f[2].multiselect("Status", STATUSES)
deploy = f[3].multiselect("Deployment", DEPLOYMENT_MODELS)

view = t
if q:
    ql = q.lower()
    view = view[view[["label", "vendor", "service", "service_category"]].apply(lambda c: c.str.lower().str.contains(ql, regex=False)).any(axis=1)]
if areas:
    view = view[view["service_area"].isin(areas)]
if statuses:
    view = view[view["standard_status"].isin(statuses)]
if deploy:
    view = view[view["deployment_model"].isin(deploy)]
view = view.sort_values(["service_area", "service", "label"]).reset_index(drop=True)

cols = ["tech_id", "label", "vendor", "service_area", "service", "standard_status", "deployment_model", "end_of_support", "support_state", "app_count", "annual_cost_usd", "owner_team", "risk_level"]
shown_cols = ["label", "service", "standard_status", "deployment_model", "end_of_support", "support_state", "app_count", "risk_level"]
event = st.dataframe(
    view[shown_cols], hide_index=True, width="stretch", on_select="rerun", selection_mode="single-row", height=380,
    column_config={
        "tech_id": "ID", "label": "Technology", "vendor": "Vendor", "service_area": "Area", "service": "Service",
        "standard_status": "Status", "deployment_model": "Deployment",
        "end_of_support": st.column_config.DateColumn("Support ends", format="DD MMM YYYY"),
        "support_state": "Support", "app_count": st.column_config.NumberColumn("Apps", width="small"),
        "annual_cost_usd": st.column_config.NumberColumn("Annual cost (USD)", format="$%d"),
        "owner_team": "Owner", "risk_level": "Risk",
    },
)
st.download_button("Download this list (CSV)", view[cols].to_csv(index=False).encode("utf-8"), "technologies.csv", "text/csv")

rows = event.selection.rows if event and event.selection else []
if rows:
    r = view.iloc[rows[0]]
    st.divider()
    colour = STATUS_COLOURS.get(r["standard_status"], "#555")
    st.subheader(r["label"])
    st.markdown(
        f'<span style="background:{colour};color:#fff;padding:.15rem .6rem;border-radius:999px;font-size:.8rem">{r["standard_status"]}</span> '
        f'&nbsp;{STATUS_MEANING.get(r["standard_status"], "")}', unsafe_allow_html=True,
    )
    m = st.columns(4)
    m[0].metric("Service", r["service"], help=f'{r["service_area"]} > {r["service_category"]}')
    m[1].metric("Used by", f'{r["app_count"]} apps')
    m[2].metric("Annual cost", money(r["annual_cost_usd"]))
    m[3].metric("Priority score", f'{r["priority"]} ({r["risk_level"]})')
    eos = f'{r["end_of_support"]:%d %b %Y}' if r["end_of_support"] == r["end_of_support"] else "no date recorded"
    st.write(f'**Support:** {r["support_state"]} (ends {eos})  |  **Vendor:** {r["vendor"]}  |  **Owner:** {r["owner_team"]}  |  **Deployment:** {r["deployment_model"]}')

    users = stack[stack["tech_id"] == r["tech_id"]][["application", "business_domain", "criticality", "app_owner", "usage", "lifecycle"]]
    st.markdown("**Applications using it**")
    st.dataframe(users.sort_values(["criticality", "application"]), hide_index=True, width="stretch",
                 column_config={"application": "Application", "business_domain": "Domain", "criticality": "Tier", "app_owner": "App owner", "usage": "Used for", "lifecycle": "Lifecycle"})
    if r["standard_status"] in ("Contain", "Retire", "Prohibited", "Emerging"):
        alt = alternatives(model, r["service_id"], r["tech_id"])
        if alt:
            st.info(f"Preferred alternatives on the same service: {alt}")
else:
    st.caption("Select a row to open its detail.")

if rows and model.has_capabilities:
    from trm import capability as cap

    st.markdown("**Business capabilities that depend on it**")
    users_ids = set(stack[stack["tech_id"] == r["tech_id"]]["app_id"])
    mapped = model.app_capability[model.app_capability["app_id"].isin(users_ids)]
    if mapped.empty:
        st.caption("None of the applications using it is mapped to a capability.")
    else:
        paths = cap.paths(model.capabilities)
        g = mapped.groupby("cap_id")["app_id"].nunique().reset_index(name="apps")
        g["capability"] = g["cap_id"].map(paths)
        st.dataframe(g.sort_values("capability")[["capability", "apps"]], hide_index=True, width="stretch",
                     column_config={"capability": "Capability", "apps": st.column_config.NumberColumn("Apps using it", width="small")})
