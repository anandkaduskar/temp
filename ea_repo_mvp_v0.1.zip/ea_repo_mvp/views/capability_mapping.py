import streamlit as st

from trm import capability as cap
from trm.state import need_capabilities
from trm.ui import money

model = need_capabilities()
caps, ac, apps = model.capabilities, model.app_capability, model.applications
paths = cap.paths(caps)
names = dict(zip(caps["cap_id"], caps["name"]))
app_name = dict(zip(apps["app_id"], apps["name"]))

st.title("Capability mapping")
st.caption("Which applications support which business capabilities, and where the mapping has gaps, overlaps or orphans.")

tab_cap, tab_app, tab_find = st.tabs(["Capability to applications", "Application to capabilities", "Findings"])

with tab_cap:
    c = st.columns([3, 2])
    pick = c[0].selectbox("Capability", list(caps["cap_id"]), format_func=lambda x: f"{x}  {paths[x]}")
    below = c[1].toggle("Include capabilities beneath it", value=True)
    ids = cap.subtree(pick, cap.children_map(caps)) if below else {pick}
    m = ac[ac["cap_id"].isin(ids)].merge(apps, on="app_id")
    if m.empty:
        st.warning("No application supports this capability.")
    else:
        m["capability"] = m["cap_id"].map(names)
        st.dataframe(
            m.sort_values(["support_level", "name"])[["name", "capability", "support_level", "fit", "criticality", "owner_team", "lifecycle"]],
            hide_index=True, width="stretch",
            column_config={"name": "Application", "capability": "Supports", "support_level": "Role", "fit": "Fit",
                           "criticality": "Tier", "owner_team": "Owner", "lifecycle": "Lifecycle"},
        )

with tab_app:
    name = st.selectbox("Application", list(apps.sort_values("name")["name"]))
    a = apps[apps["name"] == name].iloc[0]
    m = ac[ac["app_id"] == a["app_id"]].copy()
    if m.empty:
        st.warning("This application is not mapped to any capability.")
    else:
        m["path"] = m["cap_id"].map(paths)
        st.dataframe(m[["path", "support_level", "fit"]], hide_index=True, width="stretch",
                     column_config={"path": "Capability", "support_level": "Role", "fit": "Fit"})

with tab_find:
    f = model.findings
    k = st.columns(3)
    k[0].metric("Capability gaps", len(f["gaps"]))
    k[1].metric("Capabilities with several primary apps", len(f["overlaps"]))
    k[2].metric("Applications with no capability", len(f["orphans"]))

    st.subheader("Gaps: leaf capabilities no application supports")
    if f["gaps"]:
        g = caps[caps["cap_id"].isin(f["gaps"])].copy()
        g["path"] = g["cap_id"].map(paths)
        owners = dict(zip(model.org_units["org_unit_id"], model.org_units["name"])) if model.org_units is not None else {}
        g["owner"] = g["owner_org_unit_id"].map(owners).fillna(g["owner_org_unit_id"])
        st.dataframe(g[["cap_id", "path", "source_confidence", "owner"]], hide_index=True, width="stretch",
                     column_config={"cap_id": "ID", "path": "Capability", "source_confidence": "Source confidence", "owner": "Owner"})
        st.caption("A gap is either a real hole, a capability bought from outside, or a mapping nobody has done yet. "
                   "Unconfirmed capabilities are the first to check.")
    else:
        st.success("Every leaf capability has at least one application.")

    st.subheader("Overlaps: capabilities with several primary applications")
    if f["overlaps"]:
        rows = []
        cost = dict(zip(apps["app_id"], apps["allocated_cost_usd"]))
        life = dict(zip(apps["app_id"], apps["lifecycle"]))
        for cid, ids_ in f["overlaps"].items():
            rows.append({"capability": paths[cid],
                         "applications": ", ".join(f"{app_name[a]} ({life[a]})" for a in ids_),
                         "allocated_tech_cost": money(sum(cost[a] for a in ids_))})
        st.dataframe(rows, hide_index=True, width="stretch",
                     column_config={"capability": "Capability", "applications": "Primary applications", "allocated_tech_cost": "Allocated tech cost"})
        st.caption("Where one of the pair is Sunset, this is a planned retirement; otherwise it is a rationalisation candidate.")
    else:
        st.success("No capability has more than one primary application.")

    st.subheader("Orphans: applications mapped to no capability")
    if f["orphans"]:
        o = apps[apps["app_id"].isin(f["orphans"])]
        st.dataframe(o[["app_id", "name", "business_domain", "criticality", "owner_team", "lifecycle"]], hide_index=True, width="stretch",
                     column_config={"app_id": "ID", "name": "Application", "business_domain": "Domain", "criticality": "Tier",
                                    "owner_team": "Owner", "lifecycle": "Lifecycle"})
    else:
        st.success("Every application supports at least one capability.")
