import plotly.express as px
import streamlit as st

from trm.data import INVESTMENT_STANCES
from trm.model import SUPPORT_ORDER
from trm.state import need_model

model = need_model()
t = model.technologies
in_use = t[t["app_count"] > 0].copy()

STANCE_COLOURS = {"Invest": "#0f766e", "Maintain": "#1d4ed8", "Disinvest": "#b91c1c"}

st.title("Invest, maintain, disinvest")
st.caption(f"As of {model.as_of:%d %b %Y}. The investment stance of each technology, set against vendor support dates.")

declared = int((in_use["stance_source"] == "declared").sum())
if declared == 0:
    st.info("This data has no investment_stance column, so stance is derived from the standards status "
            "(Strategic and Emerging: Invest; Standard: Maintain; Contain, Retire, Prohibited: Disinvest).")

by = in_use["investment_stance"].value_counts()
dis = in_use[in_use["investment_stance"] == "Disinvest"]
c = st.columns(5)
c[0].metric("Invest", int(by.get("Invest", 0)))
c[1].metric("Maintain", int(by.get("Maintain", 0)))
c[2].metric("Disinvest", int(by.get("Disinvest", 0)))
c[3].metric("Disinvest with no replacement", int((dis["replacement"] == "").sum()), help="A technology to be wound down needs a named place to move to.")
c[4].metric("Stance contradictions", int((in_use["stance_conflict"] != "").sum()), help="For example Invest on a product whose support ends within 12 months.")

left, right = st.columns([3, 2])
with left:
    st.subheader("Stance by service area")
    g = in_use.groupby(["service_area", "investment_stance"]).size().reset_index(name="technologies")
    fig = px.bar(g, y="service_area", x="technologies", color="investment_stance", orientation="h",
                 color_discrete_map=STANCE_COLOURS, category_orders={"investment_stance": INVESTMENT_STANCES},
                 labels={"service_area": "", "technologies": "Technologies in use", "investment_stance": "Stance"})
    fig.update_layout(height=360, margin=dict(l=0, r=0, t=10, b=0), legend_title_text="", yaxis=dict(autorange="reversed"))
    st.plotly_chart(fig, width="stretch")
with right:
    st.subheader("Support status by stance")
    g = in_use.groupby(["support_state", "investment_stance"]).size().reset_index(name="technologies")
    fig = px.bar(g, y="support_state", x="technologies", color="investment_stance", orientation="h",
                 color_discrete_map=STANCE_COLOURS, category_orders={"support_state": SUPPORT_ORDER, "investment_stance": INVESTMENT_STANCES},
                 labels={"support_state": "", "technologies": "Technologies in use", "investment_stance": "Stance"})
    fig.update_layout(height=360, margin=dict(l=0, r=0, t=10, b=0), legend_title_text="", yaxis=dict(autorange="reversed"))
    st.plotly_chart(fig, width="stretch")

st.subheader("End-of-life view")
f = st.columns([2, 2, 2])
horizon = f[0].slider("Support ending within (months)", 6, 60, 24, step=6)
stances = f[1].multiselect("Stance", INVESTMENT_STANCES, default=INVESTMENT_STANCES)
tier1 = f[2].toggle("Only technologies used by Tier 1 applications", value=False)
eol = in_use[in_use["investment_stance"].isin(stances) & (in_use["months_to_support_end"] <= horizon)]
if tier1:
    eol = eol[eol["tier1_apps"] > 0]
eol = eol.sort_values("months_to_support_end")
st.caption(f"{len(eol)} technologies in use. Technologies with no vendor date are not listed here.")
st.dataframe(
    eol[["label", "service", "investment_stance", "standard_status", "support_state", "end_of_support", "app_count", "tier1_apps", "replacement"]],
    hide_index=True, width="stretch",
    column_config={"label": "Technology", "service": "Service", "investment_stance": "Stance", "standard_status": "Status",
                   "support_state": "Support", "end_of_support": st.column_config.DateColumn("Support ends", format="DD MMM YYYY"),
                   "app_count": st.column_config.NumberColumn("Apps", width="small"),
                   "tier1_apps": st.column_config.NumberColumn("Tier 1 apps", width="small"), "replacement": "Move to"},
)
st.download_button("Download end-of-life list (CSV)", eol.to_csv(index=False).encode("utf-8"), "end_of_life.csv", "text/csv")

st.subheader("Stance contradictions")
bad = in_use[in_use["stance_conflict"] != ""].sort_values("months_to_support_end")
if bad.empty:
    st.success("No in-use technology has a stance that contradicts its status or support date.")
else:
    st.dataframe(bad[["label", "investment_stance", "standard_status", "support_state", "end_of_support", "app_count", "stance_conflict"]],
                 hide_index=True, width="stretch",
                 column_config={"label": "Technology", "investment_stance": "Stance", "standard_status": "Status", "support_state": "Support",
                                "end_of_support": st.column_config.DateColumn("Support ends", format="DD MMM YYYY"),
                                "app_count": st.column_config.NumberColumn("Apps", width="small"), "stance_conflict": "Why it conflicts"})
    st.caption("Either the stance, the status or the support date needs a decision. A deliberate exception should carry a note.")

over = t[(t["stance_source"] == "declared") & (t["investment_stance"] != t["derived_stance"])]
if len(over):
    with st.expander(f"Declared stance differs from the default for the standards status ({len(over)})"):
        st.dataframe(over[["label", "standard_status", "derived_stance", "investment_stance", "stance_note"]], hide_index=True, width="stretch",
                     column_config={"label": "Technology", "standard_status": "Status", "derived_stance": "Default stance",
                                    "investment_stance": "Declared stance", "stance_note": "Reason"})
