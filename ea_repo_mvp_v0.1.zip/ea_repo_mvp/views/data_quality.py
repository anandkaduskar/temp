import streamlit as st

from trm.data import ALL_FILES, FILES, OPTIONAL_FILES, OPTIONAL_COLUMNS, REQUIRED_COLUMNS

st.title("Data quality")
st.caption("Checks run every time the data loads. Errors stop the other pages; warnings and notes do not.")

data = st.session_state.get("data")
issues = st.session_state.get("issues")

if data is None:
    st.warning("No data loaded. Choose a data source in the sidebar.")
    st.stop()

counts = data.counts()
loaded = [k for k in ALL_FILES if k in counts]
for start in range(0, len(loaded), 4):
    row = loaded[start:start + 4]
    for col, key in zip(st.columns(4), row):
        col.metric(ALL_FILES[key], counts[key])
missing_optional = [OPTIONAL_FILES[k] for k in OPTIONAL_FILES if k not in counts]
if missing_optional:
    st.caption("Not loaded (optional, switches on the capability pages): " + ", ".join(missing_optional))

if issues is None or issues.empty:
    st.success("All checks passed.")
else:
    by = issues["severity"].value_counts()
    k = st.columns(3)
    k[0].metric("Errors", int(by.get("Error", 0)))
    k[1].metric("Warnings", int(by.get("Warning", 0)))
    k[2].metric("Notes", int(by.get("Info", 0)))
    sev = st.multiselect("Show", ["Error", "Warning", "Info"], default=["Error", "Warning", "Info"])
    shown = issues[issues["severity"].isin(sev)]
    st.dataframe(shown, hide_index=True, width="stretch",
                 column_config={"severity": "Severity", "file": "File", "row": st.column_config.TextColumn("Row", width="small"), "check": "Check", "detail": "Detail"})
    st.download_button("Download issues (CSV)", shown.to_csv(index=False).encode("utf-8"), "data_issues.csv", "text/csv")

model = st.session_state.get("model")
if model is not None:
    conflicts = model.technologies[(model.technologies["app_count"] > 0) & (model.technologies["stance_conflict"] != "")]
    if len(conflicts):
        st.subheader("Stance contradictions")
        st.caption("Not file errors, but decisions: the stance disagrees with the standards status or the vendor support date.")
        st.dataframe(conflicts[["tech_id", "label", "investment_stance", "standard_status", "support_state", "stance_conflict"]],
                     hide_index=True, width="stretch",
                     column_config={"tech_id": "ID", "label": "Technology", "investment_stance": "Stance", "standard_status": "Status",
                                    "support_state": "Support", "stance_conflict": "Why it conflicts"})

with st.expander("What the checks cover"):
    st.markdown(
        """
- Required columns are present in every file.
- IDs are present and unique; each technology points to a known service; each link points to a known application and technology.
- Status, criticality and deployment model use the agreed values; dates and costs are valid.
- Owners are filled in; applications have at least one technology; unused Contain, Retire and Prohibited products are listed as notes.
- If present: investment stance uses the agreed values and replacements exist; org unit, capability parent and level are consistent;
  every capability mapping points to a known application and capability, with a valid role and fit.
- Notes list capability gaps, capabilities with several primary applications, and applications that support no capability.
"""
    )
with st.expander("Expected CSV columns"):
    for key, cols in REQUIRED_COLUMNS.items():
        st.markdown(f"**{FILES[key]}**: `{', '.join(cols)}`")
    st.markdown("Optional columns on `technologies.csv`: `investment_stance` (Invest, Maintain, Disinvest), `replacement_tech_id`, `stance_note`. "
                "Optional column on `applications.csv`: `org_unit_id`.")
    for key, cols in OPTIONAL_COLUMNS.items():
        st.markdown(f"**{OPTIONAL_FILES[key]}** (optional): `{', '.join(cols)}`")
