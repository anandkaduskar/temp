import streamlit as st

from trm.data import STATUSES
from trm.state import need_model
from trm.ui import legend_html, trm_map_html

model = need_model()
t, stack = model.technologies, model.stack

st.title("TRM map")
st.caption("The reference model as layers: service area, category, service, and the products placed on each service. Hover a product for details.")

areas_all = list(model.services["service_area"].drop_duplicates())
f1, f2, f3 = st.columns([2, 2, 2])
statuses = f1.multiselect("Show statuses", STATUSES, default=STATUSES)
areas = f2.multiselect("Show service areas", areas_all, default=areas_all)
app_names = ["(none)"] + list(model.applications.sort_values("name")["name"])
app = f3.selectbox("Highlight an application's stack", app_names, help="Products used by this application are outlined; the rest fade.")

highlight = None
if app != "(none)":
    highlight = set(stack[stack["application"] == app]["tech_id"])
    st.info(f"{app}: {len(highlight)} technologies highlighted.")

st.markdown(legend_html(), unsafe_allow_html=True)
st.markdown(trm_map_html(model, statuses, areas, highlight), unsafe_allow_html=True)
st.caption("A ! after a product name means vendor support has ended as of the as-of date.")
