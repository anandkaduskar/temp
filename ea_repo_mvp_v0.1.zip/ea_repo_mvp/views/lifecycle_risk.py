import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from trm.data import STATUSES
from trm.model import CRITICALITY_WEIGHT, HIGH_AT, MEDIUM_AT, STATUS_POINTS, SUPPORT_POINTS
from trm.state import need_model
from trm.ui import RISK_COLOURS, STATUS_COLOURS

model = need_model()
t = model.technologies
in_use = t[t["app_count"] > 0].copy()

st.title("Lifecycle and risk")
st.caption("Which technologies are out of support or close to it, how many applications depend on them, and what to deal with first.")

c = st.columns([2, 2, 2])
horizon = c[0].slider("Show support ending within (months)", 6, 60, 24, step=6)
levels = c[1].multiselect("Risk level", ["High", "Medium", "Low"], default=["High", "Medium"])
tier1 = c[2].toggle("Only technologies used by Tier 1 applications", value=False)

view = in_use.copy()
if tier1:
    view = view[view["tier1_apps"] > 0]
view = view[view["risk_level"].isin(levels)]

st.subheader("Support timeline")
tl = in_use[in_use["end_of_support"].notna()].copy()
tl = tl[(tl["end_of_support"] <= model.as_of + pd.DateOffset(months=horizon))]
if tier1:
    tl = tl[tl["tier1_apps"] > 0]
tl = tl.sort_values("end_of_support")
if tl.empty:
    st.info("No technologies in use reach end of support in this window.")
else:
    fig = go.Figure()
    for status in STATUSES:
        d = tl[tl["standard_status"] == status]
        if d.empty:
            continue
        fig.add_trace(go.Scatter(
            x=d["end_of_support"], y=d["label"], mode="markers", name=status,
            marker=dict(size=[8 + 3 * w for w in d["max_crit_weight"]], color=STATUS_COLOURS[status], line=dict(width=1, color="white")),
            customdata=d[["app_count", "support_state", "risk_level"]],
            hovertemplate="<b>%{y}</b><br>Support ends %{x|%d %b %Y}<br>%{customdata[1]}<br>Used by %{customdata[0]} apps<br>Risk: %{customdata[2]}<extra></extra>",
        ))
    fig.add_vline(x=model.as_of, line_dash="dash", line_color="#64748b")
    fig.add_annotation(x=model.as_of, y=1.02, yref="paper", text="As of", showarrow=False, font=dict(size=11))
    fig.update_layout(height=max(320, 22 * len(tl) + 120), margin=dict(l=0, r=0, t=30, b=0), yaxis=dict(autorange="reversed", title="", categoryorder="array", categoryarray=list(tl["label"])), xaxis=dict(title="Vendor end of support"), legend_title_text="Status")
    st.plotly_chart(fig, width="stretch")
    st.caption("Marker size grows with the tier of the most critical application using the technology.")

st.subheader("Priority list")
ranked = view.sort_values(["priority", "app_count"], ascending=False)
st.dataframe(
    ranked[["label", "service", "standard_status", "support_state", "end_of_support", "app_count", "tier1_apps", "status_points", "support_points", "max_crit_weight", "priority", "risk_level"]],
    hide_index=True, width="stretch",
    column_config={
        "label": "Technology", "service": "Service", "standard_status": "Status", "support_state": "Support",
        "end_of_support": st.column_config.DateColumn("Support ends", format="DD MMM YYYY"),
        "app_count": st.column_config.NumberColumn("Apps", width="small"), "tier1_apps": st.column_config.NumberColumn("Tier 1 apps", width="small"),
        "status_points": st.column_config.NumberColumn("Status pts", width="small"), "support_points": st.column_config.NumberColumn("Support pts", width="small"),
        "max_crit_weight": st.column_config.NumberColumn("Tier wt", width="small"),
        "priority": st.column_config.ProgressColumn("Priority", min_value=0, max_value=30, format="%d"), "risk_level": "Risk",
    },
)
st.download_button("Download priority list (CSV)", ranked.to_csv(index=False).encode("utf-8"), "risk_priority.csv", "text/csv")

status_rows = [(s, str(p)) for s, p in STATUS_POINTS.items()]
support_rows = [(k, str(v)) for k, v in SUPPORT_POINTS.items()]
status_rows += [("", "")] * (len(support_rows) - len(status_rows))
score_table = "\n".join(f"| {s} | {sp} | | {k} | {kp} |" for (s, sp), (k, kp) in zip(status_rows, support_rows))

with st.expander("How the score works"):
    st.markdown(
        f"""
**Priority = (status points + support points) x tier weight of the most critical application that uses the technology.**

| Status | Points | | Support state | Points |
| --- | --- | --- | --- | --- |
{score_table}

Tier weights: {", ".join(f"{k} = {v}" for k, v in CRITICALITY_WEIGHT.items())}. Risk is **High** at {HIGH_AT} or more, **Medium** from {MEDIUM_AT}, otherwise **Low**.
These rules are a starting point; edit `STATUS_POINTS`, `SUPPORT_POINTS` and `CRITICALITY_WEIGHT` in `trm/model.py`.
"""
    )
