"""Enterprise architecture repository prototype: technology reference model, lifecycle and capability mapping.

Run:  streamlit run app.py
"""
import streamlit as st

from trm.state import render_sidebar

st.set_page_config(page_title="EA repository", page_icon=":material/hub:", layout="wide")

data, issues, model = render_sidebar()
st.session_state["data"] = data
st.session_state["issues"] = issues
st.session_state["model"] = model

pages = {
    "Technology": [
        st.Page("views/overview.py", title="Overview", icon=":material/dashboard:", url_path="overview", default=True),
        st.Page("views/trm_map.py", title="TRM map", icon=":material/grid_view:", url_path="trm-map"),
        st.Page("views/catalogue.py", title="Technology catalogue", icon=":material/inventory_2:", url_path="catalogue"),
        st.Page("views/application.py", title="Application view", icon=":material/apps:", url_path="application"),
        st.Page("views/lifecycle_risk.py", title="Lifecycle and risk", icon=":material/warning:", url_path="risk"),
        st.Page("views/stance.py", title="Invest / disinvest", icon=":material/trending_flat:", url_path="stance"),
    ],
}
if model is not None and model.has_capabilities:
    pages["Business capability"] = [
        st.Page("views/capability_map.py", title="Capability map", icon=":material/account_tree:", url_path="capability-map"),
        st.Page("views/capability_mapping.py", title="Capability mapping", icon=":material/link:", url_path="capability-mapping"),
        st.Page("views/exposure.py", title="Exposure by area", icon=":material/insights:", url_path="exposure"),
    ]
pages["Quality"] = [
    st.Page("views/data_quality.py", title="Data quality", icon=":material/fact_check:", url_path="data-quality"),
]
st.navigation(pages).run()
