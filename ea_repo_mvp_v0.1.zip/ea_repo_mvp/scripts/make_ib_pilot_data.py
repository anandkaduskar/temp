"""Generate the Investment Banking pilot dataset for the EA repository MVP.

Writes CSV files to ../data/ib_pilot/ (relative to this script) and runs integrity checks.
Standard library only. Re-run any time: output is deterministic.

ILLUSTRATIVE DATA: application names are generic descriptions of capability-supporting systems,
not a statement about any real organisation's systems. Technology versions, dates, costs and
all mappings are made up for the prototype. The capability tree follows cib_capability_map.html
(L1/L2, with L3 under L1.1 to L1.4); `source_confidence` carries that map's tag
(Confirmed / Standard / Unconfirmed).
"""
import csv
import shutil
from datetime import date
from pathlib import Path

HERE = Path(__file__).resolve().parent
SAMPLE = HERE.parent / "data" / "sample"
OUT = HERE.parent / "data" / "ib_pilot"
AS_OF = date(2026, 11, 1)

# ---------------------------------------------------------------- org units
ORG_UNITS = [
    ("OU-000", "", "Global CIB Technology", "Division"),
    ("OU-010", "OU-000", "Banking and Coverage Technology", "Department"),
    ("OU-020", "OU-000", "Global Markets Technology", "Department"),
    ("OU-030", "OU-000", "Transaction Banking Technology", "Department"),
    ("OU-040", "OU-000", "Risk and Treasury Technology", "Department"),
    ("OU-050", "OU-000", "Operations Technology", "Department"),
    ("OU-060", "OU-000", "Finance and Regulatory Technology", "Department"),
    ("OU-070", "OU-000", "Control Functions Technology", "Department"),
    ("OU-080", "OU-000", "Data and Platform Engineering", "Department"),
    ("OU-090", "OU-000", "Enterprise Architecture", "Department"),
]
OU_NAME = {o[0]: o[2] for o in ORG_UNITS}

# ------------------------------------------------------------- capabilities
# (number, name, confidence, description). Number encodes the level: "1", "1.2", "1.2.3".
C, S, U = "Confirmed", "Standard", "Unconfirmed"
CAPS = [
    ("1", "Client Coverage and Origination", "", "Front-office relationship and deal origination"),
    ("1.1", "Industry and Regional Coverage", C, "Who owns the client, by industry and region"),
    ("1.1.1", "Industry coverage groups", C, "Nine industry groups (Americas)"),
    ("1.1.2", "Regional coverage", C, "US, Canada, Latin America, EMEA, APAC, Japanese banking"),
    ("1.1.3", "India and Pune coverage model", U, "Relationship of the Pune centre to client coverage"),
    ("1.2", "M&A and Advisory", C, "Advisory franchise"),
    ("1.2.1", "M&A advisory", C, "Buy-side and sell-side advisory"),
    ("1.2.2", "Restructuring", C, "Distressed and restructuring advisory"),
    ("1.2.3", "Derivative risk solutions", C, "Advisory-led hedging structures"),
    ("1.2.4", "Private capital advisory", C, "Sponsor and private capital raising"),
    ("1.3", "Capital Markets Origination", C, "Primary markets origination"),
    ("1.3.1", "Equity Capital Markets", C, "IPOs, follow-ons, equity-linked, placements"),
    ("1.3.2", "Debt Capital Markets", C, "IG bonds, loans, ABS, commercial paper, syndicate"),
    ("1.3.3", "Leveraged Finance", C, "Leveraged loans, high yield, acquisition financing"),
    ("1.3.4", "Structured and Project Finance", C, "Securitisation, project and infrastructure, lease finance"),
    ("1.4", "Deal and Pipeline Governance", S, "Pipeline, information barriers, deal documents"),
    ("1.4.1", "Deal pipeline and CRM", S, "Origination and pipeline tracking"),
    ("1.4.2", "Information barriers", S, "Wall-crossing and MNPI controls"),
    ("1.4.3", "Data room and document controls", S, "Deal document security and access"),
    ("2", "Global Markets (Sales and Trading)", "", "Sales, trading and execution"),
    ("2.1", "Fixed Income (Rates, Credit)", C, "Sales and trading across bonds"),
    ("2.2", "FX", U, "Standalone desk or embedded in Fixed Income / Treasury"),
    ("2.3", "Equities", C, "Cash equities and equity derivatives"),
    ("2.4", "Securitised Products and ABS trading", C, "ABS trading across consumer and trade receivables"),
    ("2.5", "Futures and Options Clearing and Execution", C, "Clearing and execution services"),
    ("2.6", "Derivatives Structuring, Pricing and XVA", C, "Cross-asset structuring and XVA"),
    ("2.7", "Electronic Trading and Market Making", S, "E-trading, algo execution, market making"),
    ("2.8", "Research", C, "Macro, credit and equity research"),
    ("3", "Corporate and Transaction Banking", "", "Lending, trade and cash"),
    ("3.1", "Corporate Lending", C, "Revolvers, term loans, bridge and non-recourse lending"),
    ("3.2", "Trade and Supply Chain Finance", C, "Letters of credit, receivables and supply chain finance"),
    ("3.3", "Cash Management and Treasury Services", C, "Treasury services, cards, payment rails"),
    ("3.4", "Project and Infrastructure Finance", C, "Infrastructure, energy, power, rail"),
    ("3.5", "Lease Finance", C, "Equipment, aircraft, rail car, real estate leases"),
    ("3.6", "Client Onboarding and Credit Workflow", S, "Onboarding, limits, credit approval"),
    ("4", "Risk Management and Treasury", "", "Risk, liquidity and capital"),
    ("4.1", "Market Risk", S, "VaR, sensitivities, stress testing, FRTB"),
    ("4.2", "Credit Risk", S, "Counterparty exposure, limits, concentration"),
    ("4.3", "Liquidity Risk and Funding", S, "Intraday liquidity, LCR, NSFR"),
    ("4.4", "Capital Management", S, "RWA, capital planning, stress testing"),
    ("4.5", "Model Risk Management", S, "Model governance and validation"),
    ("5", "Trade Capture, Confirmation and Booking", "", "Middle-office trade lifecycle"),
    ("5.1", "Trade Capture and Enrichment", S, "Booking from front office, static data enrichment"),
    ("5.2", "Confirmation and Matching", S, "Electronic and manual confirmation"),
    ("5.3", "Allocation and Booking", S, "Block allocation, entity and book assignment"),
    ("5.4", "Amendment and Exception Management", S, "Amendments, cancellations, breaks"),
    ("6", "Clearing, Settlement and Collateral", "", "Post-trade"),
    ("6.1", "Settlement Management", S, "DVP, FOP, FX settlement, fails"),
    ("6.2", "Clearing", C, "CCP relationships, futures and options clearing"),
    ("6.3", "Collateral and Margin Management", S, "Margin calls, tri-party collateral"),
    ("6.4", "Reconciliation and Break Management", S, "Reconciliation and break resolution"),
    ("6.5", "Corporate Actions Processing", S, "Event notification, election, position adjustment"),
    ("7", "Finance, Regulatory Reporting and Data", "", "Finance, reporting and data"),
    ("7.1", "Product Control and P&L", S, "Desk P&L, independent price verification"),
    ("7.2", "Financial and Regulatory Reporting", S, "Per-jurisdiction regulatory filings"),
    ("7.3", "Risk Data Aggregation and Lineage", S, "BCBS 239 aggregation, lineage, golden source"),
    ("7.4", "Reference and Market Data Management", S, "Golden source for trade, client, reference data"),
    ("8", "Control Functions", "", "Second and third line controls"),
    ("8.1", "Compliance", S, "AML, KYC, sanctions, conduct"),
    ("8.2", "Trade and Communications Surveillance", S, "Market abuse and communications surveillance"),
    ("8.3", "Operational Risk", S, "RCSA, incidents, KRIs"),
    ("8.4", "Internal Audit and Evidence Generation", S, "Audit-ready evidence from delivery pipelines"),
    ("9", "Cross-Cutting Enablers", "", "Shared enablers"),
    ("9.1", "Client and Counterparty Reference Data and Identity", S, "Golden client record, KYC reuse"),
    ("9.2", "Market Data Management", S, "Sourcing, cost, entitlements"),
    ("9.3", "Technology Platforms", U, "Shared vs duplicated platforms by entity and region"),
    ("9.4", "Cloud, Resilience and Security Architecture", U, "Approved cloud landscape, exit plans, zero trust"),
    ("9.5", "AI and Agentic AI Governance", C, "Use-case intake, prioritisation, tollgates"),
]
L1_OWNER = {"1": "OU-010", "2": "OU-020", "3": "OU-030", "4": "OU-040", "5": "OU-050",
            "6": "OU-050", "7": "OU-060", "8": "OU-070", "9": "OU-080"}
L1_NAME = {n: name for n, name, *_ in CAPS if "." not in n}


def cap_id(num):
    return "CAP-" + num


# ------------------------------------------------------------- applications
# Short names for technology ids (see data/sample/technologies.csv).
T = dict(J21="TECH-001", J17="TECH-002", J8="TECH-003", PY312="TECH-004", PY311="TECH-005",
         PY39="TECH-006", NET8="TECH-007", NETFW="TECH-009", JBOSS="TECH-013", WAS="TECH-014",
         TOMCAT="TECH-015", IIS="TECH-017", OCP="TECH-018", AKS="TECH-019", SQL22="TECH-020",
         SQL19="TECH-021", SQL16="TECH-022", ORA="TECH-023", PG="TECH-024", COSMOS="TECH-026",
         PBI="TECH-029", DBX="TECH-031", ADF="TECH-033", INFA="TECH-034", PURVIEW="TECH-036",
         KAFKA="TECH-037", MQ="TECH-038", RMQ="TECH-039", APIM="TECH-041", RHEL9="TECH-045",
         RHEL8="TECH-046", RHEL7="TECH-047", W22="TECH-048", W19="TECH-049", W16="TECH-050",
         VS8="TECH-052", VS7="TECH-053", AZURE="TECH-055", ENTRA="TECH-064", ELK="TECH-086",
         MON="TECH-083", SNOW="TECH-087", FABRIC="TECH-028")

# (name, tier, org unit, lifecycle, last_reviewed, capabilities, stack)
# capabilities: "num:P|S:G|P|X" = capability number, Primary/Supporting, Good/Partial/Poor
APPS = [
    ("Client Coverage CRM", 2, "OU-010", "Live", "2026-09-14", "1.1.1:P:G 1.1.2:P:G 1.4.1:S:G", "NET8 IIS SQL19 W19 VS8"),
    ("Deal Pipeline Tracker", 2, "OU-010", "Live", "2026-08-30", "1.4.1:P:G 1.2.1:S:P", "J17 TOMCAT SQL19 RHEL8 VS8"),
    ("Information Barrier Register", 1, "OU-070", "Live", "2026-10-05", "1.4.2:P:G 8.1:S:G", "J21 OCP PG RHEL9"),
    ("Deal Data Room Gateway", 2, "OU-010", "Live", "2026-07-21", "1.4.3:P:G", "NET8 IIS SQL19 W19"),
    ("ECM Book-building Platform", 1, "OU-010", "Live", "2026-09-02", "1.3.1:P:G", "J17 JBOSS ORA RHEL8 MQ VS8"),
    ("DCM Issuance Platform", 1, "OU-010", "Live", "2026-09-02", "1.3.2:P:G", "J17 JBOSS ORA RHEL8 MQ VS8"),
    ("Leveraged Finance Workflow", 2, "OU-010", "Live", "2025-11-18", "1.3.3:P:P 3.1:S:G", "J8 WAS ORA RHEL7 MQ VS7"),
    ("Securitisation Structuring Tool", 2, "OU-010", "Live", "2026-06-11", "1.3.4:P:G 2.4:S:P", "PY311 SQL19 W19"),
    ("Fixed Income Trading Platform", 1, "OU-020", "Live", "2026-10-12", "2.1:P:G 5.1:S:G", "J21 OCP KAFKA SQL22 RHEL9"),
    ("FX Trading Platform", 1, "OU-020", "Live", "2026-10-12", "2.2:P:G 2.7:S:G", "J17 OCP KAFKA SQL19 RHEL8"),
    ("Equities Order and Execution", 1, "OU-020", "Live", "2026-09-27", "2.3:P:G 2.7:P:G", "J17 TOMCAT KAFKA ORA RHEL8 VS8"),
    ("Derivatives Pricing Engine", 1, "OU-020", "Live", "2026-08-19", "2.6:P:G", "PY312 OCP DBX SQL22 RHEL9"),
    ("XVA Analytics Engine", 1, "OU-040", "Live", "2026-08-19", "2.6:S:G 4.4:S:P", "PY311 OCP DBX AZURE RHEL8"),
    ("Futures and Options Clearing Gateway", 1, "OU-050", "Live", "2026-02-03", "2.5:P:G 6.2:P:G", "J8 WAS MQ ORA RHEL7 VS7"),
    ("Research Publishing Platform", 3, "OU-020", "Live", "2026-03-09", "2.8:P:G", "NETFW IIS SQL16 W16 VS8"),
    ("Corporate Lending System", 1, "OU-030", "Live", "2026-09-30", "3.1:P:G", "J17 WAS ORA RHEL8 MQ VS8"),
    ("Trade Finance Processing", 1, "OU-030", "Live", "2026-05-22", "3.2:P:G", "NETFW IIS SQL16 W16 VS8"),
    ("Cash Management and Payments Hub", 1, "OU-030", "Live", "2026-10-20", "3.3:P:G", "J21 OCP KAFKA PG RHEL9 APIM"),
    ("Client Onboarding and KYC Workflow", 1, "OU-070", "Live", "2026-10-08", "3.6:P:G 8.1:P:G 9.1:S:P", "NET8 AKS AZURE SQL22 COSMOS"),
    ("Market Risk Engine", 1, "OU-040", "Live", "2026-09-15", "4.1:P:G", "J17 OCP ORA RHEL8 KAFKA"),
    ("Counterparty Exposure System", 1, "OU-040", "Live", "2026-01-27", "4.2:P:G 3.6:S:G", "J8 JBOSS ORA RHEL7 VS7"),
    ("Liquidity and Funding Monitor", 2, "OU-040", "Live", "2026-07-02", "4.3:P:G", "PY311 SQL19 W19 PBI"),
    ("Capital and RWA Calculator", 1, "OU-040", "Live", "2026-09-09", "4.4:P:G", "PY312 DBX AZURE ADF"),
    ("Model Inventory and Validation Tracker", 3, "OU-040", "Live", "2026-04-14", "4.5:P:G", "NET8 SQL19 W19"),
    ("Trade Capture Hub", 1, "OU-050", "Live", "2026-10-22", "5.1:P:G 5.3:P:G", "J21 OCP KAFKA PG RHEL9"),
    ("Confirmation Matching Service", 1, "OU-050", "Live", "2026-10-22", "5.2:P:G 5.4:P:G", "J17 JBOSS MQ SQL19 RHEL8"),
    ("Settlement Engine", 1, "OU-050", "Live", "2026-08-11", "6.1:P:G", "J17 WAS MQ ORA RHEL8 VS8"),
    ("Collateral and Margin Manager", 1, "OU-050", "Live", "2026-09-18", "6.3:P:G", "J21 OCP KAFKA SQL22 RHEL9"),
    ("Legacy Margin Calculator", 3, "OU-050", "Sunset", "2025-09-12", "6.3:P:P", "J8 TOMCAT SQL16 W16 VS7"),
    ("Reconciliation Platform", 2, "OU-050", "Live", "2026-10-01", "6.4:P:G", "J17 OCP PG RHEL8"),
    ("Legacy Reconciliation Tool", 3, "OU-050", "Sunset", "2025-10-03", "6.4:P:P", "PY39 SQL16 W16 VS7"),
    ("Corporate Actions Processor", 2, "OU-050", "Live", "2026-06-25", "6.5:P:G", "J17 TOMCAT ORA RHEL8 VS8"),
    ("Product Control P&L System", 1, "OU-060", "Live", "2026-09-04", "7.1:P:G", "NET8 SQL19 W19 PBI"),
    ("Regulatory Reporting Hub", 1, "OU-060", "Live", "2026-10-15", "7.2:P:G", "PY311 DBX INFA SQL19 RHEL8"),
    ("Risk Data Aggregation Platform", 1, "OU-080", "Build", "2026-10-28", "7.3:P:P 4.1:S:G", "PY312 DBX FABRIC ADF PURVIEW AZURE"),
    ("Reference Data Hub", 1, "OU-080", "Live", "2026-10-10", "7.4:P:G 9.1:P:G", "J17 OCP SQL19 KAFKA RHEL8"),
    ("Market Data Platform", 1, "OU-080", "Live", "2026-09-22", "9.2:P:G 7.4:S:G", "J17 KAFKA SQL22 RHEL8 MQ"),
    ("Trade and Communications Surveillance", 1, "OU-070", "Live", "2026-08-27", "8.2:P:G", "PY311 ELK RHEL8 DBX"),
    ("Operational Risk GRC Platform", 2, "OU-070", "Live", "2026-05-05", "8.3:P:G 8.4:S:P", "NET8 SQL19 W19"),
    ("Audit Evidence Collector", 3, "OU-070", "Build", "2026-10-30", "8.4:P:P", "PY312 OCP PG RHEL9"),
    ("AI Use-Case Register", 2, "OU-090", "Build", "2026-10-26", "9.5:P:G", "NET8 AKS AZURE COSMOS"),
    ("Legacy Desk Reporting Tool", 3, "OU-020", "Sunset", "2025-06-30", "", "NETFW IIS SQL16 W16"),
]
COMMON = ["ENTRA", "MON", "SNOW"]

# stance overrides: tech_id -> (stance, note)
STANCE_OVERRIDE = {
    "TECH-023": ("Maintain", "Core to several Tier 1 applications; no approved replacement yet"),
    "TECH-043": ("Maintain", "Retained until the integration migration completes"),
    "TECH-031": ("Invest", "Target analytics platform for risk data aggregation"),
}
REPLACEMENT = {
    "TECH-003": "TECH-001", "TECH-006": "TECH-004", "TECH-009": "TECH-007", "TECH-012": "TECH-010",
    "TECH-014": "TECH-015", "TECH-022": "TECH-020", "TECH-025": "TECH-026", "TECH-034": "TECH-033",
    "TECH-035": "TECH-033", "TECH-039": "TECH-037", "TECH-044": "TECH-041", "TECH-047": "TECH-045",
    "TECH-050": "TECH-048", "TECH-051": "TECH-048", "TECH-053": "TECH-052", "TECH-060": "TECH-059",
    "TECH-065": "TECH-064", "TECH-071": "TECH-070", "TECH-075": "TECH-074", "TECH-077": "TECH-076",
    "TECH-079": "TECH-078",
}
STANCE_FROM_STATUS = {"Strategic": "Invest", "Emerging": "Invest", "Standard": "Maintain",
                      "Contain": "Disinvest", "Retire": "Disinvest", "Prohibited": "Disinvest"}


def read(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write(name, header, rows):
    with open(OUT / name, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    shutil.copy(SAMPLE / "services.csv", OUT / "services.csv")

    # org units
    write("org_units.csv", ["org_unit_id", "parent_org_unit_id", "name", "type"], ORG_UNITS)

    # capabilities
    rows = []
    for num, name, conf, desc in CAPS:
        level = num.count(".") + 1
        parent = cap_id(num.rsplit(".", 1)[0]) if level > 1 else ""
        rows.append([cap_id(num), parent, f"L{level}", name, desc, conf, L1_OWNER[num.split(".")[0]]])
    write("capabilities.csv", ["cap_id", "parent_cap_id", "level", "name", "description",
                               "source_confidence", "owner_org_unit_id"], rows)

    # technologies (add stance columns)
    techs = read(SAMPLE / "technologies.csv")
    header = list(techs[0].keys()) + ["investment_stance", "replacement_tech_id", "stance_note"]
    trows = []
    for t in techs:
        stance, note = STANCE_OVERRIDE.get(t["tech_id"], (STANCE_FROM_STATUS[t["standard_status"]], ""))
        trows.append(list(t.values()) + [stance, REPLACEMENT.get(t["tech_id"], ""), note])
    write("technologies.csv", header, trows)

    # applications, app_capability, app_technology
    usage_of = {}
    for r in read(SAMPLE / "app_technology.csv"):
        usage_of.setdefault(r["tech_id"], r["usage"])
    apps, links, mappings = [], [], []
    for i, (name, tier, ou, life, rev, caps, stack) in enumerate(APPS, start=1):
        app_id = f"APP-{i:03d}"
        caps_list = [c.split(":") for c in caps.split()]
        domain = L1_NAME[caps_list[0][0].split(".")[0]] if caps_list else "Global Markets (Sales and Trading)"
        apps.append([app_id, name, domain, f"Tier {tier}", OU_NAME[ou], life, ou, rev])
        for num, level, fit in caps_list:
            mappings.append([app_id, cap_id(num), "Primary" if level == "P" else "Supporting",
                             {"G": "Good", "P": "Partial", "X": "Poor"}[fit]])
        for code in stack.split() + COMMON:
            tid = T[code]
            links.append([app_id, tid, usage_of.get(tid, "Other")])
    write("applications.csv", ["app_id", "name", "business_domain", "criticality", "owner_team",
                               "lifecycle", "org_unit_id", "last_reviewed"], apps)
    write("app_capability.csv", ["app_id", "cap_id", "support_level", "fit"], mappings)
    write("app_technology.csv", ["app_id", "tech_id", "usage"], links)

    check(OUT)


def check(folder):
    """Referential integrity plus the three built-in findings."""
    org = {r["org_unit_id"] for r in read(folder / "org_units.csv")}
    caps = read(folder / "capabilities.csv")
    cap_ids = {r["cap_id"] for r in caps}
    techs = {r["tech_id"]: r for r in read(folder / "technologies.csv")}
    apps = {r["app_id"]: r for r in read(folder / "applications.csv")}
    maps = read(folder / "app_capability.csv")
    links = read(folder / "app_technology.csv")
    svc = {r["service_id"] for r in read(folder / "services.csv")}

    errors = []
    errors += [f"capability {r['cap_id']}: bad parent" for r in caps if r["parent_cap_id"] and r["parent_cap_id"] not in cap_ids]
    errors += [f"capability {r['cap_id']}: bad owner" for r in caps if r["owner_org_unit_id"] not in org]
    errors += [f"app {a['app_id']}: bad org unit" for a in apps.values() if a["org_unit_id"] not in org]
    errors += [f"app_capability {m['app_id']}/{m['cap_id']}: broken link" for m in maps if m["app_id"] not in apps or m["cap_id"] not in cap_ids]
    errors += [f"app_technology {l['app_id']}/{l['tech_id']}: broken link" for l in links if l["app_id"] not in apps or l["tech_id"] not in techs]
    errors += [f"tech {t['tech_id']}: bad service" for t in techs.values() if t["service_id"] not in svc]
    errors += [f"tech {t['tech_id']}: bad replacement" for t in techs.values() if t["replacement_tech_id"] and t["replacement_tech_id"] not in techs]
    dup = {(m["app_id"], m["cap_id"]) for m in maps if sum(1 for x in maps if (x["app_id"], x["cap_id"]) == (m["app_id"], m["cap_id"])) > 1}
    errors += [f"duplicate mapping {d}" for d in dup]

    leaf_caps = [r for r in caps if r["level"] != "L1" and not any(c["parent_cap_id"] == r["cap_id"] for c in caps)]
    primary = {}
    for m in maps:
        if m["support_level"] == "Primary":
            primary.setdefault(m["cap_id"], []).append(m["app_id"])
    covered = {m["cap_id"] for m in maps}
    gaps = [r["cap_id"] for r in leaf_caps if r["cap_id"] not in covered]
    overlaps = {c: a for c, a in primary.items() if len(a) > 1}
    mapped_apps = {m["app_id"] for m in maps}
    orphans = [a for a in apps if a not in mapped_apps]

    stance_flags = []
    for t in techs.values():
        eos = t["end_of_support"]
        if t["investment_stance"] == "Invest" and eos:
            months = (date.fromisoformat(eos) - AS_OF).days / 30.4
            if months < 12:
                stance_flags.append(f"{t['tech_id']} {t['name']} {t['version']}: Invest but support ends {eos}")

    print(f"Wrote {OUT}")
    print(f"  org units {len(org)} | capabilities {len(caps)} | applications {len(apps)} | "
          f"technologies {len(techs)} | app-capability {len(maps)} | app-technology {len(links)}")
    print(f"Integrity errors: {len(errors)}")
    for e in errors:
        print("  ERROR", e)
    print(f"Capability gaps (leaf, no application): {len(gaps)}: {', '.join(gaps)}")
    print(f"Overlaps (several Primary apps): {overlaps}")
    print(f"Orphan applications: {orphans}")
    print(f"Stance contradictions: {len(stance_flags)}")
    for s in stance_flags:
        print("  ", s)


if __name__ == "__main__":
    main()
