"""Generate the illustrative sample CSV files for the TRM prototype.

Run:  python scripts/make_sample_data.py
Writes four files to data/sample/:
  services.csv          the reference model (area > category > service)
  technologies.csv      products and versions, placed on a service
  applications.csv      the applications that use them
  app_technology.csv    which application uses which technology, and how

All names, owners, costs and dates are ILLUSTRATIVE. Vendor support dates are
approximate and must be checked against vendor sources before real use.
"""
from __future__ import annotations

import csv
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / "data" / "sample"

# ---------------------------------------------------------------- services
# (area, category, service)
SERVICES = [
    ("Application Platforms", "Runtimes and Frameworks", "Java runtime"),
    ("Application Platforms", "Runtimes and Frameworks", "Python runtime"),
    ("Application Platforms", "Runtimes and Frameworks", ".NET runtime"),
    ("Application Platforms", "Runtimes and Frameworks", "Node.js runtime"),
    ("Application Platforms", "Application Hosting", "Application server"),
    ("Application Platforms", "Application Hosting", "Web server"),
    ("Application Platforms", "Containers", "Container platform"),
    ("Data and Analytics", "Data Stores", "Relational database"),
    ("Data and Analytics", "Data Stores", "Document database"),
    ("Data and Analytics", "Data Stores", "Data warehouse"),
    ("Data and Analytics", "Analytics and BI", "BI and dashboards"),
    ("Data and Analytics", "Analytics and BI", "Data science platform"),
    ("Data and Analytics", "Data Management", "Data integration (ETL)"),
    ("Data and Analytics", "Data Management", "Data catalogue"),
    ("Integration and Messaging", "Messaging", "Message streaming"),
    ("Integration and Messaging", "Messaging", "Managed file transfer"),
    ("Integration and Messaging", "APIs and Integration", "API gateway"),
    ("Integration and Messaging", "APIs and Integration", "Integration platform"),
    ("Infrastructure and Compute", "Operating Systems", "Linux server OS"),
    ("Infrastructure and Compute", "Operating Systems", "Windows server OS"),
    ("Infrastructure and Compute", "Virtualisation and Cloud", "Hypervisor"),
    ("Infrastructure and Compute", "Virtualisation and Cloud", "Public cloud"),
    ("Infrastructure and Compute", "Storage and Backup", "Storage"),
    ("Infrastructure and Compute", "Storage and Backup", "Backup"),
    ("Network and Connectivity", "Network Services", "Load balancer"),
    ("Network and Connectivity", "Network Services", "Remote access (VPN)"),
    ("Security and Identity", "Identity and Access", "Identity provider"),
    ("Security and Identity", "Identity and Access", "Privileged access"),
    ("Security and Identity", "Security Operations", "SIEM"),
    ("Security and Identity", "Security Operations", "Vulnerability scanning"),
    ("Security and Identity", "Security Operations", "Secrets management"),
    ("End User and Collaboration", "Productivity", "Productivity suite"),
    ("End User and Collaboration", "Productivity", "Team chat and meetings"),
    ("End User and Collaboration", "Endpoints", "Desktop OS"),
    ("Engineering and DevOps", "Source and Build", "Source control"),
    ("Engineering and DevOps", "Source and Build", "CI/CD pipeline"),
    ("Engineering and DevOps", "Source and Build", "Artifact repository"),
    ("Engineering and DevOps", "Automation", "Infrastructure as code"),
    ("Operations and Observability", "Monitoring", "Infrastructure monitoring"),
    ("Operations and Observability", "Monitoring", "Application performance"),
    ("Operations and Observability", "Monitoring", "Log management"),
    ("Operations and Observability", "Service Management", "ITSM platform"),
    ("Operations and Observability", "Service Management", "CMDB"),
]

# ------------------------------------------------------------ technologies
# name, vendor, version, service, status, deployment, end_of_support, owner, annual cost USD
T = [
    # Application platforms
    ("OpenJDK", "Eclipse Adoptium", "21", "Java runtime", "Strategic", "Self-managed", "2031-09-30", "Platform Engineering", 0),
    ("OpenJDK", "Eclipse Adoptium", "17", "Java runtime", "Standard", "Self-managed", "2029-09-30", "Platform Engineering", 0),
    ("Oracle Java SE", "Oracle", "8", "Java runtime", "Retire", "Self-managed", "2030-12-31", "Platform Engineering", 185000),
    ("Python", "Python Software Foundation", "3.12", "Python runtime", "Strategic", "Self-managed", "2028-10-31", "Platform Engineering", 0),
    ("Python", "Python Software Foundation", "3.11", "Python runtime", "Standard", "Self-managed", "2027-10-31", "Platform Engineering", 0),
    ("Python", "Python Software Foundation", "3.9", "Python runtime", "Retire", "Self-managed", "2025-10-31", "Platform Engineering", 0),
    (".NET", "Microsoft", "8", ".NET runtime", "Standard", "Self-managed", "2026-11-10", "Platform Engineering", 0),
    (".NET", "Microsoft", "9", ".NET runtime", "Emerging", "Self-managed", "2026-11-10", "Platform Engineering", 0),
    (".NET Framework", "Microsoft", "4.8", ".NET runtime", "Contain", "Self-managed", "", "Platform Engineering", 0),
    ("Node.js", "OpenJS Foundation", "22", "Node.js runtime", "Strategic", "Self-managed", "2027-04-30", "Platform Engineering", 0),
    ("Node.js", "OpenJS Foundation", "20", "Node.js runtime", "Standard", "Self-managed", "2026-04-30", "Platform Engineering", 0),
    ("Node.js", "OpenJS Foundation", "18", "Node.js runtime", "Retire", "Self-managed", "2025-04-30", "Platform Engineering", 0),
    ("JBoss EAP", "Red Hat", "7.4", "Application server", "Standard", "Self-managed", "2026-06-30", "Platform Engineering", 240000),
    ("WebSphere Application Server", "IBM", "9.0", "Application server", "Contain", "Self-managed", "2028-04-30", "Platform Engineering", 410000),
    ("Apache Tomcat", "Apache Software Foundation", "9", "Application server", "Standard", "Self-managed", "2027-12-31", "Platform Engineering", 0),
    ("NGINX", "F5", "1.26", "Web server", "Strategic", "Self-managed", "", "Platform Engineering", 30000),
    ("IIS", "Microsoft", "10", "Web server", "Contain", "Self-managed", "", "Windows Engineering", 0),
    ("Red Hat OpenShift", "Red Hat", "4.16", "Container platform", "Strategic", "Self-managed", "2027-06-27", "Cloud Platform", 650000),
    ("Azure Kubernetes Service", "Microsoft", "1.30", "Container platform", "Emerging", "PaaS", "", "Cloud Platform", 120000),
    # Data and analytics
    ("SQL Server", "Microsoft", "2022", "Relational database", "Strategic", "Self-managed", "2033-01-11", "Database Services", 520000),
    ("SQL Server", "Microsoft", "2019", "Relational database", "Standard", "Self-managed", "2030-01-08", "Database Services", 480000),
    ("SQL Server", "Microsoft", "2016", "Relational database", "Retire", "Self-managed", "2026-07-14", "Database Services", 390000),
    ("Oracle Database", "Oracle", "19c", "Relational database", "Contain", "Self-managed", "2027-04-30", "Database Services", 900000),
    ("PostgreSQL", "PostgreSQL Global Development Group", "15", "Relational database", "Emerging", "Self-managed", "2027-11-11", "Database Services", 0),
    ("MongoDB", "MongoDB", "6.0", "Document database", "Contain", "Self-managed", "2025-07-31", "Database Services", 95000),
    ("Azure Cosmos DB", "Microsoft", "n/a", "Document database", "Emerging", "PaaS", "", "Cloud Platform", 70000),
    ("Azure Synapse Analytics", "Microsoft", "n/a", "Data warehouse", "Contain", "PaaS", "", "Data Engineering", 310000),
    ("Microsoft Fabric", "Microsoft", "n/a", "Data warehouse", "Emerging", "SaaS", "", "Data Engineering", 150000),
    ("Power BI", "Microsoft", "n/a", "BI and dashboards", "Strategic", "SaaS", "", "Data Engineering", 140000),
    ("Tableau", "Salesforce", "2024.2", "BI and dashboards", "Contain", "Self-managed", "", "Data Engineering", 220000),
    ("Databricks", "Databricks", "n/a", "Data science platform", "Standard", "SaaS", "", "Data Engineering", 380000),
    ("Anaconda Distribution", "Anaconda", "2023.09", "Data science platform", "Contain", "Self-managed", "", "Data Engineering", 25000),
    ("Azure Data Factory", "Microsoft", "n/a", "Data integration (ETL)", "Strategic", "PaaS", "", "Data Engineering", 85000),
    ("Informatica PowerCenter", "Informatica", "10.4", "Data integration (ETL)", "Retire", "Self-managed", "2026-12-31", "Data Engineering", 560000),
    ("SSIS", "Microsoft", "2016", "Data integration (ETL)", "Contain", "Self-managed", "2026-07-14", "Data Engineering", 0),
    ("Microsoft Purview", "Microsoft", "n/a", "Data catalogue", "Emerging", "SaaS", "", "Data Governance", 60000),
    # Integration
    ("Apache Kafka", "Apache Software Foundation", "3.7", "Message streaming", "Standard", "Self-managed", "2026-11-30", "Integration Services", 140000),
    ("IBM MQ", "IBM", "9.3", "Message streaming", "Standard", "Self-managed", "2028-09-30", "Integration Services", 300000),
    ("RabbitMQ", "Broadcom", "3.12", "Message streaming", "Contain", "Self-managed", "2025-12-31", "Integration Services", 0),
    ("Axway SecureTransport", "Axway", "5.5", "Managed file transfer", "Contain", "Self-managed", "2027-06-30", "Integration Services", 110000),
    ("Azure API Management", "Microsoft", "n/a", "API gateway", "Strategic", "PaaS", "", "Integration Services", 55000),
    ("Kong Gateway", "Kong", "3.4", "API gateway", "Contain", "Self-managed", "2026-09-30", "Integration Services", 90000),
    ("MuleSoft Anypoint", "Salesforce", "4.5", "Integration platform", "Contain", "SaaS", "", "Integration Services", 430000),
    ("TIBCO BusinessWorks", "TIBCO", "5.14", "Integration platform", "Retire", "Self-managed", "2025-06-30", "Integration Services", 270000),
    # Infrastructure
    ("Red Hat Enterprise Linux", "Red Hat", "9", "Linux server OS", "Strategic", "Self-managed", "2032-05-31", "Linux Engineering", 260000),
    ("Red Hat Enterprise Linux", "Red Hat", "8", "Linux server OS", "Standard", "Self-managed", "2029-05-31", "Linux Engineering", 300000),
    ("Red Hat Enterprise Linux", "Red Hat", "7", "Linux server OS", "Retire", "Self-managed", "2024-06-30", "Linux Engineering", 120000),
    ("Windows Server", "Microsoft", "2022", "Windows server OS", "Strategic", "Self-managed", "2031-10-14", "Windows Engineering", 210000),
    ("Windows Server", "Microsoft", "2019", "Windows server OS", "Standard", "Self-managed", "2029-01-09", "Windows Engineering", 240000),
    ("Windows Server", "Microsoft", "2016", "Windows server OS", "Retire", "Self-managed", "2027-01-12", "Windows Engineering", 180000),
    ("Windows Server", "Microsoft", "2012 R2", "Windows server OS", "Prohibited", "Self-managed", "2023-10-10", "Windows Engineering", 40000),
    ("VMware vSphere", "Broadcom", "8", "Hypervisor", "Standard", "Self-managed", "2027-10-11", "Virtualisation", 880000),
    ("VMware vSphere", "Broadcom", "7", "Hypervisor", "Retire", "Self-managed", "2025-10-02", "Virtualisation", 700000),
    ("Hyper-V", "Microsoft", "2019", "Hypervisor", "Contain", "Self-managed", "2029-01-09", "Virtualisation", 0),
    ("Microsoft Azure", "Microsoft", "n/a", "Public cloud", "Strategic", "PaaS", "", "Cloud Platform", 1900000),
    ("Amazon Web Services", "Amazon", "n/a", "Public cloud", "Contain", "PaaS", "", "Cloud Platform", 320000),
    ("NetApp ONTAP", "NetApp", "9.14", "Storage", "Standard", "Appliance", "2027-09-30", "Storage Services", 450000),
    ("Azure Blob Storage", "Microsoft", "n/a", "Storage", "Strategic", "PaaS", "", "Cloud Platform", 90000),
    ("Veeam Backup and Replication", "Veeam", "12", "Backup", "Standard", "Self-managed", "2027-02-28", "Storage Services", 160000),
    ("Commvault", "Commvault", "11.28", "Backup", "Retire", "Self-managed", "2026-03-31", "Storage Services", 230000),
    # Network
    ("F5 BIG-IP", "F5", "17.1", "Load balancer", "Standard", "Appliance", "2027-12-31", "Network Services", 340000),
    ("Azure Application Gateway", "Microsoft", "n/a", "Load balancer", "Strategic", "PaaS", "", "Cloud Platform", 45000),
    ("GlobalProtect", "Palo Alto Networks", "6.2", "Remote access (VPN)", "Standard", "Appliance", "2027-07-31", "Network Services", 120000),
    # Security
    ("Microsoft Entra ID", "Microsoft", "n/a", "Identity provider", "Strategic", "SaaS", "", "Identity Services", 410000),
    ("AD FS", "Microsoft", "2019", "Identity provider", "Retire", "Self-managed", "2029-01-09", "Identity Services", 0),
    ("CyberArk PAM", "CyberArk", "14.2", "Privileged access", "Standard", "Self-managed", "2027-08-31", "Security Operations", 270000),
    ("Microsoft Sentinel", "Microsoft", "n/a", "SIEM", "Strategic", "SaaS", "", "Security Operations", 380000),
    ("Splunk Enterprise", "Cisco", "9.1", "SIEM", "Contain", "Self-managed", "2026-06-30", "Security Operations", 620000),
    ("Tenable", "Tenable", "10.7", "Vulnerability scanning", "Standard", "Self-managed", "2027-04-30", "Security Operations", 140000),
    ("Azure Key Vault", "Microsoft", "n/a", "Secrets management", "Strategic", "PaaS", "", "Security Operations", 12000),
    ("HashiCorp Vault", "HashiCorp", "1.15", "Secrets management", "Contain", "Self-managed", "2026-01-31", "Security Operations", 75000),
    # End user
    ("Microsoft 365", "Microsoft", "n/a", "Productivity suite", "Strategic", "SaaS", "", "Workplace Services", 1200000),
    ("Microsoft Teams", "Microsoft", "n/a", "Team chat and meetings", "Strategic", "SaaS", "", "Workplace Services", 0),
    ("Windows", "Microsoft", "11 24H2", "Desktop OS", "Strategic", "Self-managed", "2027-10-12", "Workplace Services", 0),
    ("Windows", "Microsoft", "10", "Desktop OS", "Retire", "Self-managed", "2025-10-14", "Workplace Services", 150000),
    # Engineering
    ("GitLab", "GitLab", "17", "Source control", "Strategic", "Self-managed", "", "Engineering Tools", 330000),
    ("Subversion", "Apache Software Foundation", "1.14", "Source control", "Retire", "Self-managed", "", "Engineering Tools", 0),
    ("GitLab CI", "GitLab", "17", "CI/CD pipeline", "Strategic", "Self-managed", "", "Engineering Tools", 0),
    ("Jenkins", "CloudBees", "2.440", "CI/CD pipeline", "Contain", "Self-managed", "2026-05-31", "Engineering Tools", 60000),
    ("JFrog Artifactory", "JFrog", "7.77", "Artifact repository", "Standard", "Self-managed", "2027-03-31", "Engineering Tools", 125000),
    ("Terraform", "HashiCorp", "1.9", "Infrastructure as code", "Standard", "Self-managed", "", "Cloud Platform", 70000),
    ("Ansible", "Red Hat", "2.16", "Infrastructure as code", "Standard", "Self-managed", "2026-11-30", "Linux Engineering", 85000),
    # Operations
    ("Azure Monitor", "Microsoft", "n/a", "Infrastructure monitoring", "Strategic", "PaaS", "", "Operations", 160000),
    ("Zabbix", "Zabbix", "6.0", "Infrastructure monitoring", "Contain", "Self-managed", "2027-02-28", "Operations", 0),
    ("Dynatrace", "Dynatrace", "n/a", "Application performance", "Standard", "SaaS", "", "Operations", 470000),
    ("Elastic Stack", "Elastic", "8.12", "Log management", "Contain", "Self-managed", "2026-10-15", "Operations", 190000),
    ("ServiceNow ITSM", "ServiceNow", "Washington DC", "ITSM platform", "Strategic", "SaaS", "", "Service Management", 900000),
    ("ServiceNow CMDB", "ServiceNow", "Washington DC", "CMDB", "Strategic", "SaaS", "", "Service Management", 0),
]

# ------------------------------------------------------------ applications
# id, name, business domain, criticality, owner, lifecycle
APPS = [
    ("APP-001", "Order Management System", "Front Office", "Tier 1", "Front Office Technology", "Live"),
    ("APP-002", "Portfolio Management System", "Front Office", "Tier 1", "Front Office Technology", "Live"),
    ("APP-003", "IBOR Position Service", "Middle Office", "Tier 1", "Middle Office Technology", "Live"),
    ("APP-004", "Fund Accounting (ABOR)", "Back Office", "Tier 1", "Operations Technology", "Live"),
    ("APP-005", "Trade Settlement Gateway", "Back Office", "Tier 1", "Operations Technology", "Live"),
    ("APP-006", "Risk Analytics Engine", "Risk and Compliance", "Tier 1", "Risk Technology", "Live"),
    ("APP-007", "Compliance Monitoring", "Risk and Compliance", "Tier 1", "Risk Technology", "Live"),
    ("APP-008", "Reference Data Hub", "Data and Reporting", "Tier 1", "Data Engineering", "Live"),
    ("APP-009", "Investment Data Warehouse", "Data and Reporting", "Tier 2", "Data Engineering", "Live"),
    ("APP-010", "Client Reporting Portal", "Data and Reporting", "Tier 2", "Client Technology", "Live"),
    ("APP-011", "Regulatory Reporting", "Risk and Compliance", "Tier 2", "Risk Technology", "Live"),
    ("APP-012", "Reconciliation Service", "Back Office", "Tier 2", "Operations Technology", "Live"),
    ("APP-013", "Client CRM", "Client Services", "Tier 2", "Client Technology", "Live"),
    ("APP-014", "Research Workbench", "Front Office", "Tier 3", "Front Office Technology", "Live"),
    ("APP-015", "Legacy Performance Reporter", "Data and Reporting", "Tier 3", "Data Engineering", "Sunset"),
    ("APP-016", "EA Repository", "Corporate", "Tier 3", "Enterprise Architecture", "Build"),
]

# app -> [(technology label, how it is used)]; label = "name version"
LINKS = {
    "APP-001": [("OpenJDK 17", "Runtime"), ("JBoss EAP 7.4", "Hosting"), ("SQL Server 2019", "Database"), ("Red Hat Enterprise Linux 8", "Operating system"), ("IBM MQ 9.3", "Messaging"), ("F5 BIG-IP 17.1", "Network"), ("Dynatrace n/a", "Monitoring"), ("VMware vSphere 8", "Virtualisation")],
    "APP-002": [("OpenJDK 21", "Runtime"), ("Apache Tomcat 9", "Hosting"), ("Oracle Database 19c", "Database"), ("Red Hat Enterprise Linux 9", "Operating system"), ("Apache Kafka 3.7", "Messaging"), ("Red Hat OpenShift 4.16", "Containers"), ("Azure API Management n/a", "API")],
    "APP-003": [("Python 3.11", "Runtime"), ("Red Hat OpenShift 4.16", "Containers"), ("SQL Server 2022", "Database"), ("Apache Kafka 3.7", "Messaging"), ("NGINX 1.26", "Web"), ("Azure Key Vault n/a", "Secrets"), ("Microsoft Azure n/a", "Cloud")],
    "APP-004": [(".NET Framework 4.8", "Runtime"), ("IIS 10", "Web"), ("SQL Server 2016", "Database"), ("Windows Server 2016", "Operating system"), ("Informatica PowerCenter 10.4", "Data integration"), ("Hyper-V 2019", "Virtualisation"), ("Commvault 11.28", "Backup")],
    "APP-005": [("Oracle Java SE 8", "Runtime"), ("WebSphere Application Server 9.0", "Hosting"), ("Oracle Database 19c", "Database"), ("Red Hat Enterprise Linux 7", "Operating system"), ("IBM MQ 9.3", "Messaging"), ("Axway SecureTransport 5.5", "File transfer"), ("VMware vSphere 7", "Virtualisation")],
    "APP-006": [("Python 3.11", "Runtime"), ("Databricks n/a", "Data science"), ("Microsoft Azure n/a", "Cloud"), ("Azure Blob Storage n/a", "Storage"), ("Apache Kafka 3.7", "Messaging"), ("Azure Data Factory n/a", "Data integration"), ("Power BI n/a", "Reporting"), ("Microsoft Sentinel n/a", "Security")],
    "APP-007": [("OpenJDK 17", "Runtime"), ("Apache Tomcat 9", "Hosting"), ("PostgreSQL 15", "Database"), ("Red Hat Enterprise Linux 8", "Operating system"), ("Splunk Enterprise 9.1", "Log management"), ("Microsoft Entra ID n/a", "Identity")],
    "APP-008": [("Python 3.12", "Runtime"), ("Red Hat OpenShift 4.16", "Containers"), ("SQL Server 2022", "Database"), ("Azure Data Factory n/a", "Data integration"), ("Microsoft Purview n/a", "Data catalogue"), ("Azure API Management n/a", "API"), ("Microsoft Entra ID n/a", "Identity")],
    "APP-009": [("Azure Synapse Analytics n/a", "Warehouse"), ("SSIS 2016", "Data integration"), ("SQL Server 2019", "Database"), ("Windows Server 2019", "Operating system"), ("Power BI n/a", "Reporting"), ("Tableau 2024.2", "Reporting"), ("Veeam Backup and Replication 12", "Backup")],
    "APP-010": [("Node.js 20", "Runtime"), ("NGINX 1.26", "Web"), ("PostgreSQL 15", "Database"), ("Red Hat OpenShift 4.16", "Containers"), ("Microsoft Entra ID n/a", "Identity"), ("Azure Application Gateway n/a", "Network"), ("Dynatrace n/a", "Monitoring")],
    "APP-011": [(".NET 8", "Runtime"), ("IIS 10", "Web"), ("SQL Server 2019", "Database"), ("Windows Server 2019", "Operating system"), ("Informatica PowerCenter 10.4", "Data integration"), ("Axway SecureTransport 5.5", "File transfer")],
    "APP-012": [("Python 3.9", "Runtime"), ("MongoDB 6.0", "Database"), ("Red Hat Enterprise Linux 8", "Operating system"), ("RabbitMQ 3.12", "Messaging"), ("Jenkins 2.440", "CI/CD")],
    "APP-013": [("MuleSoft Anypoint 4.5", "Integration"), ("Microsoft Entra ID n/a", "Identity"), ("Power BI n/a", "Reporting"), ("Microsoft 365 n/a", "Productivity")],
    "APP-014": [("Python 3.12", "Runtime"), ("Anaconda Distribution 2023.09", "Data science"), ("Databricks n/a", "Data science"), ("Azure Blob Storage n/a", "Storage"), ("GitLab 17", "Source control")],
    "APP-015": [("Oracle Java SE 8", "Runtime"), ("Apache Tomcat 9", "Hosting"), ("SQL Server 2016", "Database"), ("Windows Server 2012 R2", "Operating system"), ("Tableau 2024.2", "Reporting"), ("Subversion 1.14", "Source control")],
    "APP-016": [("Python 3.12", "Runtime"), ("Red Hat OpenShift 4.16", "Containers"), ("SQL Server 2022", "Database"), ("GitLab 17", "Source control"), ("GitLab CI 17", "CI/CD"), ("ServiceNow CMDB Washington DC", "Integration"), ("Microsoft Entra ID n/a", "Identity")],
}

# Shared services every application depends on, by tier (kept out of LINKS for brevity)
COMMON = [("ServiceNow ITSM Washington DC", "Service management"), ("Microsoft Entra ID n/a", "Identity"), ("Azure Monitor n/a", "Monitoring")]


def label(t):
    name, _, version, *_ = t
    return f"{name} {version}"


def write(path: Path, header: list[str], rows: list[list]):
    with path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    svc_rows, svc_id = [], {}
    for i, (area, cat, svc) in enumerate(SERVICES, start=1):
        sid = f"SVC-{i:03d}"
        svc_id[svc] = sid
        svc_rows.append([sid, area, cat, svc])
    write(OUT / "services.csv", ["service_id", "service_area", "service_category", "service"], svc_rows)

    tech_rows, tech_id = [], {}
    for i, t in enumerate(T, start=1):
        name, vendor, version, svc, status, deploy, eos, owner, cost = t
        tid = f"TECH-{i:03d}"
        tech_id[label(t)] = tid
        tech_rows.append([tid, name, vendor, version, svc_id[svc], status, deploy, eos, "illustrative" if eos else "", owner, cost])
    write(
        OUT / "technologies.csv",
        ["tech_id", "name", "vendor", "version", "service_id", "standard_status", "deployment_model",
         "end_of_support", "date_source", "owner_team", "annual_cost_usd"],
        tech_rows,
    )

    write(OUT / "applications.csv", ["app_id", "name", "business_domain", "criticality", "owner_team", "lifecycle"], [list(a) for a in APPS])

    link_rows = []
    for app_id, items in LINKS.items():
        seen = set()
        for lab, usage in items + COMMON:
            tid = tech_id[lab]
            if tid in seen:
                continue
            seen.add(tid)
            link_rows.append([app_id, tid, usage])
    write(OUT / "app_technology.csv", ["app_id", "tech_id", "usage"], link_rows)

    print(f"services={len(svc_rows)} technologies={len(tech_rows)} applications={len(APPS)} links={len(link_rows)}")


if __name__ == "__main__":
    main()
